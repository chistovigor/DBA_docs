=========================================================================
Interim Patch for Base Bug: 8350262
=========================================================================

Date: Sep 10, 2010
-------------------------------------------------------------------------
 Platform Patch for      : Generic
 Product Patched         : 10.2.0.4.0
 Product Version         : Enterprise Manager Database Control

Bugs Fixed by this patch:
-------------------------
8350262:CREATE DBCONSOLE CERT WITH 10YEAR VALIDITY

Patch Preinstall Steps:
-----------------------

1. For non-recommended patches, you must have the exact symptoms
   described in the service request (SR).

2. Verify the OUI Inventory.

OPatch needs access to a valid OUI inventory to apply patches.
Validate the OUI inventory with the following command:

  % opatch lsinventory

If the command errors out, contact Oracle Support and work to validate
and verify the inventory setup before proceeding.

3. Please use the latest Version of OPatch.

Oracle recommends that all customers be on the latest version of OPatch.
Please review the following metalink note and follow the instructions
to update to the latest version if needed:

 https://metalink.oracle.com/metalink/plsql/ml2_documents.showNOT?p_id=224346.1

4. Confirm executables appear in your system PATH.

The patching process will use the unzip and the opatch executables.  After
sourcing the ORACLE_HOME environment, confirm both of these exist before
continuing:

  - "which opatch"
  - "which unzip"

If either of these executables do not show in the PATH, correct the problem
before proceeding.

5. Create a location for storing the unzipped patch.  This location
will be referred to later in the document as <PATCH_TOP>.

6. Unzip the patch zip file into the <PATCH_TOP>.

  unzip -d <PATCH_TOP> p8350262_102040_Generic.zip

7. Shut down services running from the ORACLE_HOME.

Before applying this patch, do a clean shut down of all services
running from the ORACLE_HOME.

Patch Installation Steps:
-------------------------

1. Shutdown EM DB Console using the following command.

       % $ORACLE_HOME/bin/emctl stop dbconsole

2. Set your current directory to the directory where the patch
   is located:
    % cd <PATCH_TOP>/8350262

   Ensure that the directory containing the opatch script appears in
   your $PATH; then enter the following command:
    % opatch apply
	
3. Start EM DB Console using the following command.

      % $ORACLE_HOME/bin/emctl start dbconsole

NOTE:
------
There may be cases when Starting dbconsole may fail post 31-Dec-2010. 
In this case, Please set ORACLE_HOME to your Database Home & ORACLE_SID 
and run the following from the patch folder.
   % ./killDBConsole


Patch Deinstallation Instructions:
----------------------------------
1. Shutdown EM DB Console using the following command.

       % $ORACLE_HOME/bin/emctl stop dbconsole

2. Set your current directory to the directory where the patch
   is located:
    % cd <PATCH_TOP>/8350262

3. Ensure that the directory containing the opatch script appears in
   your $PATH; then run the following command:-
   %  opatch rollback -id 8350262
   
4. Start EM DB Console using the following command.

      % $ORACLE_HOME/bin/emctl start dbconsole

