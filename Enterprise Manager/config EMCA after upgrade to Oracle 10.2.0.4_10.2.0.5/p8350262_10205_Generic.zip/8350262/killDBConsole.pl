#!/usr/local/bin/perl
# 
# $Header: emdw/notes/killDBConsole.pl st_emdw_pchebrol_blr_backport_8350262_10.2.0.5.0/3 2010/10/07 07:20:00 pchebrol Exp $
#
# SecureAgent_oms.pl
#  
# Copyright (c) 2010, 2020, Oracle and/or its affiliates. All rights reserved. 
#
#    NAME
#      killDBConsole.pl - <one-line expansion of the name>
#  
#    DESCRIPTION
#      <short description of component this file declares/defines>
#
#    NOTES
#      <other useful comments, qualifications, etc.>
#
#    MODIFIED   (MM/DD/YY)
#    rpinnama    08/19/10 - Creation

use strict;

sub getDBConsolePID($)
{
    my ($emctlPIDFile) = @_;

    my $dbconsolePID = 0;

    open(PIDFILE, "<$emctlPIDFile") or return 0;
    while(<PIDFILE>)
    {
      $dbconsolePID=$_;
    }
    close(PIDFILE);
    chomp($dbconsolePID);

    my $isDBCUp = kill 0, $dbconsolePID;
    if($isDBCUp eq 0)
    {
        $dbconsolePID = 0;
    }

    return $dbconsolePID;
}

sub getWatchDogPID
{
    my $dbcPID = shift;
    my $wdPID = 0;
    my $os = "";

    if($dbcPID ne 0)
    {
        $os = $^O;
        if ($os eq "hpux")
        {
            $ENV{UNIX95} = "XPG4";
        }
        $wdPID = `ps -p $dbcPID -o ppid=`;
        chomp($wdPID);
        $wdPID  =~ s/ //g;
        if($wdPID eq "" or $wdPID eq 1)
        {
            $wdPID = 0;
        }
    }

    return $wdPID;
}

sub getEMAgentPID($)
{
    my ($emdbNohupLoc) = @_;
    my $pidLine = "";
    open(NOHUPFILE, "$emdbNohupLoc") or die "Failed to open $emdbNohupLoc";
    while(<NOHUPFILE>)
    {
        if(/starting emagent/)
        {
            chomp;
            $pidLine = $_;
        }
    }
    close(NOHUPFILE);
    #print "Line from emdb.nohup:\n\t$pidLine\n";
    my @tmpArr = split(":", $pidLine);
    my $tmpLine = $tmpArr[0];
    $tmpLine =~ s/\(pid=//;
    $tmpLine =~ s/\)//;

    my $agentPid = $tmpLine;
    my $isAgtUp = kill 0, $agentPid;
    if($isAgtUp eq 0)
    {
        return 0;
    }
    else
    {
        return $agentPid;
    }
}

sub killProcess
{
    my $pid = shift;
    if($pid eq 1)
    {
        return;
    }

    my $cnt = kill 0, $pid;
    if($cnt eq 0)
    {
       print "Process $pid doesn't exist\n";
       return;
    }
    kill 9, $pid;
    sleep 5;

    my $i = 1;
    for($i=1; $i<=6; $i++)
    {
        sleep 5;
        $cnt = kill 0, $pid;
        if($cnt eq 0)
        {
            print "Successfully killed process $pid\n";
            return;
        }
        else
        {
            if($i eq 6)
            {
                print "Process $pid didn't get kiiled\n"; #TODO
            }
            else
            {
                print "Waiting for process $pid to die\n";
            }
        }
    }
}

#main
my $oh = $ENV{"ORACLE_HOME"};
my $sid = $ENV{"ORACLE_SID"};
if(!defined($oh) || !defined($sid))
{
    die "ORACLE_HOME & ORACLE_SID environment variables need to be set";
}
#print "ORACLE_HOME=$oh\n";
#print "ORACLE_SID=$sid\n";
my $cmd = "$oh/bin/emctl getemhome";
my $emHomeOutput = `$cmd`;
my @tmpArr2 = split("\n",$emHomeOutput);
my $tmpLine= "";
my $stateDir = "";
foreach $tmpLine (@tmpArr2)
{
   chomp($tmpLine);
   if($tmpLine =~ /^EMHOME/)
   {
       $stateDir = $tmpLine;
       $stateDir =~ s/EMHOME=//; 
   }
}

print "State directory = $stateDir\n";

my $justDumpPIDs= 0;
my $argv;
foreach $argv (@ARGV)
{
    if($argv eq "-dump")
    {
        $justDumpPIDs= 1;
    }
}

my $emdbNohupFile = "$stateDir/sysman/log/emdb.nohup";
my $emctlPIDFile  = "$stateDir/emctl.pid";
my $watchDogPID   = 0;
my $dbconsolePID  = 0;
my $agentPID      = 0;

#print "emdb.nohup  = $emdbNohupFile\n";
#print "emctl pid file = $emctlPIDFile\n";

open(TMP1,"$emdbNohupFile") or die "Invalid state directory";
close(TMP1);

$dbconsolePID = getDBConsolePID($emctlPIDFile);
$agentPID = getEMAgentPID($emdbNohupFile);
$watchDogPID = getWatchDogPID($agentPID);

if($watchDogPID eq 0)
{
    print "WatchDog is already stopped\n";
}
else
{
    print "WatchDog PID  = $watchDogPID\n";
}

if($dbconsolePID eq 0)
{
    print "DBConsole is already stopped\n";
}
else
{
    print "DBconsole PID = $dbconsolePID\n";
}

if($agentPID eq 0)
{
    print "EMAgent is already stopped\n";
}
else
{
    print "EMAgent PID   = $agentPID\n";
}


if($justDumpPIDs eq 0)
{
    if($watchDogPID ne 0)
    {
        print "Killing WatchDog (pid=$watchDogPID) ...\n";
        killProcess($watchDogPID);
    }

    if($dbconsolePID ne 0)
    {
        print "Killing DBConsole (pid=$dbconsolePID) ...\n";
        killProcess($dbconsolePID);
    }

    if($agentPID ne 0)
    {
        print "Killing EMAgent (pid=$agentPID) ...\n";
        killProcess($agentPID);
    }
}

