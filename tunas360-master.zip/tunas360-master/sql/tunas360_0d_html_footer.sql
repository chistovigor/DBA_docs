PRO
PRO <br><font class="n">
PRO Want additional information about your system?<br>
PRO TUNAs360 is designed to help gain initial insights about a database.<br>
PRO To know more about the overall system please consider using &&tunas360_conf_eDB360_page.eDB360</a>.<br>
PRO To know more about a specific SQL_ID please consider using &&tunas360_conf_SQLd360_page.SQLd360</a>.<br>
PRO To know more about a specific session that is currently active please consider using &&tunas360_conf_Snapper_page.Snapper</a>.<br>
PRO </font><br>
PRO
PRO <font class="f">&&tunas360_prefix.&&tunas360_copyright.. Version &&tunas360_vrsn.. Report executed on &&tunas360_time_stamp. </font>
PRO </body>
PRO </html>
