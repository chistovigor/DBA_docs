Rem
Rem Copyright (c) 2008,2013 Oracle. All rights reserved.  
Rem
Rem    NAME
Rem     upg_tzv_apply.sql - time zone update apply script for 11gR2 (and higher)
Rem		Version 1.4
Rem     published in note 1585343.1 Scripts to automatically update the RDBMS DST (timezone) version in an 11gR2 or 12cR1 database .
Rem  
Rem    NOTES
Rem      * The upg_tzv_check.sql script must be run before this script.
Rem      * This script must be run using SQL*PLUS from the database home.
Rem      * This script must be connected AS SYSDBA to run.
Rem      * The database need to be 11.2.0.1 or higher.
Rem      * The database need to be single instance ( cluster_database = FALSE ).
Rem      * The database will be restarted 2 times without asking any confirmation.
Rem 	 * This script takes no arguments.
Rem      * This script WILL exit SQL*PLUS when an error is detected
Rem      * The dba_recyclebin WILL be purged.
Rem      * TZ_VERSION in Registry$database will be updated with new DST version after the DST upgrade.
Rem      * TZ_VERSION_UPGRADE in Registry$database will be updated with null after the DST upgrade.
Rem
Rem    DESCRIPTION
Rem      This script update the database to the highest installed 
Rem      timezone definitions found by the upg_tzv_check.sql.
Rem 
Rem		MODIFIED	(MM/DD/YY)
Rem	    gvermeir 	 12/23/13 - minor changes on error handling
Rem	    gvermeir 	 09/20/13 - enhanced error handling
Rem 	gvermeir 	 06/12/13 - Enhanced output
Rem 	gvermeir 	 05/16/13 - Typos fixed
Rem		gvermeir	 05/13/13 - Initial internal release
Rem		gvermeir	 04/23/13 - created
Rem
set TERMOUT off

-- Get time
VARIABLE V_SEC number
EXEC :V_SEC := DBMS_UTILITY.GET_TIME

-- Set client_info so one can use: 
-- select .... from V$SESSION where CLIENT_INFO = 'upg_tzv';
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('upg_tzv');

-- Alter sessions to avoid performance issues
alter session set nls_sort='BINARY';

whenever SQLERROR EXIT
set TERMOUT on
set SERVEROUTPUT on
set FEEDBACK off

-- Check if user is sys
declare
	V_CHECKVAR1				varchar2(10 char);
begin
		execute immediate
		'select substr(SYS_CONTEXT(''USERENV'',''CURRENT_USER''),1,10) from dual' into V_CHECKVAR1 ;
		if V_CHECKVAR1 = 'SYS' then
				null;
			else
				DBMS_OUTPUT.PUT_LINE('ERROR: Current connection is not a sysdba connection !');
				RAISE_APPLICATION_ERROR(-20030,'Stopping script - see previous message .....');
		end if;
end;
/

-- Give some info
EXEC DBMS_OUTPUT.PUT_LINE('INFO: If an ERROR occurs the script will EXIT sqlplus.' );

-- All pre-checks
declare
	V_DBVERSION				varchar2(8 char);
	V_NEWDBTZV				number;
	V_OLDDBTZV				number;
	V_CHECKNUM1				number;
	V_CHECKVAR1				varchar2(10 char);
begin

-- Check if upg_tzv_check.sql has been run
	begin
		execute immediate
         'select TZ_VERSION_UPGRADE from REGISTRY$DATABASE' into V_NEWDBTZV ;
		 		EXCEPTION 
				when NO_DATA_FOUND then -- no rows in REGISTRY$DATABASE  
					DBMS_OUTPUT.PUT_LINE('ERROR: REGISTRY$DATABASE has no rows.');
					DBMS_OUTPUT.PUT_LINE('ERROR: You need to run upg_tzv_check.sql BEFORE upg_tzv_apply.sql .');
					DBMS_OUTPUT.PUT_LINE('ERROR: NO update of the DST version was done !');
					RAISE_APPLICATION_ERROR(-20031,'Stopping script - see previous message .....');
				when TOO_MANY_ROWS then -- more than 1 row in REGISTRY$DATABASE 
					DBMS_OUTPUT.PUT_LINE('ERROR: REGISTRY$DATABASE has more than one row.');
					DBMS_OUTPUT.PUT_LINE('ERROR: You need to run upg_tzv_check.sql BEFORE upg_tzv_apply.sql .');
					DBMS_OUTPUT.PUT_LINE('ERROR: NO update of the DST version was done !');
 					RAISE_APPLICATION_ERROR(-20032,'Stopping script - see previous message .....');					
				when OTHERS then
				if SQLCODE = -904 then  -- REGISTRY$DATABASE exists but no TZ_VERSION_UPGRADE
					DBMS_OUTPUT.PUT_LINE('ERROR: TZ_VERSION_UPGRADE does not exist.');
					DBMS_OUTPUT.PUT_LINE('ERROR: You need to run upg_tzv_check.sql BEFORE upg_tzv_apply.sql .');
					DBMS_OUTPUT.PUT_LINE('ERROR: NO update of the DST version was done !');
					RAISE_APPLICATION_ERROR(-20033,'Stopping script - see previous message .....');
				end if;
				if SQLCODE = -942 then -- no REGISTRY$DATABASE table 
					DBMS_OUTPUT.PUT_LINE('ERROR: REGISTRY$DATABASE does not exist.');
					DBMS_OUTPUT.PUT_LINE('ERROR: You need to run upg_tzv_check.sql BEFORE upg_tzv_apply.sql .');
					DBMS_OUTPUT.PUT_LINE('ERROR: NO update of the DST version was done !');
					RAISE_APPLICATION_ERROR(-20034,'Stopping script - see previous message .....');
				end if;	
		if  V_NEWDBTZV is null then  -- TZ_VERSION_UPGRADE is null
			DBMS_OUTPUT.PUT_LINE('ERROR: TZ_VERSION_UPGRADE is null.');
			DBMS_OUTPUT.PUT_LINE('ERROR: You need to run upg_tzv_check.sql BEFORE upg_tzv_apply.sql .');
			DBMS_OUTPUT.PUT_LINE('ERROR: NO update of the DST version was done !');
			RAISE_APPLICATION_ERROR(-20035,'Stopping script - see previous message .....');
		end if;
	end;
	
	begin
		execute immediate
         'select to_number(substr(PROPERTY_VALUE, 1, 3)) from DATABASE_PROPERTIES where PROPERTY_NAME = ''DST_PRIMARY_TT_VERSION''' into V_OLDDBTZV;
		if V_OLDDBTZV < V_NEWDBTZV then
				DBMS_OUTPUT.PUT_LINE('INFO: The database RDBMS DST version will be updated to DSTv' || TO_CHAR(V_NEWDBTZV) ||' .');
			else
				DBMS_OUTPUT.PUT_LINE('ERROR: No newer DST update was detected.');
				DBMS_OUTPUT.PUT_LINE('ERROR: You need to run upg_tzv_check.sql BEFORE upg_tzv_apply.sql.');
				DBMS_OUTPUT.PUT_LINE('ERROR: NO update of the DST version was done!');
				RAISE_APPLICATION_ERROR(-20036,'Stopping script - see previous message .....');
		end if;
	end;
	
-- Check if DST_UPGRADE_STATE is NONE
	begin
		execute immediate
			'select substr(PROPERTY_VALUE, 1, 10) from DATABASE_PROPERTIES where PROPERTY_NAME = ''DST_UPGRADE_STATE''' into V_CHECKVAR1;
		if V_CHECKVAR1 = 'NONE' then
				null;
			else
				DBMS_OUTPUT.PUT_LINE('ERROR: Current DST_UPGRADE_STATE is '||  V_CHECKVAR1 || ' !');
				DBMS_OUTPUT.PUT_LINE('ERROR: DST_UPGRADE_STATE in DATABASE_PROPERTIES need to be NONE ');
				DBMS_OUTPUT.PUT_LINE('ERROR: before running upg_tzv_check.sql or upg_tzv_apply.sql.');
				DBMS_OUTPUT.PUT_LINE('ERROR: See note 977512.1 for 11gR2 or note 1509653.1 for 12c .');
				RAISE_APPLICATION_ERROR(-20037,'Stopping script - see previous message .....');
		end if;
	end;
	
-- Check if db is single instance, if not end script
	begin
		execute immediate
			'select upper(VALUE) from V$SYSTEM_PARAMETER where upper(NAME)=''CLUSTER_DATABASE''' into V_CHECKVAR1 ;
		if V_CHECKVAR1 = 'FALSE' then
				null;
			else
				DBMS_OUTPUT.PUT_LINE('ERROR: This RAC database is not started in single instance mode !');
				DBMS_OUTPUT.PUT_LINE('ERROR: Set cluster_database = false and start as single instance');
				DBMS_OUTPUT.PUT_LINE('ERROR: and then re-run upg_tzv_apply.sql .');
				DBMS_OUTPUT.PUT_LINE('ERROR: This is required by the startup UPGRADE needed to do the DST update.');
				RAISE_APPLICATION_ERROR(-20038,'Stopping script - see previous message .....');
		end if;
	end;
	
-- End block
end;
/

-- Print little warning and sleep for 3 seconds so one can control-C
EXEC DBMS_OUTPUT.PUT_LINE('WARNING: This script will restart the database 2 times ' );
EXEC DBMS_OUTPUT.PUT_LINE('WARNING: WITHOUT asking ANY confirmation.' );
EXEC DBMS_OUTPUT.PUT_LINE('WARNING: Hit control-c NOW if this is not intended.' );
EXEC DBMS_LOCK.SLEEP( 3 );

-- Say what we do next	
EXEC DBMS_OUTPUT.PUT_LINE('INFO: Restarting the database in UPGRADE mode to start the DST upgrade.' );

whenever SQLERROR continue
set TERMOUT on

-- Startup in upgrade mode
shutdown immediate;
startup upgrade;

set TERMOUT off

-- Alter sessions to avoid (performance) issues
alter session set nls_sort='BINARY';
alter session set "_with_subquery"=materialize;
alter session set "_simple_view_merging"=true;

-- Clean up used objects
truncate table SYS.DST$TRIGGER_TABLE;
truncate table SYS.DST$AFFECTED_TABLES;
truncate table SYS.DST$ERROR_TABLE;

-- Purging dba_recyclebin
purge dba_recyclebin;

whenever SQLERROR EXIT
set TERMOUT on
set SERVEROUTPUT on
set FEEDBACK off

-- Say what we do next	
EXEC DBMS_OUTPUT.PUT_LINE('INFO: Starting the RDBMS DST upgrade. ' );
EXEC DBMS_OUTPUT.PUT_LINE('INFO: Upgrading all SYS owned TSTZ data.' );
EXEC DBMS_OUTPUT.PUT_LINE('INFO: It might take time before any further output is seen ...');

-- Start Upgrade block
declare
	V_NEWDBTZV				number;
	V_OLDDBTZV				number;
	V_CHECKVAR1				varchar2(10 char);
	V_NUMFAIL				number;
	V_ERRCODE				number;
    V_ERRMSG				varchar2(140 char);
	INVALID_TIMEZONE_FILE	EXCEPTION;
	PRAGMA EXCEPTION_INIT(INVALID_TIMEZONE_FILE, -30094);
	WINDOW_ACTIVE			EXCEPTION;
	PRAGMA EXCEPTION_INIT(WINDOW_ACTIVE, -56920);
	NOT_IN_UPGRADE_MODE		EXCEPTION;
	PRAGMA EXCEPTION_INIT(NOT_IN_UPGRADE_MODE, -56926);
 	VIRTUAL_COLUMNS			EXCEPTION;
	PRAGMA EXCEPTION_INIT(VIRTUAL_COLUMNS, -54017); 
begin

-- Get V_Newdbtzv value
	begin
		execute immediate
			'select TZ_VERSION_UPGRADE from REGISTRY$DATABASE' into V_NEWDBTZV;
	end;

-- Start DST upgrade using V_Newdbtzv
-- Need catch for ORA-30094, ORA-56920, ORA-56926 and ora-54017
	begin
		DBMS_DST.BEGIN_UPGRADE(V_NEWDBTZV);
			EXCEPTION
				when INVALID_TIMEZONE_FILE then
					DBMS_OUTPUT.PUT_LINE('ERROR: Unable to find newer RDBMS DST patch or files.');
					RAISE_APPLICATION_ERROR(-20039,'Stopping script - see previous message .....');
				when WINDOW_ACTIVE then
					DBMS_OUTPUT.PUT_LINE('ERROR: A prepare or upgrade window or an on-demand ');
					DBMS_OUTPUT.PUT_LINE('ERROR: or datapump-job loading of a secondary time zone data file is in an active state.');
					RAISE_APPLICATION_ERROR(-20040,'Stopping script - see previous message .....');
				when NOT_IN_UPGRADE_MODE then
					DBMS_OUTPUT.PUT_LINE('ERROR: The database is not started in startup UPGRADE mode!');
					RAISE_APPLICATION_ERROR(-20041,'Stopping script - see previous message');
				when VIRTUAL_COLUMNS then
					DBMS_OUTPUT.PUT_LINE('ERROR: Virtual columns with TSTZ dataype exist giving ora-54017!');
					RAISE_APPLICATION_ERROR(-20042,'Stopping script - see previous message .....');		
				when OTHERS then
					DBMS_OUTPUT.PUT_LINE('ERROR: something went wrong during DBMS_DST.BEGIN_UPGRADE.');
					V_ERRCODE := SQLCODE;
					V_ERRMSG := SUBSTR(SQLERRM,1,140);
					DBMS_OUTPUT.PUT_LINE('Error code ' || V_ERRCODE || ': ' || V_ERRMSG);
					RAISE_APPLICATION_ERROR(-20043,'Stopping script - see previous message .....');
	end; 

-- Check if DST_UPGRADE_STATE is UPGRADE
	begin
		execute immediate
			'select substr(PROPERTY_VALUE, 1, 10) from DATABASE_PROPERTIES where PROPERTY_NAME = ''DST_UPGRADE_STATE''' into V_CHECKVAR1;
		if V_CHECKVAR1 = 'UPGRADE' then
				null;
			else
				DBMS_OUTPUT.PUT_LINE('ERROR: Current DST_UPGRADE_STATE is '||  V_CHECKVAR1 || ' !');
				DBMS_OUTPUT.PUT_LINE('ERROR: DST_UPGRADE_STATE in DATABASE_PROPERTIES need to be UPGRADE ');
				DBMS_OUTPUT.PUT_LINE('ERROR: after a DBMS_DST.BEGIN_UPGRADE.');
				DBMS_OUTPUT.PUT_LINE('ERROR: See note 977512.1 for 11gR2 or note 1509653.1 for 12c .');
				RAISE_APPLICATION_ERROR(-20044,'Stopping script - see previous message .....');
		end if;
	end;

-- End block
end;
/

-- Say what we do next		
EXEC DBMS_OUTPUT.PUT_LINE('INFO: Restarting the database in NORMAL mode to upgrade non-SYS TSTZ data.' );

whenever SQLERROR continue
set TERMOUT on

-- Startup normal needed to end upgrade
shutdown immediate
startup
set TERMOUT off

-- Alter sessions to avoid (performance) issues
alter session set nls_sort='BINARY';
alter session set "_with_subquery"=materialize;
alter session set "_simple_view_merging"=true;

whenever SQLERROR EXIT
set TERMOUT on
set SERVEROUTPUT on
set FEEDBACK off

-- Say what we do next	
EXEC DBMS_OUTPUT.PUT_LINE('INFO: Upgrading all non-SYS TSTZ data.' );
EXEC DBMS_OUTPUT.PUT_LINE('INFO: It might take time before any further output is seen ...');
EXEC DBMS_OUTPUT.PUT_LINE('INFO: Do NOT start any application yet that uses TSTZ data!');
-- Begin upgrade user data block
declare
	V_NEWDBTZV		number;
	V_OLDDBTZV		number;
	V_CHECKVAR1		varchar2(10 char);
	V_NUMFAIL		number;
 begin
 
-- Upgrade database TSTZ data
	begin
		DBMS_OUTPUT.PUT_LINE('INFO: Next is a list of all upgraded tables:');
		DBMS_DST.UPGRADE_DATABASE(V_NUMFAIL,
			PARALLEL => true,
			LOG_ERRORS => true,
			LOG_ERRORS_TABLE => 'SYS.DST$ERROR_TABLE',
			LOG_TRIGGERS_TABLE => 'SYS.DST$TRIGGER_TABLE',
			ERROR_ON_OVERLAP_TIME => false,
			ERROR_ON_NONEXISTING_TIME => false);
		DBMS_OUTPUT.PUT_LINE('INFO: Total failures during update of TSTZ data: '|| V_NUMFAIL|| ' .');
	end;

-- If this gives count(*) > 0 then error - go manual
	begin
		execute immediate
         'select count(*) from SYS.DST$ERROR_TABLE'  into V_CHECKVAR1 ;
		if V_CHECKVAR1 != '0' then
				DBMS_OUTPUT.PUT_LINE('ERROR: Something cannot be handled automatically !');
				DBMS_OUTPUT.PUT_LINE('ERROR: Do an manual update and checks as documented in ');
				DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c.');
				RAISE_APPLICATION_ERROR(-20045,'Stopping script - see previous message .....');
		end if;
	end;
	
-- End upgrade
	DBMS_DST.END_UPGRADE(V_NUMFAIL);
	
-- Check if DST_UPGRADE_STATE is NONE
	begin
		execute immediate
			'select substr(PROPERTY_VALUE, 1, 10) from DATABASE_PROPERTIES where PROPERTY_NAME = ''DST_UPGRADE_STATE''' into V_CHECKVAR1;
		if V_CHECKVAR1 = 'NONE' then
				null;
			else
				DBMS_OUTPUT.PUT_LINE('ERROR: Current DST_UPGRADE_STATE is '||  V_CHECKVAR1 || ' !');
				DBMS_OUTPUT.PUT_LINE('ERROR: DST_UPGRADE_STATE in DATABASE_PROPERTIES need to be NONE ');
				DBMS_OUTPUT.PUT_LINE('ERROR: after a DBMS_DST.END_UPGRADE.');
				DBMS_OUTPUT.PUT_LINE('ERROR: See note 977512.1 for 11gR2 or note 1509653.1 for 12c .');
				RAISE_APPLICATION_ERROR(-20046,'Stopping script - see previous message .....');
		end if;
	end;
	
-- Check if new TZ value is indeed seen
-- Get new Newdbtzv value and compare
	begin
		execute immediate
         'select TZ_VERSION_UPGRADE from REGISTRY$DATABASE' into V_NEWDBTZV ;
		execute immediate
         'select to_number(substr(PROPERTY_VALUE, 1, 3)) from DATABASE_PROPERTIES where PROPERTY_NAME = ''DST_PRIMARY_TT_VERSION''' into V_OLDDBTZV;
		if V_OLDDBTZV = V_NEWDBTZV then
				DBMS_OUTPUT.PUT_LINE('INFO: Your new Server RDBMS DST version is DSTv' || TO_CHAR(V_NEWDBTZV) ||' .');
			else
				DBMS_OUTPUT.PUT_LINE('ERROR: Your Server timezone version was not updated to DSTv'|| TO_CHAR(V_NEWDBTZV) ||' .');
				RAISE_APPLICATION_ERROR(-20047,'Stopping script - see previous message .....');
		end if;
	end;
	
-- Housekeeping
	begin
      execute immediate 
         'update REGISTRY$DATABASE set TZ_VERSION = :1' using V_NEWDBTZV;
	  execute immediate 
         'update REGISTRY$DATABASE set TZ_VERSION_UPGRADE = NULL';
	end;
commit;

-- End of block
end;
/
EXEC DBMS_OUTPUT.PUT_LINE('INFO: The RDBMS DST update is successfully finished.');
EXEC DBMS_OUTPUT.PUT_LINE('INFO: Make sure to exit this sqlplus session.');
EXEC DBMS_OUTPUT.PUT_LINE('INFO: Do not use it for timezone related selects.');

-- uncomment to print time it took
EXEC :V_SEC := (DBMS_UTILITY.GET_TIME - :V_SEC)/100
-- EXEC DBMS_OUTPUT.PUT_LINE('INFO: Total Seconds elapsed : '||:V_SEC)

whenever SQLERROR continue
set TERMOUT on
set FEEDBACK on
-- End of upg_tzv_apply.sql