Rem
Rem Copyright (c) 2008,2013 Oracle. All rights reserved.  
Rem
Rem    NAME
Rem     upg_tzv_check.sql - time zone update check script for 11gR2 (and higher)
Rem		Version 1.4
Rem     published in note 1585343.1 Scripts to automatically update the RDBMS DST (timezone) version in an 11gR2 or 12cR1 database .
Rem
Rem    NOTES
Rem      * This script must be run using SQL*PLUS from the database home.
Rem      * This script must be connected AS SYSDBA to run.
Rem      * The database need to be 11.2.0.1 or higher.
Rem      * The database will NOT be restarted .
Rem      * NO downtime is needed for this script.
Rem 	 * This script takes no arguments.
Rem      * This script WILL exit SQL*PLUS when an error is detected
Rem      * The dba_recyclebin WILL be purged.
Rem      * This script will check for all known issues at time of last update.
Rem      * Column TZ_VERSION_UPGRADE will be added to Registry$database.
Rem      * TZ_VERSION_UPGRADE in Registry$database will be updated with new version.
Rem      * TZ_VERSION in Registry$database will be updated with current version.
Rem      * The upg_tzv_apply.sql script depends on this script.
Rem
Rem    DESCRIPTION
Rem      This script prepares a database to update the database to the highest 
Rem      installed timezone definitions using the upg_tzv_apply.sql.
Rem 
Rem		MODIFIED	(MM/DD/YY)
Rem	    gvermeir 	 12/23/13 - minor changes on error handling
Rem	    gvermeir 	 09/20/13 - enhanced error checking and handling
Rem		gvermeir 	 06/12/13 - enhanced storing of found result
Rem		gvermeir 	 06/07/13 - corrected check for bug 14732853
Rem 	gvermeir 	 05/16/13 - Additional check added/typos fixed
Rem		gvermeir	 05/13/13 - Initial internal release
Rem		gvermeir	 04/23/13 - created
Rem
set TERMOUT off
set FEEDBACK off

-- Get time
VARIABLE V_SEC number
EXEC :V_SEC := DBMS_UTILITY.GET_TIME

-- Set client_info so one can use: 
-- select .... from V$SESSION where CLIENT_INFO = 'upg_tzv';
EXEC DBMS_APPLICATION_INFO.SET_CLIENT_INFO('upg_tzv');

set SERVEROUTPUT on
whenever SQLERROR EXIT

-- Alter session to avoid performance issues
alter session set nls_sort='BINARY';

set TERMOUT on

-- Check if user is sys
declare
	V_CHECKVAR1				varchar2(10 char);
begin
		execute immediate
		'select substr(SYS_CONTEXT(''USERENV'',''CURRENT_USER''),1,10) from dual' into V_CHECKVAR1 ;
		if V_CHECKVAR1 = 'SYS' then
				null;
			else
				DBMS_OUTPUT.PUT_LINE('ERROR: Current connection is not a sysdba connection!');
				RAISE_APPLICATION_ERROR(-20001,'Stopping script - see previous message .....');
		end if;
end;
/

-- Give some info
EXEC DBMS_OUTPUT.PUT_LINE('INFO: Starting with RDBMS DST update preparation.' );
EXEC DBMS_OUTPUT.PUT_LINE('INFO: NO actual RDBMS DST update will be done by this script.' );
EXEC DBMS_OUTPUT.PUT_LINE('INFO: If an ERROR occurs the script will EXIT sqlplus.' );

-- Purging dba_recyclebin
purge dba_recyclebin;

-- All pre-checks
declare
	V_DBVERSION				varchar2(8 char);
	V_OLDDBTZV				number;
	V_CHECKNUM1				number;
	V_CHECKNUM2				number;	
	V_CHECKVAR1				varchar2(10 char);
begin

-- Making sure that only Release 11gR2 and up uses this script
	begin
		begin
			execute immediate
				'SELECT substr(VERSION,1,8)from V$INSTANCE' into V_DBVERSION ;
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
				DBMS_OUTPUT.PUT_LINE('ERROR: VERSION from V$INSTANCE gives no rows.');
				DBMS_OUTPUT.PUT_LINE('ERROR: Do an manual update and checks as documented in ');
				DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c.');
				RAISE_APPLICATION_ERROR(-20002,'Stopping script - see previous message .....');
		END;
		 if SUBSTR(V_DBVERSION,1,6) in ('8.1.7.','8.1.6.','8.1.5.','8.0.6.','8.0.5.','8.0.4.','9.0.1.','9.2.0.','10.1.0','10.2.0','11.1.0') then
				DBMS_OUTPUT.PUT_LINE('ERROR: This script cannot be used in Release ' || V_DBVERSION);
				DBMS_OUTPUT.PUT_LINE('ERROR: Please see note 412160.1 for the relevant note ');
				DBMS_OUTPUT.PUT_LINE('ERROR: when applying a DST patch to a database. ');
				DBMS_OUTPUT.PUT_LINE('ERROR: When upgrading to 11.2 or higher you need to run ' );
				DBMS_OUTPUT.PUT_LINE('ERROR: the upg_tzv_check.sql and upg_tzv_apply.sql scripts ' );
				DBMS_OUTPUT.PUT_LINE('ERROR: AFTER the RDBMS version upgrade. ' );
				RAISE_APPLICATION_ERROR(-20003,'Stopping script - see previous message .....');
			else
				DBMS_OUTPUT.PUT_LINE('INFO: Database version is '|| V_DBVERSION || ' .');
		 end if;
	end;
	
-- Check if DST_UPGRADE_STATE is NONE
	begin
		begin	
			execute immediate
				'select substr(PROPERTY_VALUE, 1, 10) from DATABASE_PROPERTIES where PROPERTY_NAME = ''DST_UPGRADE_STATE''' into V_CHECKVAR1;
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					DBMS_OUTPUT.PUT_LINE('ERROR: DST_PRIMARY_TT_VERSION from DATABASE_PROPERTIES gives no rows.');
					DBMS_OUTPUT.PUT_LINE('ERROR: Do an manual update and checks as documented in ');
					DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c.');
					RAISE_APPLICATION_ERROR(-20004,'Stopping script - see previous message .....');
		end;
		if V_CHECKVAR1 = 'NONE' then
				null;
				
		elsif V_CHECKVAR1 = 'PREPARE' then
				DBMS_OUTPUT.PUT_LINE('WARNING: Current DST_UPGRADE_STATE is '||  V_CHECKVAR1 || ' !');
				DBMS_OUTPUT.PUT_LINE('WARNING: DST_UPGRADE_STATE in DATABASE_PROPERTIES need to be NONE ');
				DBMS_OUTPUT.PUT_LINE('WARNING: before running upg_tzv_check.sql or upg_tzv_apply.sql.');
				DBMS_OUTPUT.PUT_LINE('WARNING: Trying to end PREPARE window and then continue');
				DBMS_DST.END_PREPARE;
				-- if this fails it will error out in next Check if DST_SECONDARY_TT_VERSION is zero check
				
		elsif V_CHECKVAR1 = 'DATAPUMP' then		
				DBMS_OUTPUT.PUT_LINE('ERROR: Current DST_UPGRADE_STATE is '||  V_CHECKVAR1 || ' !');
				DBMS_OUTPUT.PUT_LINE('ERROR: DST_UPGRADE_STATE in DATABASE_PROPERTIES need to be NONE ');
				DBMS_OUTPUT.PUT_LINE('ERROR: before running upg_tzv_check.sql or upg_tzv_apply.sql.');
				DBMS_OUTPUT.PUT_LINE('ERROR: wait until the datapump load is done or check ');
				DBMS_OUTPUT.PUT_LINE('ERROR: Note 336014.1 How To Cleanup Orphaned DataPump Jobs In DBA_DATAPUMP_JOBS ?');
				RAISE_APPLICATION_ERROR(-20004,'Stopping script - see previous message .....');
				
		elsif V_CHECKVAR1 = 'UPGRADE' then
				DBMS_OUTPUT.PUT_LINE('ERROR: Current DST_UPGRADE_STATE is '||  V_CHECKVAR1 || ' !');
				DBMS_OUTPUT.PUT_LINE('ERROR: DST_UPGRADE_STATE in DATABASE_PROPERTIES need to be NONE ');
				DBMS_OUTPUT.PUT_LINE('ERROR: before running upg_tzv_check.sql or upg_tzv_apply.sql.');
				DBMS_OUTPUT.PUT_LINE('ERROR: Check if an other DBA is doing a DST upgrade .');
				DBMS_OUTPUT.PUT_LINE('ERROR: If not the do the checks as documented in point 3 ');
				DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c .');
				RAISE_APPLICATION_ERROR(-20005,'Stopping script - see previous message .....');
				
		else
				DBMS_OUTPUT.PUT_LINE('ERROR: Current DST_UPGRADE_STATE is '||  V_CHECKVAR1 || ' !');
				DBMS_OUTPUT.PUT_LINE('ERROR: DST_UPGRADE_STATE in DATABASE_PROPERTIES need to be NONE ');
				DBMS_OUTPUT.PUT_LINE('ERROR: before running upg_tzv_check.sql or upg_tzv_apply.sql.');
				DBMS_OUTPUT.PUT_LINE('ERROR: Do the checks as documented in point 3 ');
				DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c .');
				RAISE_APPLICATION_ERROR(-20006,'Stopping script - see previous message .....');
		end if;
	end;

-- Check if DST_SECONDARY_TT_VERSION is zero
	begin
		begin
			execute immediate
				'select substr(PROPERTY_VALUE, 1, 3) from DATABASE_PROPERTIES where PROPERTY_NAME = ''DST_SECONDARY_TT_VERSION''' into V_CHECKNUM1;
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					DBMS_OUTPUT.PUT_LINE('ERROR: DST_PRIMARY_TT_VERSION from DATABASE_PROPERTIES gives no rows.');
					DBMS_OUTPUT.PUT_LINE('ERROR: Do an manual update and checks as documented in ');
					DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c.');
					RAISE_APPLICATION_ERROR(-20007,'Stopping script - see previous message .....');
		end;
		
		if V_CHECKNUM1 = '0' then
				null;
			else
				DBMS_OUTPUT.PUT_LINE('ERROR: Current DST_SECONDARY_TT_VERSION is '|| TO_CHAR(V_CHECKNUM1) || ' !');
				DBMS_OUTPUT.PUT_LINE('ERROR: DST_SECONDARY_TT_VERSION in DATABASE_PROPERTIES need to be 0 ');
				DBMS_OUTPUT.PUT_LINE('ERROR: before this script can be run. ');
				DBMS_OUTPUT.PUT_LINE('ERROR: Do the checks as documented in point 3 ');
				DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c .');
				RAISE_APPLICATION_ERROR(-20008,'Stopping script - see previous message .....');
		end if;
	end;
		
-- Get current TZ version seen in v$timezone_file
-- Check that DST_PRIMARY_TT_VERSION value matches VERSION of V$TIMEZONE_FILE
-- If not then someone messed with the *.dat files (renamed them or made symbolic links)
	begin
		begin
			execute immediate
				'select VERSION from V$TIMEZONE_FILE' into V_OLDDBTZV ;
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					DBMS_OUTPUT.PUT_LINE('ERROR: VERSION from V$TIMEZONE_FILE gives no rows.');
					DBMS_OUTPUT.PUT_LINE('ERROR: Do an manual update and checks as documented in ');
					DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c.');
					RAISE_APPLICATION_ERROR(-20009,'Stopping script - see previous message .....');
		END;
	
		begin
			execute immediate
				'select substr(PROPERTY_VALUE, 1, 3) from DATABASE_PROPERTIES where PROPERTY_NAME = ''DST_PRIMARY_TT_VERSION''' into V_CHECKNUM1 ;
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
					DBMS_OUTPUT.PUT_LINE('ERROR: DST_PRIMARY_TT_VERSION from DATABASE_PROPERTIES gives no rows.');
					DBMS_OUTPUT.PUT_LINE('ERROR: Do an manual update and checks as documented in ');
					DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c.');
					RAISE_APPLICATION_ERROR(-20010,'Stopping script - see previous message .....');
		end;
	
		if V_OLDDBTZV = V_CHECKNUM1 then
			DBMS_OUTPUT.PUT_LINE('INFO: Database RDBMS DST version is DSTv'|| TO_CHAR(V_OLDDBTZV) || ' .');
		else
			DBMS_OUTPUT.PUT_LINE('ERROR: Current Server RDBMS DST version cannot be determined.');
			DBMS_OUTPUT.PUT_LINE('ERROR: Do an manual update and checks as documented in ');
			DBMS_OUTPUT.PUT_LINE('ERROR: of note 977512.1 for 11gR2 or note 1509653.1 for 12c.');
			RAISE_APPLICATION_ERROR(-20011,'Stopping script - see previous message .....');
		end if;
	end;


-- Version dependent checks for known bugs
DBMS_OUTPUT.PUT_LINE('INFO: Doing checks for known issues ...' );

-- V_CHECKNUM2 is used to count issues found
V_CHECKNUM2 := TO_NUMBER('0');

--  11.2.0.1 only bugs 
	if V_DBVERSION in ('11.2.0.1') then
	
-- Check if case insensitive table or column names exist
-- They give ORA-00904: invalid identifier 
-- or ORA-01747: invalid user.table.column, table.column, or column specification.
-- Fixed in 11.2.0.2
		begin
			execute immediate
				'select count (*) from DBA_TAB_COLUMNS where DATA_TYPE like ''TIMESTAMP% WITH TIME ZONE'' and ( upper(TABLE_NAME) != TABLE_NAME or upper(COLUMN_NAME) != COLUMN_NAME)' into V_CHECKNUM1 ;
			if V_CHECKNUM1 = TO_NUMBER('0') then
					null;
				else
					DBMS_OUTPUT.PUT_LINE('ERROR: Case insensitive table or column names exist.');
					DBMS_OUTPUT.PUT_LINE('ERROR: ORA-00904 or ORA-01747 will be seen duing DBMS_DST.');
					DBMS_OUTPUT.PUT_LINE('ERROR: See known issues section of Note 977512.1 .');			
					V_CHECKNUM2 := V_CHECKNUM2 + TO_NUMBER('1');
			end if;
		end;
	end if;
	
-- no 11.2.0.2 only bugs exist

-- 11.2.0.1, 11.2.0.2, 11.2.0.3 only bugs
	if V_DBVERSION in ('11.2.0.1','11.2.0.2','11.2.0.3') then
	
-- Check if TIMESTAMP WITH TIME ZONE data type as part of an object subtype exist
-- They give ORA-00907: missing right parenthesis
-- Bug 13833939 - ora-0907 when preparing for dst upgrade.
-- Fixed in 11.2.0.4 and 12c
		begin
			execute immediate
				'select count (*) from DBA_TSTZ_TAB_COLS where instr(QUALIFIED_COL_NAME,''TREAT'',1,1) > 0' into V_CHECKNUM1 ;
			if V_CHECKNUM1 = TO_NUMBER('0') then
					null;
				else
					DBMS_OUTPUT.PUT_LINE('ERROR: TSTZ data type as part of an object subtype exist.');
					DBMS_OUTPUT.PUT_LINE('ERROR: ORA-00907 will be seen during DBMS_DST.');
					DBMS_OUTPUT.PUT_LINE('ERROR: See known issues section of Note 977512.1 ');
					DBMS_OUTPUT.PUT_LINE('ERROR: for bug 13833939 .');						
					V_CHECKNUM2 := V_CHECKNUM2 + TO_NUMBER('1');
			end if;
		end;

-- Check if there are virtual TSTZ columns
-- They give ORA-54017: UPDATE operation disallowed on virtual columns
-- Bug 13436809: ORA-54017 UPDATE OPERATION DISALLOWED ON VIRTUAL COLUMNS ERROR RUNNING DBMS_DST
-- Fixed in 11.2.0.4 and 12c
		begin
			execute immediate
				'select count (*) from DBA_TAB_COLS C, DBA_OBJECTS O where C.DATA_TYPE like ''%WITH TIME ZONE'' and C.VIRTUAL_COLUMN =''YES'' and O.OBJECT_TYPE = ''TABLE'' and C.OWNER = O.OWNER and C.TABLE_NAME = O.OBJECT_NAME ' into V_CHECKNUM1 ;
			if V_CHECKNUM1 = TO_NUMBER('0') then
					null;
				else
					DBMS_OUTPUT.PUT_LINE('ERROR: Virtual TSTZ columns exist.');
					DBMS_OUTPUT.PUT_LINE('ERROR: ORA-54017 will be seen during DBMS_DST.');
					DBMS_OUTPUT.PUT_LINE('ERROR: See known issues section of Note 977512.1 ');
					DBMS_OUTPUT.PUT_LINE('ERROR: for bug 13436809 .');		
					V_CHECKNUM2 := V_CHECKNUM2 + TO_NUMBER('1');
			end if;
		end;
	end if;
	
-- Bugs not fixed in 11gR2 or 12c at time of script creation

-- Check if there are unused TSTZ columns 
-- They give ORA-00904: "T"."SYS_C00001_-random number here-": invalid identifier 
-- Bug 14732853 - DBMS_DST DOES NOT HANDLE UNUSED TIMESTAMP WITH TIME ZONE COLUMNS
-- NOT Fixed yet
	begin
		execute immediate
			'select count (*) from  DBA_TAB_COLS U, DBA_UNUSED_COL_TABS O where U.OWNER=O.OWNER and U.TABLE_NAME=O.TABLE_NAME and U.HIDDEN_COLUMN = ''YES'' and U.COLUMN_NAME in (select T.QUALIFIED_COL_NAME from DBA_TSTZ_TAB_COLS T )' into V_CHECKNUM1 ;
		if V_CHECKNUM1 = TO_NUMBER('0')then
				null;
			else
				DBMS_OUTPUT.PUT_LINE('ERROR: Unused TSTZ columns exist.');
				DBMS_OUTPUT.PUT_LINE('ERROR: ORA-00904 will be seen during DBMS_DST.');
				DBMS_OUTPUT.PUT_LINE('ERROR: See the known issues section of  ');
				DBMS_OUTPUT.PUT_LINE('ERROR: note 977512.1 for 11gR2 or note 1509653.1 for 12c .');
				DBMS_OUTPUT.PUT_LINE('ERROR: for bug 14732853 .');						
				V_CHECKNUM2 := V_CHECKNUM2 + TO_NUMBER('1');
		end if;
	end;
	
-- Error out if one of above problems is detected
	begin
		if V_CHECKNUM2 != TO_NUMBER('0') then
				RAISE_APPLICATION_ERROR(-20012,'Stopping script - see previous message .....');
			else
			DBMS_OUTPUT.PUT_LINE('INFO: No known issues detected.');
		end if;
	end;
	
-- End block
end;
/
	
-- REGISTRY$DATABASE checks
declare
	V_OLDDBTZV				number;
	V_CHECKNUM1				number;	
begin
	begin
		execute immediate
			'select VERSION from V$TIMEZONE_FILE' into V_OLDDBTZV ;
	end;

-- Update REGISTRY$DATABASE TZ_VERSION_UPGRADE with null
-- If REGISTRY$DATABASE already exists and column TZ_VERSION_UPGRADE
-- is added to the existing REGISTRY$DATABASE table then this will
-- invalidate DBMS_REGISTRY package, DBA_REGISTRY_DATABASE view and
-- DBA_REGISTRY_DATABASE synonym, so we need to compile these after  
-- alter table add column via the alter xx ..compile statement below
	begin
		execute immediate 
			'update REGISTRY$DATABASE set TZ_VERSION_UPGRADE =  NULL';
		EXCEPTION 
			when OTHERS then 
				if SQLCODE = -904 then  -- REGISTRY$DATABASE exists but no TZ_VERSION_UPGRADE
					execute immediate
						'alter table REGISTRY$DATABASE add (TZ_VERSION_UPGRADE NUMBER)';
					execute immediate
						'update REGISTRY$DATABASE set TZ_VERSION_UPGRADE =  NULL';
					execute immediate
						'alter PACKAGE DBMS_REGISTRY compile body';
					execute immediate
						'alter view DBA_REGISTRY_DATABASE compile';
					execute immediate
						'alter public synonym DBA_REGISTRY_DATABASE compile';
				end if;
				if SQLCODE = -942 then -- no REGISTRY$DATABASE table so create it
					execute immediate 
						'CREATE TABLE REGISTRY$DATABASE( 
						platform_id   NUMBER,       
						platform_name VARCHAR2(101),
						edition       VARCHAR2(30), 
						TZ_VERSION    NUMBER,
						TZ_VERSION_UPGRADE NUMBER    			 
						)';
					execute immediate
						'insert into REGISTRY$DATABASE
						(platform_id, platform_name, edition, TZ_VERSION, TZ_VERSION_UPGRADE)
						VALUES (NULL, NULL, NULL, :1,  NULL)' using V_OLDDBTZV ;
				end if;
		commit;
	end;
commit;
-- set TZ_VERSION to current TZ value
-- same story as with TZ_VERSION_UPGRADE but now we know  REGISTRY$DATABASE exists
	begin
      execute immediate 
         'update REGISTRY$DATABASE set TZ_VERSION = :1' using V_OLDDBTZV;
		EXCEPTION 
			when OTHERS then 
				if SQLCODE = -904 then  -- REGISTRY$DATABASE exists but no TZ_VERSION
					execute immediate
						'alter table REGISTRY$DATABASE add (TZ_VERSION NUMBER)';
					execute immediate
						'update REGISTRY$DATABASE set TZ_VERSION = :1 ' using V_OLDDBTZV;
					execute immediate
						'alter PACKAGE DBMS_REGISTRY compile body';
					execute immediate
						'alter view DBA_REGISTRY_DATABASE compile';
					execute immediate
						'alter public synonym DBA_REGISTRY_DATABASE compile';
				end if;	 
		commit;
	end;
commit;
-- Still possible to have no rows or to many rows in REGISTRY$DATABASE
-- so check that also, just in case
	begin
		execute immediate
         'select TZ_VERSION from REGISTRY$DATABASE' into V_CHECKNUM1 ;
		 		EXCEPTION 
				when NO_DATA_FOUND then -- no rows in REGISTRY$DATABASE  
						execute immediate
						'insert into REGISTRY$DATABASE
						( TZ_VERSION, TZ_VERSION_UPGRADE)
						VALUES (  :1,  NULL)' using V_OLDDBTZV ;
						Commit;
				when TOO_MANY_ROWS then -- more than 1 row in REGISTRY$DATABASE 
						execute immediate
						'truncate table REGISTRY$DATABASE' ;
						execute immediate
						'insert into REGISTRY$DATABASE
						( TZ_VERSION, TZ_VERSION_UPGRADE)
						VALUES (  :1,  NULL)' using V_OLDDBTZV ;
						Commit;				
	end;
		 
-- End block
end;
/

-- Say what we do next	
EXEC DBMS_OUTPUT.PUT_LINE('INFO: Now detecting new RDBMS DST version.' );

set TERMOUT off
-- Alter sessions to avoid (performance) issues
alter session set "_with_subquery"=materialize;
alter session set "_simple_view_merging"=true;

set TERMOUT on
set FEEDBACK off

-- Now find new DST value
declare

	V_NEWDBTZV				number;
	V_CHECKNUM1				number;
	V_CHECKVAR1				varchar2(10 char);
	V_ERRCODE				number;
    V_ERRMSG				varchar2(140 char);
	V_NUMFAIL				number;
	NO_NEW_TIMEZONE        	EXCEPTION;
	PRAGMA EXCEPTION_INIT(NO_NEW_TIMEZONE, -56921);
	INVALID_TIMEZONE_FILE  	EXCEPTION;
	PRAGMA EXCEPTION_INIT(INVALID_TIMEZONE_FILE, -30094);
	PREPWINDOW_FAIL			EXCEPTION;
	PRAGMA EXCEPTION_INIT(PREPWINDOW_FAIL, -56922);
begin

-- Using DBMS_DST.BEGIN_PREPARE to find highest installed DST version
-- by doing DBMS_DST.BEGIN_PREPARE from 199 to 1 .
-- It will ORA-30094: failed to find the time zone data file if no DST patch is found
-- in that case loop further .
-- DBMS_DST.BEGIN_PREPARE will not error out if a newer than the current DST value
-- is detected.
-- A lower or equal than current TZ value gives ORA-56921: invalid time zone version,
-- in that case stop.
	for	I in reverse 1..199 LOOP
		begin
			V_NEWDBTZV := I;
			DBMS_DST.BEGIN_PREPARE(I);
			EXIT;
			EXCEPTION
				when INVALID_TIMEZONE_FILE then
					null;
				when NO_NEW_TIMEZONE then
					DBMS_OUTPUT.PUT_LINE('ERROR: No newer RDBMS DST patch has been detected.');
					DBMS_OUTPUT.PUT_LINE('ERROR: Check if a newer RDBMS DST patch is actually installed.');
					RAISE_APPLICATION_ERROR(-20013,'Stopping script - see previous message .....');
				when PREPWINDOW_FAIL then
					DBMS_OUTPUT.PUT_LINE('ERROR: ORA-56922: Starting a prepare window failed.');
					DBMS_OUTPUT.PUT_LINE('ERROR: Most likly the shared pool is unable to allocate additional');
					DBMS_OUTPUT.PUT_LINE('ERROR: storage during the execution of the DBMS_DST.BEGIN_PREPARE package.');
					DBMS_OUTPUT.PUT_LINE('ERROR: Flush the shared pool or bounced the database to free up the SGA ');
					DBMS_OUTPUT.PUT_LINE('ERROR: and then run upg_tzv_check.sql again.');	
					RAISE_APPLICATION_ERROR(-20014,'Stopping script - see previous message .....');
				when OTHERS then
					DBMS_OUTPUT.PUT_LINE('ERROR: something went wrong during DBMS_DST.BEGIN_PREPARE');
					V_ERRCODE := SQLCODE;
					V_ERRMSG := SUBSTR(SQLERRM,1,140);
					DBMS_OUTPUT.PUT_LINE('Error code ' || V_ERRCODE || ': ' || V_ERRMSG);
					RAISE_APPLICATION_ERROR(-20015,'Stopping script - see previous message .....');
		end;
	end LOOP;

-- Here we have if all went well a V_Newdbtzv value with the highest new TZ file found
-- But it means also a DBMS_DST.BEGIN_PREPARE is already started 
-- So that is not needed in the following steps
	begin
		DBMS_OUTPUT.PUT_LINE('INFO: Newest RDBMS DST version detected is DSTv'|| TO_CHAR(V_NEWDBTZV) || ' .' );
	end;
	
-- Update REGISTRY$DATABASE with V_Newdbtzv time zone information

	begin
		execute immediate 
			'update REGISTRY$DATABASE set TZ_VERSION_UPGRADE = :1' using V_NEWDBTZV;
		EXCEPTION 
			when OTHERS then 
					DBMS_OUTPUT.PUT_LINE('ERROR: something went wrong updating TZ_VERSION_UPGRADE REGISTRY$DATABASE');
					V_ERRCODE := SQLCODE;
					V_ERRMSG := SUBSTR(SQLERRM,1,140);
					DBMS_OUTPUT.PUT_LINE('Error code ' || V_ERRCODE || ': ' || V_ERRMSG);
					RAISE_APPLICATION_ERROR(-20016,'Stopping script - see previous message .....');
	end;
commit;

-- Check if DST_UPGRADE_STATE is PREPARE
	begin
		execute immediate
			'select substr(PROPERTY_VALUE, 1, 10) from DATABASE_PROPERTIES where PROPERTY_NAME = ''DST_UPGRADE_STATE''' into V_CHECKVAR1;
		if V_CHECKVAR1 = 'PREPARE' then
				null;
			else
				DBMS_OUTPUT.PUT_LINE('ERROR: Current DST_UPGRADE_STATE is '||  V_CHECKVAR1 || ' !');
				DBMS_OUTPUT.PUT_LINE('ERROR: DST_UPGRADE_STATE in DATABASE_PROPERTIES need to be PREPARE');
				DBMS_OUTPUT.PUT_LINE('ERROR: after a DBMS_DST.BEGIN_PREPARE.');
				DBMS_OUTPUT.PUT_LINE('ERROR: See note 977512.1 for 11gR2 or note 1509653.1 for 12c .');
				RAISE_APPLICATION_ERROR(-20017,'Stopping script - see previous message .....');
		end if;
	end;

-- End block
end;
/

-- Say what we do next		
EXEC DBMS_OUTPUT.PUT_LINE('INFO: Next step is checking all TSTZ data.');
EXEC DBMS_OUTPUT.PUT_LINE('INFO: It might take a while before any further output is seen ...');

-- Start check on data
set TERMOUT off

-- Clean up used objects
truncate table SYS.DST$TRIGGER_TABLE;
truncate table SYS.DST$AFFECTED_TABLES;
truncate table SYS.DST$ERROR_TABLE;

set TERMOUT on
set FEEDBACK off

-- Need catch here for ORA-01882: timezone region not found -> if seen run the 
-- Fix1882.sql script found in Note 414590.1 using the server home sqlplus and then retry
-- If this happens DBMS_DST.END_PREPARE need be called before exiting
declare

	V_NEWDBTZV				number;
	V_CHECKNUM1				number;
	V_CHECKVAR1				varchar2(10 char);
	V_ERRCODE				number;
    V_ERRMSG				varchar2(140 char);
	V_NUMFAIL				number;
	INVALID_TIMEZONE       	EXCEPTION;
	PRAGMA EXCEPTION_INIT(INVALID_TIMEZONE, -1882); 

begin
	begin
		DBMS_DST.FIND_AFFECTED_TABLES
		(AFFECTED_TABLES => 'SYS.DST$AFFECTED_TABLES',
		LOG_ERRORS => true,
		LOG_ERRORS_TABLE => 'SYS.DST$ERROR_TABLE');
		EXCEPTION
			when INVALID_TIMEZONE then
				DBMS_OUTPUT.PUT_LINE('ERROR: ORA-01882 was detected during FIND_AFFECTED_TABLES.');
				DBMS_OUTPUT.PUT_LINE('ERROR: Make sure to run this script using the database home sqlplus.');
				DBMS_OUTPUT.PUT_LINE('ERROR: If this error is seen using the database home sqlplus');					
				DBMS_OUTPUT.PUT_LINE('ERROR: then run the Fix1882.sql script found in Note 414590.1 ');
				DBMS_OUTPUT.PUT_LINE('ERROR: using the server home sqlplus.');
				DBMS_OUTPUT.PUT_LINE('ERROR: And then run upg_tzv_check.sql again.');
				DBMS_OUTPUT.PUT_LINE('ERROR: If this error persists log an SR.');	
				DBMS_DST.END_PREPARE;
				RAISE_APPLICATION_ERROR(-20018,'Stopping script - see previous message .....');
			when OTHERS then
				DBMS_OUTPUT.PUT_LINE('ERROR: Something went wrong during DBMS_DST.FIND_AFFECTED_TABLES.');
				DBMS_DST.END_PREPARE;
				V_ERRCODE := SQLCODE;
				V_ERRMSG := SUBSTR(SQLERRM,1,140);
				DBMS_OUTPUT.PUT_LINE('Error code ' || V_ERRCODE || ': ' || V_ERRMSG);
				RAISE_APPLICATION_ERROR(-20019,'Stopping script - see previous message .....');
	end;
	
-- If this gives count(*) > 0 then issue warning
	begin
		execute immediate
         'SELECT count(*) FROM SYS.DST$ERROR_TABLE where ERROR_NUMBER in (''1878'',''1883'')'  into V_CHECKNUM1 ;
			if V_CHECKNUM1 != TO_NUMBER('0') then
				DBMS_OUTPUT.PUT_LINE('WARNING: Some TSTZ data that needs adjusting is detected');
				DBMS_OUTPUT.PUT_LINE('WARNING: during FIND_AFFECTED_TABLES.');		
				DBMS_OUTPUT.PUT_LINE('WARNING: This is error_on_overlap_time and error_on_nonexisting_time data.');
				DBMS_OUTPUT.PUT_LINE('WARNING: For more information see ');
				DBMS_OUTPUT.PUT_LINE('WARNING: note 977512.1 for 11gR2 or note 1509653.1 for 12c .');				
				DBMS_OUTPUT.PUT_LINE('WARNING: This is a message in case you want to check this data manually.' );
				DBMS_OUTPUT.PUT_LINE('WARNING: The upg_tzv_apply.sql script will adjust this data automatically.' );
				DBMS_OUTPUT.PUT_LINE('WARNING: It will not stop the DST upgrade.' );					
			end if;
	end;		

	-- If this gives count(*) > 0 then error ask the 1882 script be be runn
	begin
		execute immediate
         'SELECT count(*) FROM SYS.DST$ERROR_TABLE where ERROR_NUMBER in (''1882'')'  into V_CHECKNUM1 ;
			if V_CHECKNUM1 != TO_NUMBER('0') then
				DBMS_OUTPUT.PUT_LINE('ERROR: ORA-01882 was detected during FIND_AFFECTED_TABLES.');
				DBMS_OUTPUT.PUT_LINE('ERROR: Make sure to run this script using the database home sqlplus.');
				DBMS_OUTPUT.PUT_LINE('ERROR: If this error is seen using the database home sqlplus');					
				DBMS_OUTPUT.PUT_LINE('ERROR: then run the Fix1882.sql script found in Note 414590.1 ');
				DBMS_OUTPUT.PUT_LINE('ERROR: using the server home sqlplus.');
				DBMS_OUTPUT.PUT_LINE('ERROR: And then run upg_tzv_check.sql again.');
				DBMS_OUTPUT.PUT_LINE('ERROR: If this error persists log an SR.');					
				DBMS_DST.END_PREPARE;
				RAISE_APPLICATION_ERROR(-20020,'Stopping script - see previous message .....');
			end if;
	end;
	
-- If this gives count(*) > 0 then error - go manual
	begin
		execute immediate
         'SELECT count(*) FROM SYS.DST$ERROR_TABLE where ERROR_NUMBER not in (''1878'',''1883'',''1882'')'  into V_CHECKNUM1 ;
			if V_CHECKNUM1 != TO_NUMBER('0') then
				DBMS_OUTPUT.PUT_LINE('ERROR: Some data that cannot be handled automatically ');
				DBMS_OUTPUT.PUT_LINE('ERROR: was detected during FIND_AFFECTED_TABLES.');
				DBMS_OUTPUT.PUT_LINE('ERROR: Do a manual DST update and checks as documented in ');
				DBMS_OUTPUT.PUT_LINE('ERROR: note 977512.1 for 11gR2 or note 1509653.1 for 12c .');
				DBMS_DST.END_PREPARE;
				RAISE_APPLICATION_ERROR(-20021,'Stopping script - see previous message .....');
			end if;
	end;
	

-- End the prepare window
DBMS_DST.END_PREPARE;
		
-- Check if DST_UPGRADE_STATE is NONE
	begin
		execute immediate
			'select substr(PROPERTY_VALUE, 1, 10) from DATABASE_PROPERTIES where PROPERTY_NAME = ''DST_UPGRADE_STATE''' into V_CHECKVAR1;
			if V_CHECKVAR1 = 'NONE' then
					null;
				else
					DBMS_OUTPUT.PUT_LINE('ERROR: Current DST_UPGRADE_STATE is '||  V_CHECKVAR1 || ' !');
					DBMS_OUTPUT.PUT_LINE('ERROR: DST_UPGRADE_STATE in DATABASE_PROPERTIES need to be NONE ');
					DBMS_OUTPUT.PUT_LINE('ERROR: after a DBMS_DST.END_PREPARE.');
					DBMS_OUTPUT.PUT_LINE('ERROR: See note 977512.1 for 11gR2 or note 1509653.1 for 12c.');
					RAISE_APPLICATION_ERROR(-20022,'Stopping script - see previous message .....');
			end if;
	end;


-- End message
		DBMS_OUTPUT.PUT_LINE('INFO: A newer RDBMS DST version than the one currently used is found.');
		DBMS_OUTPUT.PUT_LINE('INFO: Note that NO DST update was yet done.');
		DBMS_OUTPUT.PUT_LINE('INFO: Now run upg_tzv_apply.sql to do the actual RDBMS DST update.' );
		DBMS_OUTPUT.PUT_LINE('INFO: Note that the upg_tzv_apply.sql script will ' );
		DBMS_OUTPUT.PUT_LINE('INFO: restart the database 2 times WITHOUT any confirmation or prompt.' );
-- Check if db is RAC, if so warn to restart RAC DB in single instance if needed
	begin
		execute immediate
			'select upper(VALUE) from V$SYSTEM_PARAMETER where upper(NAME)=''CLUSTER_DATABASE''' into V_CHECKVAR1 ;
		if V_CHECKVAR1 = 'FALSE' then
				null;
			else
				DBMS_OUTPUT.PUT_LINE('WARNING: This RAC database is not started in single instance mode !');
				DBMS_OUTPUT.PUT_LINE('WARNING: Set cluster_database = false and start as single instance');
				DBMS_OUTPUT.PUT_LINE('WARNING: BEFORE running upg_tzv_apply.sql !');
				DBMS_OUTPUT.PUT_LINE('WARNING: This is REQUIRED to run upg_tzv_apply.sql !');
		end if;
	end;
	
-- End block
end;
/

-- uncomment to print time it took
EXEC :V_SEC := (DBMS_UTILITY.GET_TIME - :V_SEC)/100
-- EXEC DBMS_OUTPUT.PUT_LINE('INFO: Total Seconds elapsed : '||:V_SEC)

whenever SQLERROR continue
set TERMOUT on
set FEEDBACK on
-- End of upg_tzv_check.sql
