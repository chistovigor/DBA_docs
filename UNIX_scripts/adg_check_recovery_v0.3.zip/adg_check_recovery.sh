#!/bin/bash
# ADG status check. Restarts standby database if it was unable to start after node crash
# adg_check_recovery.sh version 0.3
# See Bug 20484760 : ACTIVE DATAGUARD REQUESTING AN ACTIVE LOG AND CRASHED WITH ORA-10458
# lmikhailov@jet.su


##################################################################################################
#Checks...

if [ "$#" -ne 1 ] ; then
  echo "ERROR: No database name found!"
  echo "Usage: $0 DBNAME" >&2
  exit 1
fi

#DB_NAME=dbmstb02
DB_NAME=$1
DBENV_PATH=/home/oracle/.set$DB_NAME
#DBENV_PATH=/home/oracle/.setdbm021
ASMENV_PATH=/home/oracle/.setASM
OLD_ERROR_FILE=/var/tmp/adg_check_recovery_$DB_NAME.conf
WARNING_FILE=/home/oracle/RESTART_ADG_MANUALLY_$DB_NAME.txt

echo
echo "Starting ADG check for $DB_NAME"
date
echo

. $DBENV_PATH
#ALERT_LOG_PATH=/u01/app/oracle/diag/rdbms/dbmstb02/dbmstb02/trace/alert_dbmstb02.log
ALERT_LOG_PATH=$ORACLE_BASE/diag/rdbms/$DB_NAME/$DB_NAME/trace/alert_$DB_NAME.log

total_lines=`wc -l $ALERT_LOG_PATH | awk '{print $1;}'`
# echo $total_lines

err_line1=`grep -n "^Standby crash recovery failed to bring standby database to a consistent$" $ALERT_LOG_PATH | tail -1 | awk -F: '{print $1;}'`
#err_line2=`grep -n "^Standby Crash Recovery aborted due to error 10877.$" $ALERT_LOG_PATH | tail -1 | awk -F: '{print $1;}'`
#err_line3=`grep -n "^ORA-10458: standby database requires recovery$" $ALERT_LOG_PATH | tail -1 | awk -F: '{print $1;}'`
#good_line1=`grep -n "^Starting ORACLE instance (normal) (OS id" $ALERT_LOG_PATH | tail -1 | awk -F: '{print $1;}'`
good_line2=`grep -n "^Completed: ALTER DATABASE OPEN" $ALERT_LOG_PATH| tail -1 | awk -F: '{print $1;}'`

#echo err_line1=$err_line1
#echo err_line2=$err_line2
#echo err_line3=$err_line3
#echo good_line1=$good_line1
#echo good_line2=$good_line2



#Check file with error line for previosu restart
if [ -f "$OLD_ERROR_FILE" ]
then
   echo "File with record of previos restart found at $OLD_ERROR_FILE"
   old_err=$(< $OLD_ERROR_FILE) >/dev/null
else
   #echo "Old error file not found."
   echo
fi

#Check and cleanup warning file
if [ -f "$WARNING_FILE" ]
then
   echo "Removing old warning file $WARNING_FILE"
   rm $WARNING_FILE
fi

#Check alert log exists and is not empty
if [ "0$total_lines" -gt 0 ]; then
  echo "Alert log for database $DB_NAME file found."
else
  echo "Alert log file for $DB_NAME not found."
  echo "Looking for alert log at: ALERT_LOG_PATH=$ALERT_LOG_PATH"
  echo "Exiting..."
  exit 0
fi

#Look for line with error
if [ "0$err_line1" -gt 0 ]; then
  echo "Standby recovery error found in alert log at line $err_line1"
else
  echo "No recovery errors found in alert log"
  echo "Exiting..."
  exit 0
fi

#Check if this issue is recent
if [ $total_lines -lt $[$err_line1 + 1000] ]; then
   echo "Recent problem found"
   if [ "0$good_line2" -lt "$err_line1" ]; then
      echo "Database was not successfully restarted after problem"
   else
      echo "Database was already successfully restarted since last problem occurence, exinig..."
      exit 0
   fi
else
   echo "This is an old issue, no recent problems found, ignoring it and exiting ..."
   exit 0
fi

# Check database status in clusterware
# crsctl stat res ora.$DB_NAME.db -v
#
#Good state:
#STATE=ONLINE on var01vm01
#TARGET=ONLINE
#STATE_DETAILS=Open,Readonly
#INTERNAL_STATE=STABLE
#
#Wrong state:
#STATE=INTERMEDIATE on var01vm01
#TARGET=ONLINE
#STATE_DETAILS=Mounted (Closed)
#INTERNAL_STATE=STABLE

. $ASMENV_PATH
CRS_OUTPUT="$(crsctl stat res ora.$DB_NAME.db -v)"
while read -r line
do
    #echo "$line"
    VARNAME=`echo "$line" | awk -F= '{print $1;}'`
    VARVAL=`echo "$line" | awk -F= '{print $2;}'`
    #echo ">$VARNAME<"
    #echo ">$VARVAL<"
    if [ "$VARNAME" = "STATE" ]; then
      DB_STATE=`echo $VARVAL | awk '{print $1;}'`
    fi
    if [ "$VARNAME" = "TARGET" ]; then
      DB_TARGET=$VARVAL
    fi
    if [ "$VARNAME" = "STATE_DETAILS" ]; then
      DB_STATE_DETAILS=$VARVAL
    fi
done <<< "$CRS_OUTPUT"
#echo DB_STATE_DETAILS=$DB_STATE_DETAILS
#echo DB_TARGET=$DB_TARGET
#echo DB_STATE="$DB_STATE"

if ! [[ "$DB_STATE" = "INTERMEDIATE"  &&  "$DB_TARGET" = "ONLINE"  &&  "$DB_STATE_DETAILS" = "Mounted (Closed)" ]]; then
   echo "Database status in CRS does not look like this issue!"
   echo " DB_STATE_DETAILS=$DB_STATE_DETAILS"
   echo " DB_TARGET=$DB_TARGET"
   echo " DB_STATE="$DB_STATE""
   echo "Exiting..."
   exit 0
else
   echo "Found bad Database $DB_NAME status in CRS!"
   echo " DB_STATE_DETAILS=$DB_STATE_DETAILS"
   echo " DB_TARGET=$DB_TARGET"
   echo " DB_STATE="$DB_STATE""
fi

# Check if we already tried to restart Database for this issue
if [ "0$err_line1" == "0$old_err" ]; then
  echo "Found previous restart file."
  echo " $OLD_ERROR_FILE"
  echo "Looks that previous restart attempt didn't help."
  echo "Please restart database manually!"
  #Create warning file
  echo "Please restart database manually!" > $WARNING_FILE
  date >>  $WARNING_FILE
  exit 1
fi

#Check if warning file exists with error line for previous restart
if [ -f "$WARNING_FILE" ]
then
   echo "Removing old warning file $WARNING_FILE"
   rm $WARNING_FILE
fi


#Check database process is not running
pmon_is_running=`ps -ef | grep ora_pmon_$DB_NAME | grep -v grep | wc -l`

if [ "0$pmon_is_running" -eq 1 ]; then
   echo "Database process already running"
   ps -ef | grep ora_pmon_$DB_NAME | grep -v grep
   echo "Cannot start database, exiting..."
   exit 1
fi

#######################################################################################
#Problem exists, database is down, then trying starting database

echo "Staring database"

. $DBENV_PATH
srvctl start database -d $DB_NAME
echo
echo "Database $DB_NAME was started!"

#Saving last error location
echo $err_line1 >$OLD_ERROR_FILE

echo "Done with ADG check"
date
echo

