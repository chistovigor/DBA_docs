#!/bin/bash
BACKUP_PATH="/mnt/backup"
REMOTE_HOST="atmdb02int"
export ORACLE_HOME=/usr/oracle/product/10.2.0/db_1
export ORACLE_SID=lanit
export PATH=$PATH:$HOME/bin:$ORACLE_HOME/bin

echo "-----------------------------------------"
echo "***** Begin" `date '+%a %d.%m.%Y-%H:%M:%S'` "*****"
echo "-----------------------------------------"

name=`date +%Y%m%d`

#3) Moving backup to reserve

       EXEC="rsync -e ssh -avz --progress ${BACKUP_PATH}/${name} ${REMOTE_HOST}:/var/backup/backup"
       su rsync -c "${EXEC}"
       echo " "

       echo "Done!" `date '+%a %d.%m.%Y-%H:%M:%S'`
