#!/bin/bash

# mount cifs

start() {
        /sbin/mount.cifs '\\172.23.112.34\O$\Physical_backup\'  /mnt/data/oracle/rmbackup/ -o user='rualkd2',pass='Divergent1',dom='RAIFFEISEN',rw
        return 0
}

stop() {
        umount /mnt/data/oracle/rmbackup
        return 0
}

# See how we were called.
case "$1" in
  start)
        start
        ;;
  stop)
        stop
        ;;
  *)
        echo $"Usage: $0 {start|stop}"
        exit 1
esac

exit 0

