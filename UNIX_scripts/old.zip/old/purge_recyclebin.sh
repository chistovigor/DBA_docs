#!/bin/bash
ORACLE_HOME=/usr/oracle/product/10.2.0/db_1/
ORA_SID=lanit
export ORACLE_HOME
export ORA_SID
/usr/oracle/product/10.2.0/db_1/bin/sqlplus atmmonitor/notify@LANIT < /usr/local/bin/purge_recyclebin.sql
