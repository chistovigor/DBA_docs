#!/bin/bash
> /tmp/space_archivelog
echo `date +%d\.%m\.%Y\ %H\:%M` >> /tmp/space_archivelog
for i in `df -k /mnt/data/ | grep "/mnt/"  | awk '{print $3}'`
        do
                df -k /mnt/data/ | grep $i | awk '($3 < 31457280) {print $3,"\t",$4,"\t",$5;}'>> /tmp/space_archivelog
done

a=`cat /tmp/space_archivelog | wc -l`
if [ $a -gt 1 ];
 then  cat  /tmp/space_archivelog | mailx -s "`uname -n`  space_archivelog is LOW" RBRU-CardCenter_Notifications@raiffeisen.ru -c "iruafaa1@raiffeisen.ru,iruagov3@raiffeisen.ru";
fi
