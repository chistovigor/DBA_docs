sqlplus / as sysdba < /usr/local/bin/truncate_audit.sql
