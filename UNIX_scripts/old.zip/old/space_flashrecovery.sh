#!/bin/bash
> /tmp/space_flash
echo `date +%d\.%m\.%Y\ %H\:%M` >> /tmp/space_flash
for i in `du /mnt/data/oracle/flash_recovery_area/ | grep "flash_recovery_area/" | awk '{print $1}'`
        do
                du /mnt/data/oracle/flash_recovery_area/ | grep $i | awk '($1 > 38797312) {print $1\1024\1024,"\t",$2;}'>> /tmp/space_flash
done

a=`cat /tmp/space_flash | wc -l`
if [ $a -gt 1 ];
 then  cat  /tmp/space_flash | mailx -s "`uname -n`  space_flash is LOW" "iruafaa1@raiffeisen.ru";
fi
