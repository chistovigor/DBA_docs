delete from sys.aud$ where timestamp#=trunc(sysdate)-15+6/24;
commit;
