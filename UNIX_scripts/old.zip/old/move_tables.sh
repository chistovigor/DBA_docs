#!/bin/bash

sqlplus / as sysdba < /usr/local/bin/move_tables.sql
