
Oracle Database 11g Release 11.2.0.3.0

CORE Patch for Bug# 19396455 for Little-endian Platforms

This patch is RAC Rolling Installable 
Released: Wed Aug 27 05:32:04 2014
  
This document describes how you can install the CORE DST patch for bug#  19396455 on your Oracle Database 11g Release 11.2.0.3.0


 
(I) Prerequisites
--------------------
Before you install or deinstall the patch, ensure that you meet the following requirements:

Note: In case of an Oracle RAC environment, meet these prerequisites on each of the nodes.

1.	Ensure that the Oracle home on which you are installing the patch or from which you are rolling back the patch is Oracle Database 11g Release 11.2.0.3.0.

2.      Oracle recommends that you use the latest version available for 11g Release 11.2.0.3.0. If you do not have  OPatch 11g Release 11.2.0.3.0 or the latest version available for 11g Release 11.2.0.3.0,then download it from patch# 6880880 for 11.2.0.3.0 release.

	For information about OPatch documentation, including any known issues, see My Oracle Support Document 293369.1 OPatch documentation list:
	https://support.oracle.com/CSP/main/article?cmd=show&type=NOT&id=224346.1

3.	Ensure that you set (as the home user) the ORACLE_HOME environment variable to the Oracle home.

4.	Ensure that the $PATH definition has the following executables: make, ar, ld and nm. The location of these executables depends on your operating system. On many operating systems, they are located in /usr/ccs/bin.	

5.	Ensure that you verify the Oracle Inventory because OPatch accesses it to install the patches. To verify the inventory, run the following command.
       $ opatch lsinventory 
	Note:
	-	If this command succeeds, it will list the Top-Level Oracle Products and one-off patches if any that are installed in the Oralce Home.
			- Save the output so you have the status prior to the patch apply.
	-	If the command displays some errors, then contact Oracle Support and resolve the issue first before proceeding further.

6.	(Only for Installation) Maintain a location for storing the contents of the patch ZIP file. In the rest of the document, this location (absolute path) is referred to as <PATCH_TOP_DIR>. Extract the contents of the patch ZIP file to the location (PATCH_TOP_DIR) you have created above. To do so, run the following command:
	$ unzip -d <PATCH_TOP_DIR>  p19396455_112030_<Little-endian platform>.zip 


7.	(Only for Installation) Determine whether any currently installed interim patches conflict with this patch 19396455 as shown below:
	$ cd <PATCH_TOP_DIR>/19396455
	$ opatch prereq CheckConflictAgainstOHWithDetail -ph ./
	
	The report will indicate the patches that conflict with this patch and the patches for which the current 19396455 is a superset.
	
	Note:
	When OPatch starts, it validates the patch and ensures that there are no conflicts with the software already installed in the ORACLE_HOME. OPatch categorizes conflicts into the following types: 
	-	Conflicts with a patch already applied to the ORACLE_HOME that is a subset of the patch you are trying to apply  - In this case, continue with the patch installation because the new patch contains all the fixes from the existing patch in the ORACLE_HOME. The subset patch will automatically be rolled back prior to the installation of the new patch.
	-	Conflicts with a patch already applied to the ORACLE_HOME - In this case, stop the patch installation and contact Oracle Support Services.

8.	Ensure that you also meet the DST-specific prerequisites described in My Oracle Support note 412160.1 available at the following location. Failing to meet these prerequisites may result in corrupted timezone data in the database, which may not be possible to correct later.
	https://metalink.oracle.com/metalink/plsql/ml2_documents.showNOT?p_id=412160.1

	You will notice that the My Oracle Support note mandates you to install patch 7695070 for DSTv11 or higher, as a prerequisite, for all releases of Oracle Database, except for Oracle Database 10g 
	Release 2 (10.2.0.5) and Oracle Database 11g Release 2 (11.2.0.1.0) or higher. However, note that on Microsoft Windows platforms, instead of installing patch 7695070, you must install a Patch 
	Set Bundle that includes the fix for bug# 7695070. 



(II) Installation  
-----------------
To install the patch, follow these steps:

1.	If this is a RAC environment, install the  patch using the OPatch rolling (no downtime) installation method as the patch is rolling RAC installable. Refer to My Oracle Support Document 244241.1 Rolling Patch - OPatch Support for RAC. 

2.	Set your current directory to the directory where the patch is located and then run the OPatch utility by entering the following commands:

	$ cd <PATCH_TOP_DIR>/19396455

	$ opatch apply

3.	Verify whether the patch has been successfully installed by running the following command:

	$ opatch lsinventory




(III) Deinstallation
----------------------
Ensure to follow the Prerequsites (Section I). To deinstall the patch, follow these steps:

1.	Deinstall the patch by running the following command:

	$ opatch rollback -id 19396455

2.      Ensure that you verify the Oracle Inventory and compare the output with the one run before the patch installation and re-apply any patches that were rolled back as part of this patch apply. To verify the inventory, run the following command:

        $ opatch lsinventory 




 (IV) Bugs Fixed by This Patch
---------------------------------
The following are the bugs fixed by this patch:
  19396455: DST-23: DST UPDATE SEPTEMBER 2014 - TZDATA2014F


--------------------------------------------------------------------------
Copyright 2014, Oracle and/or its affiliates. All rights reserved.
--------------------------------------------------------------------------
