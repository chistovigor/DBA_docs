Oracle Database 11g Release 12.1.0.1.0
CORE DST Patch for Bug 19396455 for Little Endian Platforms
(RAC Rolling Installable)
Released: Sep 01, 2014

This document describes how you can install the CORE DST patch for bug 19396455 on your Oracle Database 11g Release 12.1.0.1.0.

(1) Prerequisites
---------------------
Before you install or deinstall the patch, ensure that you meet the following requirements:
Note: In case of an Oracle RAC environment, meet these prerequisites on each of the nodes.

1.      Ensure that the Oracle Database on which you are installing the patch or from which you are rolling back the patch is Oracle Database 11g Release 12.1.0.1.0.

2.      Oracle recommends you to use the latest version of OPatch.
        If you do not have the latest version, then follow the instructions outlined in the My Oracle Support note 224346.1 available at:
        https://support.oracle.com/CSP/main/article?cmd=show&type=NOT&id=224346.1

3.      Ensure that you set the ORACLE_HOME environment variable to the Oracle home of the Oracle Database.

4.      Ensure that you set the PATH environment variable to include the location of the unzip executable, and the <ORACLE_HOME>/bin and the <ORACLE_HOME>/OPatch directories present in the Oracle home of the Oracle Database.

5.      Ensure that you verify the Oracle Inventory because OPatch accesses it to install the patches. To verify the inventory, run the following command. If the command displays some errors, then contact Oracle Support and resolve the issue.
        $ opatch lsinventory

6.      Ensure that you also meet the DST-specific prerequisites described in My Oracle Support note 412160.1 available at the following location. Failing to meet these prerequisites may result in corrupted timezone data in the database, which may not be possible to correct later.
        https://metalink.oracle.com/metalink/plsql/ml2_documents.showNOT?p_id=412160.1

        You will notice that the My Oracle Support note mandates you to install patch 7695070 for DSTv11 or higher, as a prerequisite, for all releases of Oracle Database, except for Oracle Database 10g
        Release 2 (10.2.0.5) and Oracle Database 11g Release 2 (11.2.0.1.0) or higher. However, note that on Microsoft Windows platforms, instead of installing patch 7695070, you must install a Patch
        Set Bundle that includes the fix for bug# 7695070.


(2) Installation
-----------------
To install the patch, follow these steps:

1.      Maintain a location for storing the contents of the patch ZIP file. In the rest of the document, this location (absolute path) is referred to as <PATCH_TOP_DIR>.

2.      Extract the contents of the patch ZIP file to the location you created in Step (1). To do so, run the following command:
        $ unzip -d <PATCH_TOP_DIR> p19396455_121010_<Little Endian Platform>.zip

3.      Navigate to the <PATCH_TOP_DIR>/19396455 directory:
        $ cd <PATCH_TOP_DIR>/19396455

4.      Install the patch by running the following command:
        $ opatch apply

        Note:
        When OPatch starts, it validates the patch and ensures that there are no conflicts with the software already installed in the ORACLE_HOME of the Oracle Database. OPatch categorizes conflicts into
        the following types:
        -       Conflicts with a patch already applied to the ORACLE_HOME - In this case, stop the patch installation and contact Oracle Support Services.
        -       Conflicts with a patch already applied to the ORACLE_HOME that is a subset of the patch you are trying to apply  - In this case, continue with the patch installation because the new patch
                contains all the fixes from the existing patch in the ORACLE_HOME. The subset patch will automatically be rolled back prior to the installation of the new patch.



(3) Deinstallation
--------------------
To deinstall the patch, follow these steps:

1.      Navigate to the <PATCH_TOP_DIR>/19396455 directory:
        $ cd <PATCH_TOP_DIR>/19396455

2.      Deinstall the patch by running the following command:
        $ opatch rollback -id 19396455



(4) Bugs Fixed by This Patch
---------------------------------
The following are the bugs fixed by this patch:
  19396455: DST-23: DST UPDATE SEPTEMBER 2014 - TZDATA2014F

--------------------------------------------------------------------------
Copyright 2014, Oracle and/or its affiliates. All rights reserved.
--------------------------------------------------------------------------

