Rem
Rem $Header: utltzchk.sql  
Rem
Rem utltchk.sql
Rem
Rem Copyright (c) 2006, 2014 Oracle. All rights reserved.
Rem
Rem    NAME
Rem      utltzchk.sql - script to see if the Europe/Kaliningrad , Europe/Simferopol ,
Rem      Europe/Moscow, W-SU, Europe/Volgograd, Europe/Samara, 
Rem      Asia/Yekaterinburg, Asia/Omsk, Asia/Novosibirsk, Asia/Krasnoyarsk
Rem      Asia/Irkutsk, Asia/Yakutsk , Asia/Vladivostok, Asia/Sakhalin
Rem      Asia/Magadan, Asia/Kamchatka or Asia/Anadyr timezone 
Rem      is stored in TimeStamp with Time Zone columns
Rem      see note 1907147.1 for more information
Rem
Rem      This can be adapted to search for other timezones very easely, simply search and replace
Rem      the timezone names with the timezone you want to check for
Rem
Rem    NOTES
Rem      * This script will check if any of above timezone is stored in TSTZ data
Rem      * This script will *not* update any data.
Rem      * this script will drop and recreate sys.sys_tzuv2_temptab and
Rem        sys.sys_tzuv2_affected_regions, 2 tables that are to be used exclusivly
Rem        for DST upgrade checks.
Rem      * This script must be run using SQL*PLUS.
Rem      * You must be connected AS SYSDBA to run this script.
Rem
Rem
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    gvermeir   08/08/14 - corrected based on tzdata2014f release
Rem    gvermeir   08/04/14 - adapted for Russia going to dst again
Rem    gvermeir   03/18/11 - adapted for Russia
Rem    gvermeir   03/18/11 - adapted for Turkey
Rem    gvermeir   07/26/10 - modified to be used as utlzchk.sql
Rem    gvermeir   06/28/10 - update for DSTv14 update
Rem    gvermeir   12/15/09 - update for DSTv13 update
Rem    gvermeir   06/18/09 - corrected 9i detection
Rem    gvermeir   06/16/09 - update for DSTv11 update
Rem    gvermeir   12/19/08 - update for DSTv10 update
Rem    gvermeir   03/04/08 - added missing timezones to V7 routine
Rem    gvermeir   02/06/08 - changed cursor to handle tables with non-uppercase column names
Rem    gvermeir   02/04/08 - changed dstv7 detection routine for 92 to avoid bug 4616093
Rem    gvermeir   01/21/08 - added nested table check for 10g and up and minor cleanup
Rem    gvermeir   01/03/08 - changed to search for upgrade to v7 to find Argentina changes
Rem    gvermeir   12/06/07 - changed to search for upgrade to v7 to find AU/Brazil/Egypt/Venezulea changes
Rem    gvermeir   12/05/07 - removed incorrect suggestion to backup data trough exp/imp
Rem    gvermeir   12/01/07 - changed detection routine of current DST files version to more flexible one
Rem    gvermeir   07/25/07 - changed to search for upgrade to v6 to find NZ changes and made generic for 9i and up
Rem    huagli     06/25/07 - bug 6141905 timezone updates V5
Rem    huagli     06/25/07 - Creation
Rem
-- Alter session to avoid performance issues
alter session set nls_sort='BINARY';

SET SERVEROUTPUT ON
set TERMOUT on

-- Check if user is sys
whenever SQLERROR EXIT

declare
	V_CHECKVAR1				varchar2(10 char);
begin
		execute immediate
		'select substr(SYS_CONTEXT(''USERENV'',''CURRENT_USER''),1,10) from dual' into V_CHECKVAR1 ;
		if V_CHECKVAR1 = 'SYS' then
				null;
			else
				DBMS_OUTPUT.PUT_LINE('ERROR: Current connection is not a sysdba connection!');
				RAISE_APPLICATION_ERROR(-20001,'Stopping script - see previous message .....');
		end if;
end;
/

whenever SQLERROR continue
Rem=========================================================================
Rem Recreate any existing table with this name sys.sys_tzuv2_temptab
Rem this table will hold any possible affected rows
Rem=========================================================================
DROP TABLE sys.sys_tzuv2_temptab purge
/
CREATE TABLE sys.sys_tzuv2_temptab
(
 table_owner  VARCHAR2(30),
 table_name   VARCHAR2(30),
 column_name  VARCHAR2(30),
 rowcount     NUMBER,
 nested_tab   VARCHAR2(3)
)
/

Rem========================================================================
Rem Recreate any existing table with this name sys.sys_tzuv2_affected_regions
Rem this table will hold affected timezonenames
Rem========================================================================
DROP TABLE sys.sys_tzuv2_affected_regions purge
/
CREATE TABLE sys.sys_tzuv2_affected_regions
(
 time_zone_name VARCHAR2(60)
)
/

DECLARE

  dbv                  VARCHAR2(10);
  release              VARCHAR2(16);
  tznames_count        NUMBER;
  tznames_dist_count   NUMBER;
  dbtzv                VARCHAR2(5);
  numrows              NUMBER;
  TYPE cursor_t        IS REF CURSOR;
  cursor_tstz          cursor_t;
  tstz_owner           VARCHAR2(30);
  tstz_tname           VARCHAR2(30);
  tstz_qcname          VARCHAR2(4000);

BEGIN

  --========================================================================
  -- Make sure that only Release 9i to 12.1 uses this script
  --========================================================================

  SELECT substr(version,1,6), version INTO dbv, release FROM v$instance;

  IF dbv in ('8.1.7.','8.1.6.','8.1.5.','8.0.6.','8.0.5.','8.0.4.')
  THEN
    DBMS_OUTPUT.PUT_LINE('TIMEZONE data type was not supported in Release ' || release);
    DBMS_OUTPUT.PUT_LINE('No need to validate TIMEZONE data.');
    RETURN;
  END IF;

  IF dbv not in ('9.0.1.','9.2.0.','10.1.0','10.2.0','11.1.0','11.2.0','12.1.0')
  THEN
    DBMS_OUTPUT.PUT_LINE('Versions below 9.0.1 do not have TIMEZONE data and are not affected');
    DBMS_OUTPUT.PUT_LINE('See Note 412160.1 on Metalink');
   RETURN;
  END IF;

  --======================================================================
  -- Check the current timezone version.
  --======================================================================

 -- TZ version checks if db is 10g or 11g

IF dbv in ('10.1.0','10.2.0','11.1.0','11.2.0','12.1.0')
 THEN
    EXECUTE IMMEDIATE 'SELECT version FROM v$timezone_file' INTO dbtzv;
END IF;

 -- TZ version checks if db is 9i
 -- In 9i there is no way to catch if the TZ files are newer then the latest DST patch version
 -- at the time this script was made, wich is DSTv11
 -- For DSTv8 and up it's assumed the large timezone file
 -- (standard in 9.2.0.5 and up when ORA_TZFILE is NOT set) is used.

-- checking if V7 (or higher) is used in 9i

IF dbv in ('9.0.1.','9.2.0.')
  THEN
     EXECUTE IMMEDIATE 'SELECT CASE TO_NUMBER(TO_CHAR(TO_TIMESTAMP_TZ
                               (''20080405 23:00:00 Australia/Victoria'',''YYYYMMDD HH24:MI:SS TZR'') +
                               to_dsinterval(''0 08:00:00''),''HH24''))
                        WHEN 7 THEN 6
                        WHEN 6 THEN 7 END
                        FROM DUAL'
                        INTO dbtzv;
END IF;

-- DBMS_OUTPUT.PUT_LINE('temp version is ' || TO_CHAR(dbtzv) || '!');

-- checking if V6 is used in 9i

IF dbtzv = 6 and dbv in ('9.0.1.','9.2.0.')
  THEN
     EXECUTE IMMEDIATE 'SELECT CASE TO_NUMBER(TO_CHAR(TO_TIMESTAMP_TZ
                               (''20070929 23:00:00 NZ'',''YYYYMMDD HH24:MI:SS TZR'') +
                               to_dsinterval(''0 08:00:00''),''HH24''))
                        WHEN 7 THEN 5
                        WHEN 8 THEN 6 END
                        FROM DUAL'
                        INTO dbtzv;
END IF;

-- DBMS_OUTPUT.PUT_LINE('temp version is ' || TO_CHAR(dbtzv) || '!');

-- checking if V5 is used in 9i

IF dbtzv = 5 and dbv in ('9.0.1.','9.2.0.')
  THEN
     EXECUTE IMMEDIATE 'SELECT CASE TO_NUMBER(TO_CHAR(TO_TIMESTAMP_TZ
                               (''20070310 23:00:00 CUBA'',''YYYYMMDD HH24:MI:SS TZR'') +
                               to_dsinterval(''0 08:00:00''),''HH24''))
                        WHEN 7 THEN 4
                        WHEN 8 THEN 5 END
                        FROM DUAL'
                        INTO dbtzv;
END IF;

-- DBMS_OUTPUT.PUT_LINE('temp version is ' || TO_CHAR(dbtzv) || '!');

-- checking if V4 or lower is used in 9i
-- this will not change anymore, so using old routine for 9i

IF dbtzv = 4 and dbv in ('9.0.1.','9.2.0.')
  THEN
     EXECUTE IMMEDIATE 'SELECT COUNT(DISTINCT(tzname)), COUNT(tzname)
                     FROM v$timezone_names'
                     INTO tznames_dist_count, tznames_count;

      dbtzv := CASE
             WHEN tznames_dist_count in (183, 355, 347) THEN 1
             WHEN tznames_dist_count = 377 THEN 2
             WHEN (tznames_dist_count = 186 and tznames_count = 636) THEN 2
             WHEN (tznames_dist_count = 186 and tznames_count = 626) THEN 3
             WHEN tznames_dist_count in (185, 386) THEN 3
             WHEN (tznames_dist_count = 387 and tznames_count = 1438) THEN 3
             WHEN (tznames_dist_count = 391 and tznames_count = 1457) THEN 4
             WHEN (tznames_dist_count = 188 and tznames_count = 637) THEN 4
           END;
END IF;

-- DBMS_OUTPUT.PUT_LINE('temp version is ' || TO_CHAR(dbtzv) || '!');

-- checking if V8 is used or DSTv14 small file
-- no DST rules changed, only tz's added
-- The then 99 is the check if for DSTv >7 and < 14 the small file is used 

IF dbtzv = 7 and dbv in ('9.0.1.','9.2.0.')
  THEN
     EXECUTE IMMEDIATE 'SELECT COUNT(DISTINCT(tzname)), COUNT(tzname)
                     FROM v$timezone_names' 
                     INTO tznames_dist_count, tznames_count;
  
       dbtzv := CASE
             WHEN (tznames_dist_count = 519 and tznames_count = 1858) THEN 7
             WHEN (tznames_dist_count = 188 and tznames_count =  637) THEN 7
             WHEN (tznames_dist_count = 199 and tznames_count =  755) THEN 14
             WHEN (tznames_dist_count = 197 and tznames_count =  676) THEN 99
             WHEN (tznames_dist_count > 519 and tznames_count > 1858) THEN 8 
           END;
END IF;

-- DBMS_OUTPUT.PUT_LINE('temp version is ' || TO_CHAR(dbtzv) || '!');

-- checking if V9 is used

IF dbtzv = 8 and dbv in ('9.0.1.','9.2.0.')
  THEN
     EXECUTE IMMEDIATE 'SELECT CASE TO_NUMBER(TO_CHAR(TO_TIMESTAMP_TZ
                               (''20080531 23:00:00 Africa/Casablanca'',''YYYYMMDD HH24:MI:SS TZR'') +
                               to_dsinterval(''0 08:00:00''),''HH24''))
                        WHEN 8 THEN 9
                        WHEN 7 THEN 8 END
                        FROM DUAL'
                        INTO dbtzv;
END IF;

-- DBMS_OUTPUT.PUT_LINE('temp version is ' || TO_CHAR(dbtzv) || '!');

-- checking if V10, v11 , v13 or v14 is used
-- no need to check for DSTv12
-- no DST rules changed

IF dbtzv = 9 and dbv in ('9.0.1.','9.2.0.')
  THEN
     EXECUTE IMMEDIATE 'SELECT COUNT(DISTINCT(tzname)), COUNT(tzname)
                     FROM v$timezone_names'
                     INTO tznames_dist_count, tznames_count;
       dbtzv := CASE
             WHEN (tznames_dist_count = 548 and tznames_count = 1987) THEN 9
             WHEN (tznames_dist_count = 549 and tznames_count = 1992) THEN 10
             WHEN (tznames_dist_count = 551 and tznames_count = 2137) THEN 11
             WHEN (tznames_dist_count = 551 and tznames_count = 2141) THEN 13
             WHEN (tznames_dist_count = 556 and tznames_count = 2164) THEN 14
             WHEN (tznames_dist_count > 556 ) THEN 99
             WHEN (tznames_dist_count = 556 and tznames_count > 2164) THEN 99
        END;
END IF;

-- 99 is a catch to have always a result when things don't match
-- like when runned on a future DST version in 9i

-- DBMS_OUTPUT.PUT_LINE('temp version is ' || TO_CHAR(dbtzv) || '!');

IF dbtzv > 14 and dbv in ('9.0.1.','9.2.0.')
  THEN
     DBMS_OUTPUT.PUT_LINE('The exact DST version cannot be detected but is DSTv8 or higher ' ||
                          'please check manually the 9i DST version');
     DBMS_OUTPUT.PUT_LINE('Most likely you are using the small timezone file -ORA_TZFILE IS set-');
     DBMS_OUTPUT.PUT_LINE('Still checking for TSTZ data however..');
END IF;

IF dbtzv < 15 and dbv in ('9.0.1.','9.2.0.')
  THEN
DBMS_OUTPUT.PUT_LINE('Your current 9i timezone version is ' ||
                       TO_CHAR(dbtzv) || '!');
END IF;

-- if current version is already V23 or up there nothing to check

IF dbtzv >= 23
  THEN
     DBMS_OUTPUT.PUT_LINE('The current DST version is already version ' || dbtzv || '!');
     DBMS_OUTPUT.PUT_LINE('No need to validate TIMEZONE WITH TIMEZONE data for the Russian 2014 change');
     DBMS_OUTPUT.PUT_LINE('Please see Note 412160.1 on Metalink for other DST updates');
     RETURN;
END IF;

IF dbv in ('10.1.0','10.2.0','11.1.0','11.2.0','12.1.0')
  THEN
DBMS_OUTPUT.PUT_LINE('Your current timezone version is ' ||
                       TO_CHAR(dbtzv) || '!');
END IF;


--======================================================================
-- Get tables with columns defined as type TIMESTAMP WITH TIME ZONE.
--======================================================================

  OPEN cursor_tstz FOR
       'SELECT atc.owner, atc.table_name, atc.column_name ' ||
       'FROM   "ALL_TAB_COLS" atc, "ALL_TABLES" at ' ||
       'WHERE  data_type LIKE ''TIMESTAMP%WITH TIME ZONE''' ||
       'AND atc.owner = at.owner AND atc.table_name = at.table_name ' ||
       'ORDER BY atc.owner, atc.table_name, atc.column_name';


--======================================================================
-- Get all the affected time zones based on the current database time
-- zone version, and put them into a temporary table, sys_tzuv2_temptab.
--======================================================================

IF dbtzv >= 1

THEN
EXECUTE IMMEDIATE 'INSERT INTO sys.sys_tzuv2_affected_regions
SELECT ''Asia/Magadan'' FROM DUAL UNION ALL
SELECT ''W-SU'' FROM DUAL UNION ALL
SELECT ''Europe/Kaliningrad'' FROM DUAL UNION ALL
SELECT ''Europe/Moscow'' FROM DUAL UNION ALL
SELECT ''Europe/Simferopol'' FROM DUAL UNION ALL
SELECT ''Europe/Volgograd'' FROM DUAL UNION ALL
SELECT ''Asia/Yekaterinburg'' FROM DUAL UNION ALL
SELECT ''Asia/Omsk'' FROM DUAL UNION ALL
SELECT ''Asia/Novosibirsk'' FROM DUAL UNION ALL
SELECT ''Asia/Krasnoyarsk'' FROM DUAL UNION ALL
SELECT ''Asia/Irkutsk'' FROM DUAL UNION ALL
SELECT ''Asia/Yakutsk'' FROM DUAL UNION ALL
SELECT ''Asia/Vladivostok'' FROM DUAL UNION ALL
SELECT ''Asia/Khandyga'' FROM DUAL UNION ALL
SELECT ''Asia/Sakhalin'' FROM DUAL UNION ALL
SELECT ''Asia/Ust-Nera'' FROM DUAL';

END IF;

  EXECUTE IMMEDIATE 'ANALYZE TABLE sys.sys_tzuv2_affected_regions ' ||
                    'COMPUTE STATISTICS';

--======================================================================
-- Check regular table columns.
-- they have no value in the nested_tab column to avoid confusion
--======================================================================
  LOOP
       BEGIN
         FETCH cursor_tstz INTO tstz_owner, tstz_tname, tstz_qcname;
         EXIT WHEN cursor_tstz%NOTFOUND;

         EXECUTE IMMEDIATE
           'SELECT COUNT(1) FROM ' ||
            tstz_owner || '."' || tstz_tname || '" t_alias, ' ||
            ' sys.sys_tzuv2_affected_regions r ' ||
            ' WHERE UPPER(r.time_zone_name) = ' ||
               ' UPPER(TO_CHAR(t_alias."' || tstz_qcname || '", ''TZR'')) ' INTO numrows;

         IF numrows > 0 THEN
           EXECUTE IMMEDIATE ' INSERT INTO sys.sys_tzuv2_temptab VALUES (''' ||
             tstz_owner || ''',''' || tstz_tname || ''',''' ||
             tstz_qcname || ''',' || numrows || ', ''  '')';
         END IF;

       EXCEPTION
         WHEN OTHERS THEN
           DBMS_OUTPUT.PUT_LINE('OWNER : ' || tstz_owner);
           DBMS_OUTPUT.PUT_LINE('TABLE : ' || tstz_tname);
           DBMS_OUTPUT.PUT_LINE('COLUMN : ' || tstz_qcname);
           DBMS_OUTPUT.PUT_LINE(SQLERRM);
       END;
  END LOOP;

--======================================================================
-- Check nested table columns,only possible if 10g or higher.
-- these tables need manual check to see what data may be stored
-- we simply see if it's a TIMESTAMP WITH TIME ZONE datatype, not
-- if it actually contains affected data.
--======================================================================
IF dbv in ('10.1.0','10.2.0','11.1.0','11.2.0','12.1.0')
 THEN
  EXECUTE IMMEDIATE
    'INSERT INTO sys.sys_tzuv2_temptab
       SELECT owner, table_name, column_name, NULL, ''YES''
       FROM DBA_NESTED_TABLE_COLS
       WHERE data_type like ''TIMESTAMP%WITH TIME ZONE''';
END IF;

  DBMS_OUTPUT.PUT_LINE('.');
  DBMS_OUTPUT.PUT_LINE('Do a select * from sys.sys_tzuv2_temptab; to see if any ');
  DBMS_OUTPUT.PUT_LINE('TIMEZONE WITH TIMEZONE data is storing ');
  DBMS_OUTPUT.PUT_LINE('Russian named timezones ');
  DBMS_OUTPUT.PUT_LINE('.');
  DBMS_OUTPUT.PUT_LINE('Any table with YES in the nested_tab column (last column) needs');
  DBMS_OUTPUT.PUT_LINE('a manual check as these are nested tables.');

END;
/

COMMIT
/

Rem=========================================================================
SET SERVEROUTPUT OFF
Rem=========================================================================
