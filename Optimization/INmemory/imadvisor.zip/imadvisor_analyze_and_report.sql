Rem
Rem $Header: rdbms/admin/imadvisor_analyze_and_report.sql jraitto_imadvisor_12_2_adefix/2 2016/08/15 12:09:13 jraitto Exp $
Rem
Rem imadvisor_analyze_and_report.sql
Rem
Rem Copyright (c) 2015, 2016, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      imadvisor_analyze_and_report.sql - Analyze the given workload and generate
Rem                                         report.
Rem
Rem    DESCRIPTION
Rem      Wrapper script on top of IMADVISOR PL/SQL API.
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/imadvisor_analyze_and_report.sql 
Rem    SQL_SHIPPED_FILE: 
Rem    SQL_PHASE: 
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: 
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    jraitto     03/25/16 - deprecate and replaced with
Rem                           imadvisor_recommendations.sql
Rem    jraitto     03/22/16 - check for ^C followed by re-run and abort
Rem    jraitto     03/21/16 - Continuing edits
Rem    jraitto     03/10/16 - Continuing edits
Rem    jraitto     03/01/16 - Continuing edits
Rem    jraitto     02/29/16 - Continuing edits
Rem    jraitto     02/24/16 - enhance
Rem    jraitto     08/06/15 - derived from imadvisor_analyze_and_report.sql
Rem                           (rdbms/src/server/svrman/im/) 1.0.0.0.1 build #540
Rem    jraitto     08/06/15 - Created, 1.0.0.0.1 build #540 history:
Rem    jraitto     05/22/15 - Add CDB/PDB support
Rem    jraitto     01/26/15 - Use new GENERATE_RECOMMENDATIONS interface
Rem    hpoduri     09/22/14 - Add a demo script on top of the PL/SQL API
Rem    hpoduri     09/22/14 - Created
Rem

PROMPT
PROMPT
PROMPT This script (imadvisor_analyze_and_report.sql) has been deprecated and replaced
PROMPT by interactive script imadvisor_recommendations.sql.
PROMPT
PROMPT Script imadvisor_analyze_and_report.sql previously supported the following:
PROMPT
PROMPT * Support Oracle Database 11.2.0.3 and later
PROMPT * Support live database workloads
PROMPT * Support use on non-CDBs, CDB roots and PDBs
PROMPT * Support a user-specified statistics capture window
PROMPT * Automatically transfer the recommendation files to the client
PROMPT
PROMPT Replacement script imadvisor_recommendations.sql supports all of the above plus
PROMPT the following enhancements:
PROMPT
PROMPT * Present a list of available augmented AWR workloads + support AWR or live
PROMPT * Present a list of RAC instances + support a specific instance choice
PROMPT * Present a list of IM sizes with performance estimates + support a size choice
PROMPT * Present a list of available tasks + quickly optimize for different IM sizes
PROMPT
PROMPT Next time you wish In-Memory Advisor recommendations, invoke
PROMPT imadvisor_recommendations.sql instead.
PROMPT
PROMPT
PROMPT This script will now invoke imadvisor_recommendations.sql for you...
PROMPT
PAUSE Press ENTER to continue

@@imadvisor_recommendations.sql

