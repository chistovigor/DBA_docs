Rem
Rem $Header: rdbms/admin/imadvisor_debug_switch.sql jraitto_imadvisor_12_2_adefix/1 2015/09/04 16:32:52 jraitto Exp $
Rem
Rem imadvisor_debug_switch.sql
Rem
Rem Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.
Rem
Rem    NAME
Rem      imadvisor_debug_switch.sql - enable/disable debug
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/imadvisor_debug_switch.sql 
Rem    SQL_SHIPPED_FILE: 
Rem    SQL_PHASE: 
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: 
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    jraitto     08/10/15 - derived from imadvisor_debug_switch.sql
Rem                           (rdbms/src/server/svrman/im) 1.0.0.0.1 build #540
Rem    jraitto     08/10/15 - Created, 1.0.0.0.1 build #540 history:
Rem    jraitto     06/28/15 - enable/disable debug
Rem    jraitto     06/28/15 - Created
Rem

-- @@?/rdbms/admin/sqlsessstart.sql

BEGIN
  dbms_inmemory_advisor.set_str_parameter$  (NULL, 'DEBUG','&&imadvisor_debug_enable');
  dbms_inmemory_advisor.set_str_parameter$  (NULL, 'DEBUG_SNAPSHOT','&&imadvisor_debug_snpshot_enable');
END;
/

UNDEFINE imadvisor_debug_enable;
UNDEFINE imadvisor_debug_snpshot_enable;

-- @?/rdbms/admin/sqlsessend.sql
