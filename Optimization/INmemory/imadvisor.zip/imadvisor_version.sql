--
-- $Header: rdbms/src/server/svrman/im/imadvisor_version.sql jraitto_imadvisor_12_2_adefix/23 2017/01/05 16:13:59 jraitto Exp $
--
-- imadvisor_version.sql
--
-- Copyright (c) 2014, 2017, Oracle and/or its affiliates. All rights reserved.
--
--    NAME
--      imadvisor_version.sql - Load table with IM Advisor version info
--
--    DESCRIPTION
--      <short description of component this file declares/defines>
--
--    NOTES
--      <other useful comments, qualifications, etc.>
--
--    BEGIN SQL_FILE_METADATA 
--    SQL_SOURCE_FILE: rdbms/src/server/svrman/im/imadvisor_version.sql 
--    SQL_SHIPPED_FILE: 
--    SQL_PHASE: 
--    SQL_STARTUP_MODE: NORMAL 
--    SQL_IGNORABLE_ERRORS: NONE 
--    SQL_CALLING_FILE: 
--    END SQL_FILE_METADATA
--
--    MODIFIED   (MM/DD/YY)
--    jraitto     01/05/17 - Continuing edits
--    jraitto     10/31/16 - Adjust to 12.2 AWR view changes
--    jraitto     06/08/16 - set version to 2.0.0.1.0
--    jraitto     05/31/16 - more html format changes
--    jraitto     12/18/15 - Continuing edits
--    jraitto     09/01/15 - Continuing edits
--    jraitto     08/28/15 - Continuing edits
--    jraitto     08/24/15 - Continuing edits
--    jraitto     08/17/15 - change object naming conventions
--    jraitto     07/10/15 - Add restriction: 12.1.0.1 PDB not supported
--                           (install and run on CDB root)
--    jraitto     07/06/15 - Continuing edits
--    jraitto     06/29/15 - bug 21312905
--    jraitto     06/24/15 - remove pre-release wording
--    jraitto     06/10/15 - fix references to dba_hist_ for PDBs
--    jraitto     06/09/15 - Continuing edits
--    jraitto     06/08/15 - add SQL DDL script to single-page
--    jraitto     06/03/15 - single-page html report option
--    jraitto     04/21/15 - CDB/PDB support
--    jraitto     03/27/15 - Bug 20434620
--    jraitto     02/27/15 - Continuing edits
--    jraitto     02/25/15 - Continuing edits
--    jraitto     02/16/15 - add debug to installation script
--    jraitto     02/13/15 - Continuing edits
--    jraitto     02/12/15 - Public release: remove pre-release stuff
--    jraitto     02/12/15 - bug 20526125
--    jraitto     02/11/15 - bug 20444598
--    jraitto     02/11/15 - bug 20517145
--    jraitto     02/10/15 - Continuing edits
--    jraitto     02/08/15 - Continuing edits
--    jraitto     02/05/15 - Continuing edits
--    jraitto     01/28/15 - Continuing edits
--    jraitto     01/27/15 - Update imadvisor_analyze_and_report.sql to use
--                           new generate_recommendations interface
--    jraitto     01/27/15 - bug 20421283
--    jraitto     01/27/15 - bug 20425300
--    jraitto     01/22/15 - Continuing edits
--    jraitto     01/16/15 - Continuing edits
--    jraitto     01/12/15 - remove erroneous NULLs in DB time
--    jraitto     01/09/15 - add imadvisor_fetch_recommendations.sql to kit
--    jraitto     01/08/15 - bug 20322681
--    jraitto     01/06/15 - Continuing edits
--    jraitto     12/29/14 - Continuing edits
--    jraitto     12/29/14 - Continuing edits
--    jraitto     12/01/14 - Continuing edits
--    jraitto     11/20/14 - Continuing edits
--    jraitto     11/20/14 - Continuing edits
--    jraitto     10/29/14 - Continuing edits
--    jraitto     10/21/14 - Continuing edits
--    jraitto     10/21/14 - bug 19862037
--    jraitto     10/20/14 - Continuing edits
--    jraitto     09/17/14 - bug 19434762
--    jraitto     09/29/14 - Continuing edits
--    jraitto     09/23/14 - add script imadvisor_analyze_and_report.sql to
--                           the .zip file
--    hpoduri     09/22/14 - Add a demo script on top of the PL/SQL API
--    jraitto     09/16/14 - bug 19608131
--    hpoduri     09/05/14 - fix view imadvisor_hist_ash_analytics
--    jraitto     09/04/14 - Continuing edits
--    hpoduri     08/29/14 - Bug Fixes, 19404480, 19468409
--    jraitto     08/27/14 - Continuing edits
--    jraitto     08/25/14 - Continuing edits
--    jraitto     08/15/14 - Continuing edits
--    jraitto     08/12/14 - more work on bug 19376950
--    jraitto     08/06/14 - Continuing edits
--    jraitto     08/04/14 - Continuing edits
--    jraitto     08/04/14 - Continuing edits
--    jraitto     08/01/14 - Continuing edits
--    jraitto     07/31/14 - Load table with IM Advisor version info
--    jraitto     07/31/14 - Created
--

  imadvisor_vers1         CONSTANT NUMBER :=
2 -- $$version_dot1$$
;
  imadvisor_vers2                CONSTANT NUMBER :=
0 -- $$version_dot2$$
;
  imadvisor_vers3             CONSTANT NUMBER :=
0 -- $$version_dot3$$
;
  imadvisor_vers4             CONSTANT NUMBER :=
1 -- $$version_dot4$$
;
  imadvisor_vers5             CONSTANT NUMBER :=
1 -- $$version_dot5$$
;
  imadvisor_buildnum          CONSTANT NUMBER :=
1222 -- $$build_number$$
;
  imadvisor_build_date        CONSTANT DATE :=
TO_DATE ('2017-01-12.18:29:02','YYYY-MM-DD.HH24:MI:SS') -- $$build_date$$
;

  imadvisor_build_db_version  CONSTANT VARCHAR2(100) :=
'12.2.0.2.0' -- $$build_db_version$$
;
  imadvisor_build_type        CONSTANT VARCHAR2(100) :=
'MOS Download' -- $$build_type$$
;
