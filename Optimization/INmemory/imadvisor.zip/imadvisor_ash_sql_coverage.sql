Rem
Rem $Header: rdbms/admin/imadvisor_ash_sql_coverage.sql jraitto_imadvisor_12_2_adefix/1 2015/09/04 16:32:52 jraitto Exp $
Rem
Rem imadvisor_ash_sql_coverage.sql
Rem
Rem Copyright (c) 2015, 2017, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      imadvisor_ash_sql_coverage.sql - Report percentage of SQL coverage of ASH data
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/imadvisor_ash_sql_coverage.sql 
Rem    SQL_SHIPPED_FILE: 
Rem    SQL_PHASE: 
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: 
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    jraitto     01/11/17 - remove sqlsessstart/end.sql calls
Rem    jraitto     08/10/15 - derived from ash_sql_coverage.sql
Rem                           (rdbms/src/server/svrman/im) 1.0.0.0.1 build #540
Rem    jraitto     08/10/15 - Created, 1.0.0.0.1 build #540 history:
Rem    jraitto     06/20/15 - Report percentage of SQL coverage of ASH data
Rem    jraitto     06/20/15 - Created

-- -- @@?/rdbms/admin/sqlsessstart.sql

SET SERVEROUTPUT ON;
DECLARE
  ash_sql_coverage  NUMBER;
BEGIN
  ash_sql_coverage :=
    dbms_inmemory_advisor.ash_sql_coverage_pct ('&&im_task_name');
  dbms_output.put_line
    ('Percentage of ASH data that has corresponding SQL plan data: '
     ||ash_sql_coverage||'%');
END;
/

-- -- @?/rdbms/admin/sqlsessend.sql
