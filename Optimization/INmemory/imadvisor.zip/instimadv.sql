Rem
Rem $Header: rdbms/src/server/svrman/im/instimadv.sql jraitto_imadvisor_12_2_adefix/5 2016/11/16 13:30:19 jraitto Exp $
Rem
Rem instimadv.sql
Rem
Rem Copyright (c) 2014, 2016, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      instimadv.sql - Installation script for DBMS_INMEMORY_ADVISOR
Rem
Rem    NOTES
Rem      See dbmsimadv.sql for more details.
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/src/server/svrman/im/instimadv.sql 
Rem    SQL_SHIPPED_FILE: 
Rem    SQL_PHASE: 
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: 
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    jraitto     11/15/16 - Enable debug to be turned on without editing this script
Rem    jraitto     10/31/16 - Adjust to 12.2 AWR view changes
Rem    jraitto     10/07/16 - remove grant on dbms_xslprocessor
Rem    jraitto     07/07/16 - remove imadvisor_emcc_13_0_0_0_compatibility.sql
Rem    jraitto     06/05/16 - Continuing edits
Rem    jraitto     06/03/16 - add @imadvisor_emcc_13_0_0_0_compatibility.sql
Rem    jraitto     04/25/16 - set schema to current_user at start
Rem    jraitto     03/31/16 - describe how to unsintall
Rem    jraitto     03/23/16 - Continuing edits
Rem    jraitto     02/23/16 - Continuing edits
Rem    jraitto     02/18/16 - move dbms_inmemory_advisor package to sys
Rem    jraitto     02/09/16 - Continuing edits
Rem    jraitto     02/03/16 - Continuing edits
Rem    jraitto     01/26/16 - name changes to go along with RDBMS integration
Rem    jraitto     12/14/15 - modify for version 1.0.0.0.2
Rem    jraitto     08/31/15 - Continuing edits
Rem    jraitto     08/17/15 - change object naming conventions
Rem    jraitto     08/13/15 - Continuing edits
Rem    jraitto     07/10/15 - Add restriction: 12.1.0.1 PDB not supported
Rem                           (install and run on CDB root)
Rem    jraitto     06/24/15 - remove pre-release wording
Rem    jraitto     06/22/15 - Continuing edits
Rem    jraitto     04/24/15 - CDB/PDB support
Rem    jraitto     02/25/15 - Continuing edits
Rem    jraitto     02/16/15 - add debug to installation script
Rem    jraitto     02/13/15 - Continuing edits
Rem    jraitto     02/12/15 - Public release: remove pre-release stuff
Rem    jraitto     02/12/15 - Continuing edits
Rem    jraitto     02/11/15 - bug 20444598
Rem    jraitto     02/06/15 - modify to make simple removal of pre-release
Rem                           wording
Rem    jraitto     01/27/15 - bug 20421283
Rem    jraitto     01/27/15 - bug 20425300
Rem    jraitto     01/22/15 - Continuing edits
Rem    jraitto     11/21/14 - remove imadvisor_objects (clone of dba_objects,
Rem                           no longer used)
Rem    jraitto     11/13/14 - remove PL/SQL encryption wrapper from files
Rem                           without substantial PL/SQL packages: the
Rem                           encryption does nothing to anonymous PL/SQL
Rem                           blocks
Rem    jraitto     10/22/14 - Continuing edits
Rem    jraitto     10/21/14 - bug 19862037
Rem    jraitto     10/09/14 - Continuing edits
Rem    jraitto     09/24/14 - enable installation with an imported workload
Rem    jraitto     08/20/14 - clone build versions of db views
Rem    jraitto     08/14/14 - Continuing edits
Rem    jraitto     08/06/14 - Continuing edits
Rem    jraitto     08/04/14 - bug 19352331
Rem    jraitto     08/01/14 - Continuing edits
Rem    jraitto     07/31/14 - Continuing edits
Rem    jraitto     07/22/14 - Continuing edits
Rem    jraitto     07/18/14 - Continuing edits
Rem    jraitto     07/17/14 - Continuing edits
Rem    jraitto     07/16/14 - install wrapped .plb files instead of .sql files
Rem    jraitto     06/20/14 - Continuing edits
Rem    jraitto     06/12/14 - Installation script for DBMS_INMEMORY_ADVISOR
Rem    jraitto     06/12/14 - Created
Rem

Rem Set debug_install=1 for debugging purposes only.
COLUMN debug_install NOPRINT NEW_VALUE debug_install;
SET TERMOUT OFF;
SELECT NULL AS debug_install FROM DUAL WHERE NULL IS NOT NULL;
SELECT NVL('&&debug_install','0') AS debug_install FROM DUAL;
SET TERMOUT ON;
COLUMN debug_install CLEAR;

SET SERVEROUTPUT ON;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
SET LINESIZE 100;
SET PAGESIZE 50000;
SET FEEDBACK OFF;
SET VERIFY   OFF;

BEGIN
  IF &&debug_install <> 0 THEN
    dbms_output.put_line ('Info: debug_install is enabled');
  END IF;
END;
/


DEFINE imadvisor_mos_download='T';

SET TERMOUT OFF;
COLUMN newvalue NOPRINT NEW_VALUE session_user;
SELECT SYS_CONTEXT('USERENV','SESSION_USER') AS newvalue FROM DUAL;
SET TERMOUT ON;
ALTER SESSION SET CURRENT_SCHEMA=&&session_user;

-- The following defines the Oracle Database username for the Oracle Database
-- In-Memory Advisor (DBMS_INMEMORY_ADVISOR) as IMADVISOR or, with a CDB-root,
-- C##IMADVISOR.
VARIABLE imadvisor_local_db_type VARCHAR2(10);
DECLARE
@@imadvisor_commoncode.sql
BEGIN
  :imadvisor_local_db_type := local_database_type();
  IF :imadvisor_local_db_type = 'PDB-seed' THEN
    RAISE_APPLICATION_ERROR (-20001,
'Installation of DBMS_INMEMORY_ADVISOR is not supported on PDB$SEED');
  END IF;
END;
/

SET TERMOUT OFF;
COLUMN imadvisor_username NOPRINT NEW_VALUE imadvisor_username;
SELECT DECODE (:imadvisor_local_db_type,
                 'CDB-root', 'C##IMADVISOR',
                 'IMADVISOR') AS imadvisor_username
FROM DUAL;
SET TERMOUT ON;

BEGIN
  IF &&debug_install <> 0 THEN
    dbms_output.put_line('Installation schema name: &&imadvisor_username');
  END IF;
END;
/

-- Note: MOS download versions 1.0.0.0.0 and 1.0.0.0.1 are uninstalled
-- using DROP USER [C##]IMADVISOR CASCADE.  This removes most of the
-- IM Advisor but leaves behind a DBMS_INMEMORY_ADVISOR public synonym.
-- This left-over synonym will not block installation of this MOS
-- download version because all synonyms use CREATE OR REPLACE SYNONYM...

DECLARE
  c1  NUMBER;
  c2  NUMBER;
  newline  CONSTANT VARCHAR2(1) := '
';
  CURSOR fragmented_installation IS
    SELECT   object_type, owner, object_name
    FROM     dba_objects
    WHERE    (  object_name LIKE 'DBMS_INMEMORY_ADVISOR%'
             OR object_name LIKE 'WRI$\_IMA\_%' ESCAPE '\'
             OR object_name LIKE 'INT$\_IMA\_%' ESCAPE '\'
             OR object_name LIKE 'DBA\_IMA\_%'  ESCAPE '\'
             OR object_name LIKE 'USER\_IMA\_%' ESCAPE '\'
             )
      AND    object_type <> 'SYNONYM'
    ORDER BY 1,2,3;

BEGIN

  SELECT COUNT(*) INTO c1
  FROM   dba_tables
  WHERE  table_name IN ('IMADVISOR_MANIFEST','WRI$_IMA_MANIFEST');
  SELECT COUNT(*) INTO c2
  FROM   dba_tables
  WHERE  owner = '&&imadvisor_username';

  IF c1 > 0 OR c2 > 0  THEN
    dbms_output.put_line ('DBMS_INMEMORY_ADVISOR is already installled.');
    dbms_output.put_line ('Installation aborting.');
    dbms_output.put_line ('If you wish to restart this installation:');
    dbms_output.put_line ('1.  Confirm that no data of any value exists with the current DBMS_INMEMORY_ADVISOR installation.');
    dbms_output.put_line ('2.  SQL> @catnoimadv.sql');
    RAISE_APPLICATION_ERROR (-20001, 'DBMS_INMEMORY_ADVISOR is already installled, aborting installation...');
  END IF;

  SELECT   COUNT(*) INTO c1
  FROM     dba_objects
    WHERE    (  object_name LIKE 'DBMS_INMEMORY_ADVISOR%'
             OR object_name LIKE 'WRI$\_IMA\_%' ESCAPE '\'
             OR object_name LIKE 'INT$\_IMA\_%' ESCAPE '\'
             OR object_name LIKE 'DBA\_IMA\_%'  ESCAPE '\'
             OR object_name LIKE 'USER\_IMA\_%' ESCAPE '\'
             )
      AND    object_type <> 'SYNONYM';

  IF c1 > 0 THEN
    dbms_output.put_line (newline||'The existence of the following objects indicates a partial, incomplete');
    dbms_output.put_line ('installation of Oracle Database In-Memory Advisor:'||newline);
    FOR fi IN fragmented_installation LOOP
      dbms_output.put_line (fi.object_type||' '||fi.owner||'.'||fi.object_name);
    END LOOP;
    dbms_output.put_line (newline||'The above listed objects must be removed before this installation can continue.');
    dbms_output.put_line ('First try @catnoimadv.sql, then try this installation again.');
    dbms_output.put_line ('If that does not work, confirm that the above listed objects are not needed.');
    dbms_output.put_line ('Then DROP them and try this installation again.'||newline);
    RAISE_APPLICATION_ERROR (-20001, 'Oracle Database In-Memory Advisor is partially installled, aborting installation...');
  END IF;

END;
/

-- The following privileges are required by the Oracle Database In-Memory Advisor
-- (DBMS_INMEMORY_ADVISOR).  The Oracle database installation user (the current
-- user) must have adminstration over these privileges in order to create the
-- DBMS_INMEMORY_ADVISOR database user and grant these privileges.
VARIABLE imadvisor_sysprivs             VARCHAR2(4000);
VARIABLE imadvisor_select_grants        VARCHAR2(4000);
VARIABLE imadvisor_sel_grant_opts       VARCHAR2(4000);
VARIABLE imadvisor_opt_write_dir_grants VARCHAR2(4000);
VARIABLE imadvisor_select_grants_12101  VARCHAR2(4000);
VARIABLE imadvisor_select_grants_12102  VARCHAR2(4000);
VARIABLE imadvisor_execute_grants       VARCHAR2(4000);
VARIABLE imadvisor_execute_grants_12102 VARCHAR2(4000);
VARIABLE imadvisor_select_grants_12201  VARCHAR2(4000);
BEGIN
  :imadvisor_sysprivs       :=
    'CREATE TABLE,'
  ||'CREATE VIEW,'
  ||'CREATE PROCEDURE,'
  ||'UNLIMITED TABLESPACE,'
  ||'CREATE SEQUENCE,'
  ||'CREATE SYNONYM,'
  ||'CREATE PUBLIC SYNONYM,'
  ||'ADVISOR,'
  ||'ADMINISTER ANY SQL TUNING SET';

  :imadvisor_select_grants  :=
    'sys.v_$instance,'
  ||'sys.v_$parameter,'
  ||'sys.v_$active_session_history,'
  ||'sys.v_$advisor_current_sqlplan,'
  ||'sys.v_$sql,'
  ||'sys.v_$sqlarea,'
  ||'sys.v_$sqlarea_plan_hash,'
  ||'sys.v_$sqlcommand,'
  ||'sys.v_$sqlfn_arg_metadata,'
  ||'sys.v_$sqlfn_metadata,'
  ||'sys.v_$sqlpa_metric,'
  ||'sys.v_$sqlstats,'
  ||'sys.v_$sqlstats_plan_hash,'
  ||'sys.v_$sqltext,'
  ||'sys.v_$sqltext_with_newlines,'
  ||'sys.v_$sql_bind_capture,'
  ||'sys.v_$sql_bind_data,'
  ||'sys.v_$sql_bind_metadata,'
  ||'sys.v_$sql_cs_histogram,'
  ||'sys.v_$sql_cs_selectivity,'
  ||'sys.v_$sql_cs_statistics,'
  ||'sys.v_$sql_cursor,'
  ||'sys.v_$sql_feature,'
  ||'sys.v_$sql_feature_dependency,'
  ||'sys.v_$sql_feature_hierarchy,'
  ||'sys.v_$sql_hint,'
  ||'sys.v_$sql_join_filter,'
  ||'sys.v_$sql_monitor,'
  ||'sys.v_$sql_optimizer_env,'
  ||'sys.v_$sql_plan,'
  ||'sys.v_$sql_plan_monitor,'
  ||'sys.v_$sql_plan_statistics,'
  ||'sys.v_$sql_plan_statistics_all,'
  ||'sys.v_$sql_redirection,'
  ||'sys.v_$sql_shared_cursor,'
  ||'sys.v_$sql_shared_memory,'
  ||'sys.v_$sql_workarea,'
  ||'sys.v_$sql_workarea_active,'
  ||'sys.v_$sql_workarea_histogram,'
  ||'sys.v_$instance,'
  ||'sys.v_$version,'
  ||'sys.v_$listener_network,'
  ||'sys.gv_$instance,'
  ||'sys.gv_$parameter,'
  ||'sys.gv_$active_session_history,'
  ||'sys.gv_$advisor_current_sqlplan,'
  ||'sys.gv_$sql,'
  ||'sys.gv_$sqlarea,'
  ||'sys.gv_$sqlarea_plan_hash,'
  ||'sys.gv_$sqlcommand,'
  ||'sys.gv_$sqlfn_arg_metadata,'
  ||'sys.gv_$sqlfn_metadata,'
  ||'sys.gv_$sqlpa_metric,'
  ||'sys.gv_$sqlstats,'
  ||'sys.gv_$sqlstats_plan_hash,'
  ||'sys.gv_$sqltext,'
  ||'sys.gv_$sqltext_with_newlines,'
  ||'sys.gv_$sql_bind_capture,'
  ||'sys.gv_$sql_bind_data,'
  ||'sys.gv_$sql_bind_metadata,'
  ||'sys.gv_$sql_cs_histogram,'
  ||'sys.gv_$sql_cs_selectivity,'
  ||'sys.gv_$sql_cs_statistics,'
  ||'sys.gv_$sql_cursor,'
  ||'sys.gv_$sql_feature,'
  ||'sys.gv_$sql_feature_dependency,'
  ||'sys.gv_$sql_feature_hierarchy,'
  ||'sys.gv_$sql_hint,'
  ||'sys.gv_$sql_join_filter,'
  ||'sys.gv_$sql_monitor,'
  ||'sys.gv_$sql_optimizer_env,'
  ||'sys.gv_$sql_plan,'
  ||'sys.gv_$sql_plan_monitor,'
  ||'sys.gv_$sql_plan_statistics,'
  ||'sys.gv_$sql_plan_statistics_all,'
  ||'sys.gv_$sql_redirection,'
  ||'sys.gv_$sql_shared_cursor,'
  ||'sys.gv_$sql_shared_memory,'
  ||'sys.gv_$sql_workarea,'
  ||'sys.gv_$sql_workarea_active,'
  ||'sys.gv_$sql_workarea_histogram,'
  ||'sys.gv_$instance,'
  ||'sys.gv_$version,'
  ||'sys.gv_$listener_network,'
  ||'sys.gv_$database,'
  ||'sys.dba_users,'
  ||'sys.dba_objects,'
  ||'sys.dba_tablespaces,'
  ||'sys.dba_hist_active_sess_history,'
  ||'sys.dba_hist_seg_stat_obj,'
  ||'sys.dba_hist_seg_stat,'
  ||'sys.dba_part_tables,'
  ||'sys.dba_tab_partitions,'
  ||'sys.dba_tab_subpartitions,'
  ||'sys.dba_tab_columns,'
  ||'sys.dba_lobs,'
  ||'sys.dba_external_tables,'
  ||'sys.dba_views,'
  ||'sys.dba_hist_sqlstat,'
  ||'sys.dba_hist_sqltext,'
  ||'sys.dba_hist_sql_plan,'
  ||'sys.dba_advisor_sqla_wk_map,'
  ||'sys.dba_sqlset,'
  ||'sys.dba_sqlset_statements,'
  ||'sys.dba_sqlset_plans,'
  ||'sys.dba_advisor_tasks,'
  ||'sys.dba_directories,'
  ||'sys.dba_sys_privs';

  :imadvisor_sel_grant_opts :=
    'sys.dba_hist_snapshot,'
  ||'sys.dba_tables,'
  ||'sys.v_$database';

  :imadvisor_opt_write_dir_grants :=
    'data_pump_dir';

  :imadvisor_select_grants_12101  :=
    'sys.cdb_users,'
  ||'sys.cdb_objects,'
  ||'sys.cdb_tablespaces,'
  ||'sys.cdb_hist_snapshot,'
  ||'sys.cdb_hist_active_sess_history,'
  ||'sys.cdb_hist_seg_stat_obj,'
  ||'sys.cdb_hist_seg_stat,'
  ||'sys.cdb_part_tables,'
  ||'sys.cdb_tab_partitions,'
  ||'sys.cdb_tab_subpartitions,'
  ||'sys.cdb_tables,'
  ||'sys.cdb_tab_columns,'
  ||'sys.cdb_lobs,'
  ||'sys.cdb_external_tables,'
  ||'sys.cdb_views,'
  ||'sys.cdb_hist_sqlstat,'
  ||'sys.cdb_hist_sqltext,'
  ||'sys.cdb_hist_sql_plan,'
  ||'sys.cdb_advisor_sqla_wk_map,'
  ||'sys.cdb_sqlset,'
  ||'sys.cdb_sqlset_statements,'
  ||'sys.cdb_sqlset_plans,'
  ||'sys.cdb_advisor_tasks,'
  ||'sys.cdb_directories,'
  ||'sys.cdb_pdbs,'
  ||'sys.cdb_pdb_history';
  :imadvisor_select_grants_12102  :=
    'sys.v_$inmemory_area,'
  ||'sys.gv_$inmemory_area';

  :imadvisor_execute_grants  := 
    'dbms_lob,'
  ||'dbms_advisor,'
  ||'dbms_sqltune,'
  ||'dbms_output,'
  ||'dbms_datapump,'
  ||'dbms_utility,'
  ||'dbms_lock,'
  ||'dbms_stats';

  :imadvisor_execute_grants_12102  := 
    'dbms_compression';

  :imadvisor_select_grants_12201   :=
    'sys.awr_root_snapshot,'
  ||'sys.awr_root_active_sess_history,'
  ||'sys.awr_root_sql_plan,'
  ||'sys.awr_root_sqltext,'
  ||'sys.awr_root_sqlstat,'
  ||'sys.awr_root_seg_stat,'
  ||'sys.awr_pdb_snapshot,'
  ||'sys.awr_pdb_active_sess_history,'
  ||'sys.awr_pdb_sql_plan,'
  ||'sys.awr_pdb_sqltext,'
  ||'sys.awr_pdb_sqlstat,'
  ||'sys.awr_pdb_seg_stat';

END;
/

-- The imadvisor_install package is a temporary package that contains utilities
-- for installing DBMS_INMEMORY_ADVISOR.  It is dropped at the end of
-- installation.
CREATE OR REPLACE PACKAGE imadvisor_installation IS
  PROCEDURE dbg (line IN VARCHAR2);
  PROCEDURE clear_failure;
  FUNCTION  failure_occurred RETURN BOOLEAN;
  PROCEDURE check_syspriv (syspriv IN VARCHAR2);
  PROCEDURE check_select_grant  (table_or_view IN VARCHAR2);
  PROCEDURE check_execute_grant (object_name   IN VARCHAR2);
  PROCEDURE process_item_list (list              IN VARCHAR2,
                               separator         IN VARCHAR2 := ',',
                               exec_action_part1 IN VARCHAR2 := NULL,
                               exec_action_part2 IN VARCHAR2 := NULL,
                               display           IN BOOLEAN  := FALSE,
                               with_count        IN BOOLEAN  := FALSE,
                               syspriv_check     IN BOOLEAN  := FALSE,
                               select_check      IN BOOLEAN  := FALSE,
                               execute_check     IN BOOLEAN  := FALSE,
                               optional          IN BOOLEAN  := FALSE);
  PROCEDURE display_item_list (list           IN VARCHAR2,
                               separator      IN VARCHAR2 := ',',
                               prefix_string  IN VARCHAR2 := NULL,
                               postfix_string IN VARCHAR2 := NULL);
  FUNCTION compare_versions (v1 IN VARCHAR2, v2 IN VARCHAR2) RETURN NUMBER;
  PROCEDURE grant_awr_augments (imadvisor_user IN VARCHAR2);

  -- Select functions and procedures from imadvisor_commoncode.sql:
  FUNCTION random_password RETURN VARCHAR2;

END imadvisor_installation;
/

CREATE OR REPLACE PACKAGE BODY imadvisor_installation IS

  failure BOOLEAN := FALSE;

  PROCEDURE dbg (line IN VARCHAR2) IS
  BEGIN
    IF &&debug_install <> 0 THEN
      dbms_output.put_line (line);
    END IF;
  END dbg;

  PROCEDURE assert (cond IN BOOLEAN, cond_str IN VARCHAR2) IS
  BEGIN
    IF NOT cond THEN
      RAISE_APPLICATION_ERROR (-20001, 'Internal error: This asserted condition is not true: '||cond_str);
    END IF;
  END assert;

  PROCEDURE clear_failure IS
  BEGIN
    failure := FALSE;
  END clear_failure;

  FUNCTION failure_occurred RETURN BOOLEAN IS
  BEGIN
    RETURN failure;
  END failure_occurred;

  PROCEDURE check_syspriv (syspriv IN VARCHAR2) IS
    c        NUMBER;
  BEGIN
    IF SUBSTR(syspriv, 1, LENGTH('INHERIT PRIVILEGES')) = 'INHERIT PRIVILEGES' THEN
      RETURN;
    END IF;
    SELECT COUNT(*) INTO c
    FROM   user_sys_privs
    WHERE  username  = SYS_CONTEXT('USERENV','SESSION_USER')
      AND  privilege = UPPER(syspriv);
    IF NVL(c,0) > 0 THEN
      RETURN;
    END IF;
    SELECT COUNT(*) INTO c
    FROM   user_role_privs rp, role_sys_privs rsp
    WHERE  rp.granted_role  = rsp.role
      AND  rsp.privilege    = UPPER(syspriv)
      AND  rownum           = 1;
    IF NVL(c,0) > 0 THEN
      RETURN;
    END IF;
    dbms_output.put_line ('Current user '||SYS_CONTEXT('USERENV','SESSION_USER')||' lacks system privilege privilege '||syspriv);
    failure := TRUE;
  END check_syspriv;

  PROCEDURE check_select_grant (table_or_view IN VARCHAR2) IS
    c   NUMBER;
  BEGIN
    EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM '||table_or_view||' WHERE NULL IS NOT NULL' INTO c;
  EXCEPTION
    WHEN OTHERS THEN
      IF SQLCODE = -942 THEN
        dbms_output.put_line ('Current user '||SYS_CONTEXT('USERENV','SESSION_USER')||' lacks GRANT SELECT ON '||table_or_view);
      ELSE
        dbms_output.put_line ('Current user '||SYS_CONTEXT('USERENV','SESSION_USER')||' cannot SELECT from '||table_or_view||': '||SQLERRM);
      END IF;
      failure := TRUE;
  END check_select_grant;

  PROCEDURE check_execute_grant (object_name   IN VARCHAR2) IS
  BEGIN
    NULL;
  END check_execute_grant;

  PROCEDURE process_item_list (list              IN VARCHAR2,
                               separator         IN VARCHAR2 := ',',
                               exec_action_part1 IN VARCHAR2 := NULL,
                               exec_action_part2 IN VARCHAR2 := NULL,
                               display           IN BOOLEAN  := FALSE,
                               with_count        IN BOOLEAN  := FALSE,
                               syspriv_check     IN BOOLEAN  := FALSE,
                               select_check      IN BOOLEAN  := FALSE,
                               execute_check     IN BOOLEAN  := FALSE,
                               optional          IN BOOLEAN  := FALSE) IS
    item_start  NUMBER := 1;
    item_len    NUMBER;
    item        VARCHAR2(32767);
    c           NUMBER := 0;
    newline     CONSTANT VARCHAR2(1) := '
';
  BEGIN
    WHILE (item_start < LENGTH(list)) LOOP
      c := c + 1;
      IF c > 1000000 THEN -- Infinite loop?
        RAISE_APPLICATION_ERROR (-20001, 'Internal error: Procedure process_item_list apparent infinite loop: '||c||' iterations');
      END IF;
      item_len := INSTR (SUBSTR(list, item_start), separator) - 1;
      IF item_len <= 0 THEN
        item_len := LENGTH(SUBSTR(list, item_start));
      END IF;
      item := SUBSTR(list, item_start, item_len);
      IF display THEN
        dbms_output.put_line (exec_action_part1 || item || exec_action_part2);
      ELSIF with_count THEN
        dbg ('process_item_list(with_count):' || exec_action_part1 || item || exec_action_part2);
        BEGIN
          EXECUTE IMMEDIATE exec_action_part1 || item || exec_action_part2 INTO c ;
        EXCEPTION
          WHEN OTHERS THEN
            IF optional THEN
              dbms_output.put_line ('Info: Optional command failed: ' || exec_action_part1 || item || exec_action_part2);
              dbms_output.put_line (SQLERRM);
            ELSE
              RAISE_APPLICATION_ERROR (-20001, 'Command failed: ' || exec_action_part1 || item || exec_action_part2 || newline || SQLERRM);
            END IF;
        END;
      ELSIF syspriv_check THEN
        check_syspriv (item);
      ELSIF select_check THEN
        check_select_grant (item);
      ELSIF execute_check THEN
        check_execute_grant (item);
      ELSE
        -- dbms_output.put_line ('EXECUTE IMMEDIATE ' || exec_action_part1 || item || exec_action_part2);
        dbg ('process_item_list:' || exec_action_part1 || item || exec_action_part2);
        BEGIN
          EXECUTE IMMEDIATE exec_action_part1 || item || exec_action_part2;
        EXCEPTION
          WHEN OTHERS THEN
            -- ORA-65058: object-specific CONTAINER_DATA attribute may only be
            -- specified for a CONTAINER_DATA
            IF SQLCODE = -65058 THEN
              -- Not all views require/allow this command:
              --   ALTER USER username SET CONTAINER_DATA=ALL FOR object_name
              --     CONTAINER=CURRENT
              NULL;
            ELSE
              IF optional THEN
                dbms_output.put_line ('Info: Optional command failed: ' || exec_action_part1 || item || exec_action_part2);
                dbms_output.put_line (SQLERRM);
              ELSE
                RAISE_APPLICATION_ERROR (-20001, 'Command failed: ' || exec_action_part1 || item || exec_action_part2 || newline || SQLERRM);
              END IF;
            END IF;
        END;
      END IF;
      item_start := item_start + item_len + 1;
    END LOOP;
  END process_item_list;

  PROCEDURE display_item_list (list           IN VARCHAR2,
                               separator      IN VARCHAR2 := ',',
                               prefix_string  IN VARCHAR2 := NULL,
                               postfix_string IN VARCHAR2 := NULL) IS
  BEGIN
    process_item_list (prefix_string, postfix_string, list, separator, display=>TRUE);
  END display_item_list;

--------------------------------------------------------------------------------
  FUNCTION compare_versions (v1 IN VARCHAR2, v2 IN VARCHAR2) RETURN NUMBER IS
  -- Compare version strings
  -- Return values:  -1 ==> v1 <  v2
  --                  0 ==> v1 == v2
  --                  1 ==> v1 >   v2
  -- Examples:
  -- v1=>'11.2.0.4', v2=>'11.1.0.2', return value=1
  -- v1=>'11.2.0.4', v2=>'11.1',     return value=1
  -- v1=>'11.2',     v2=>'11.1.0.2', return value=1
  -- v1=>'11.2.0.4', v2=>'11.2.0.4', return value=0
  -- v1=>'11.2.0.4', v2=>'11.2',     return value=0
  -- v1=>'11.2',     v2=>'11.2.0.4', return value=0
  -- v1=>'11.1.0.2', v2=>'11.2.0.4', return value=-1
  -- v1=>'11.1.0.2', v2=>'11.2',     return value=-1
  -- v1=>'11.1',     v2=>'11.2.0.4', return value=-1
    v1_start    NUMBER;
    v1_end      NUMBER;
    v1_num      NUMBER;
    v2_start    NUMBER;
    v2_end      NUMBER;
    v2_num      NUMBER;
  BEGIN
    -- This same function is also defined in prvtimadv.sql, package
    -- dbms_inmemory_advisor.  If you make changes here, please replicate
    -- the changes there.
    dbg ('compare_versions('||v1||','||v2||')');
    assert (v1 IS NOT NULL, 'v1 IS NOT NULL');
    assert (v2 IS NOT NULL, 'v2 IS NOT NULL');
    v1_start := 1;
    v2_start := 1;
    LOOP
      IF v1_start > LENGTH(v1) OR v2_start > LENGTH(v2) THEN
        dbg ('compare_versions: equivalent');
        RETURN 0;
      END IF;
      v1_end := INSTR (v1,'.',v1_start);
      v2_end := INSTR (v2,'.',v2_start);
      IF v1_end = 0 THEN
        v1_end := LENGTH(v1)+1;
      END IF;
      IF v2_end = 0 THEN
        v2_end := LENGTH(v2)+1;
      END IF;
      v1_num := TO_NUMBER (SUBSTR(v1,v1_start,v1_end-v1_start));
      v2_num := TO_NUMBER (SUBSTR(v2,v2_start,v2_end-v2_start));
      IF v1_num > v2_num THEN
        dbg ('compare_versions: '||v1_num||' > '||v2_num);
        RETURN 1;
      ELSIF v1_num < v2_num THEN
        dbg ('compare_versions: '||v1_num||' < '||v2_num);
        RETURN -1;
      END IF;
      dbg ('compare_versions: '||v1_num||' = '||v2_num);
      v1_start := v1_end+1;
      v2_start := v2_end+1;
    END LOOP;
  END compare_versions;

  PROCEDURE grant_awr_augments (imadvisor_user IN VARCHAR2) IS
    augment_owner     VARCHAR2(128);
    augment_db_name   VARCHAR2(4000);
    augment_dbid      NUMBER;
    augment_count     NUMBER := 0;
    CURSOR awr_augments IS
      SELECT   owner
      FROM     sys.dba_tables
      WHERE    (  owner LIKE 'IMADVISOR_%'
               OR owner LIKE 'C##IMADVISOR_%'
               )
        AND    table_name = 'IMADVISOR_AWR_AUGMENT'
      ORDER BY owner;
    CURSOR awr_augment_tables IS
      SELECT   table_name
      FROM     sys.dba_tables
      WHERE    owner = augment_owner
      ORDER BY table_name;
  BEGIN
    FOR aug IN awr_augments LOOP
      augment_owner := aug.owner;
      FOR t IN awr_augment_tables LOOP
        dbg ('grant_awr_augments: '||'GRANT SELECT ON '||augment_owner||'.'||t.table_name||' TO '||imadvisor_user);
        EXECUTE IMMEDIATE 'GRANT SELECT ON '||augment_owner||'.'||t.table_name||' TO '||imadvisor_user;
      END LOOP;
      dbg ('grant_awr_augments: '||'SELECT db_name, dbid FROM '||augment_owner||'.IMADVISOR_AWR_AUGMENT INTO augment_db_name, augment_dbid');
      EXECUTE IMMEDIATE 'SELECT db_name, dbid FROM '||augment_owner||'.IMADVISOR_AWR_AUGMENT' INTO augment_db_name, augment_dbid;
      IF augment_count = 0 THEN
        dbms_output.put_line ('Info: Oracle Database In-Memory Advisor AWR augment(s) are available for the following database(s):');
      END IF;
      dbms_output.put_line (augment_db_name||' (DBID='||augment_dbid||')');
      augment_count := augment_count + 1;
    END LOOP;
  END grant_awr_augments;

@@imadvisor_commoncode.sql

END imadvisor_installation;
/

DEFINE imadvisor_cleanup='BEGIN EXECUTE IMMEDIATE ''DROP PACKAGE &&session_user..imadvisor_installation''; EXCEPTION WHEN OTHERS THEN NULL; END;'

VARIABLE db_version           VARCHAR2(30);
VARIABLE db_version_cmp_12101 NUMBER;
VARIABLE db_version_cmp_12102 NUMBER;
BEGIN
  imadvisor_installation.clear_failure;
  imadvisor_installation.process_item_list (list => :imadvisor_sysprivs,            syspriv_check => TRUE);
  imadvisor_installation.process_item_list (list => :imadvisor_select_grants,       select_check  => TRUE);
  imadvisor_installation.process_item_list (list => :imadvisor_sel_grant_opts,      select_check  => TRUE);

  SELECT version INTO :db_version
  FROM   v$instance;
  :db_version_cmp_12101 := imadvisor_installation.compare_versions (:db_version, '12.1.0.1');
  :db_version_cmp_12102 := imadvisor_installation.compare_versions (:db_version, '12.1.0.2');

  IF imadvisor_installation.compare_versions (:db_version, '12.1.0.1') =0
  AND :imadvisor_local_db_type = 'PDB' THEN
    RAISE_APPLICATION_ERROR (-20001, 'Oracle Database In-Memory Advisor is not supported on 12.1.0.1 PDBs; instead, install on the CDB root');
  END IF;
  IF imadvisor_installation.compare_versions (:db_version, '12.1.0.1') >=0 THEN
    imadvisor_installation.process_item_list (list => :imadvisor_select_grants_12101, select_check  => TRUE);
  END IF;
  IF imadvisor_installation.compare_versions (:db_version, '12.1.0.2') >=0 THEN
    imadvisor_installation.process_item_list (list => :imadvisor_select_grants_12102, select_check  => TRUE);
  END IF;
  imadvisor_installation.process_item_list (list => :imadvisor_execute_grants,       execute_check => TRUE);
  IF imadvisor_installation.compare_versions (:db_version, '12.1.0.2') >=0 THEN
    imadvisor_installation.process_item_list (list => :imadvisor_execute_grants_12102, execute_check  => TRUE);
  END IF;
  IF imadvisor_installation.compare_versions (:db_version, '12.2.0.1') >=0 THEN
    imadvisor_installation.process_item_list (list => :imadvisor_select_grants_12201, select_check  => TRUE);
  END IF;
  imadvisor_installation.check_syspriv ('CREATE USER'); -- required only for the installation user, not the installed user
  IF imadvisor_installation.failure_occurred THEN
    RAISE_APPLICATION_ERROR (-20001, 'Current user '||SYS_CONTEXT('USERENV','SESSION_USER')||' lacks sufficient privileges: aborting...');
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    &&imadvisor_cleanup
    RAISE;
END;
/

VARIABLE imadvisor_user_exists    NUMBER;
VARIABLE imadvisor_import_replay  NUMBER;
DECLARE
  c  NUMBER;
BEGIN
  :imadvisor_user_exists   := 0;
  :imadvisor_import_replay := 0;
  SELECT COUNT(*) INTO c
  FROM   all_users
  WHERE  username = UPPER('&&imadvisor_username');
  IF c > 0 THEN
    :imadvisor_user_exists := 1;
    SELECT COUNT(*) INTO c
    FROM   dba_objects
    WHERE  owner = UPPER('&&imadvisor_username');
    IF c > 0 THEN
      dbms_output.put_line ('The Oracle database user &&imadvisor_username already exists with a non-empty schema.');
      dbms_output.put_line ('Installation aborting.');
      dbms_output.put_line ('If you wish to restart this installation:');
      dbms_output.put_line ('1.  Confirm that no data of any value exists in the &&imadvisor_username schema.');
      dbms_output.put_line ('2.  SQL> @catnoimadv.sql');
      RAISE_APPLICATION_ERROR (-20001, 'Schema &&imadvisor_username already exists and is non-empty: aborting...');
    END IF;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    &&imadvisor_cleanup
    RAISE;
END;
/

PROMPT Welcome to the Oracle Database In-Memory Advisor (DBMS_INMEMORY_ADVISOR)
PROMPT installation.
PROMPT

PROMPT
PROMPT DBMS_INMEMORY_ADVISOR uses Active Session History (ASH), Automatic Workload
PROMPT Repository (AWR) and optionally SQL Tuning Sets (STS) to determine which
PROMPT tables, partitions and subpartitions to place In Memory for optimized analytics
PROMPT processing performance.  DBMS_INMEMORY_ADVISOR produces a recommendation report
PROMPT and a SQLPlus script to implement its recommendations.
PROMPT
PROMPT DBMS_INMEMORY_ADVISOR users require the ADVISOR privilege.
PROMPT

SET TERMOUT  OFF;
COLUMN newvalue NOPRINT NEW_VALUE imadvisor_public_schema;
SELECT DECODE (SYS_CONTEXT('USERENV','SESSION_USER'), 'SYS', 'SYS', '&&imadvisor_username') AS newvalue FROM DUAL;
COLUMN newvalue NOPRINT NEW_VALUE imadvisor_11_or_12plus;
SELECT CASE WHEN TO_NUMBER(SUBSTR(version,1,INSTR(version,'.')-1)) >= 12 AND '&&imadvisor_public_schema' = 'SYS' THEN '12' ELSE '11' END AS newvalue FROM v$instance;
COLUMN newvalue NOPRINT NEW_VALUE imadvisor_cdb_root_or_not;
SELECT DECODE ('&&imadvisor_username','C##IMADVISOR','cdbroot','noncdbroot') AS newvalue FROM DUAL;
COLUMN newvalue NOPRINT NEW_VALUE imadvisor_installer_is_ideal;
SELECT CASE WHEN TO_NUMBER(SUBSTR(version,1,INSTR(version,'.')-1)) >= 12 AND '&&imadvisor_public_schema' <> 'SYS' THEN 'NO' ELSE 'YES' END AS newvalue FROM v$instance;
COLUMN newvalue CLEAR;
SET TERMOUT ON;

DECLARE
  newline  CONSTANT VARCHAR2(1) := '
';
BEGIN
  IF '&&imadvisor_installer_is_ideal' <> 'YES' THEN
    dbms_output.put_line ('********************************************************************************');
    dbms_output.put_line ('*** When installing the Oracle Database In-Memory Advisor on Oracle Database ***');
    dbms_output.put_line ('*** 12.1 or later, it is best to do so logged in as user SYS.  Otherwise,    ***');
    dbms_output.put_line ('*** the following, additional grant will be required for all In-Memory       ***');
    dbms_output.put_line ('*** Advisor users:                                                           ***');
    dbms_output.put_line ('***                                                                          ***');
    dbms_output.put_line (
      '***   GRANT INHERIT PRIVILEGES ON USER <username> TO &&imadvisor_username;'
      ||SUBSTR('                                                                                ',
               1, 77-LENGTH('***   GRANT INHERIT PRIVILEGES ON USER <username> TO &&imadvisor_username;'))
      ||'***');
    dbms_output.put_line ('***                                                                          ***');
    dbms_output.put_line ('*** To avoid the inconvience of these additional grants and to fully retain  ***');
    dbms_output.put_line ('*** this security enhancement with Oracle Database 12.1 and later, log in as ***');
    dbms_output.put_line ('*** user SYS and restart this installation.                                  ***');
    dbms_output.put_line ('********************************************************************************');
    dbms_output.put_line (newline);
    dbms_output.put_line ('Please answer YES only if you wish to continue this installaton as user '||SYS_CONTEXT('USERENV','SESSION_USER')||'.');
  END IF;
END;
/

SET TERMOUT OFF;
COLUMN newvalue NOPRINT NEW_VALUE imadvisor_setvar;
SELECT DECODE('&&imadvisor_installer_is_ideal', 'YES', 'continue_installation', 'imadvisor_trash') AS newvalue FROM DUAL;
COLUMN newvalue NOPRINT NEW_VALUE &&imadvisor_setvar;
SELECT 'YES' AS newvalue FROM DUAL;
COLUMN newvalue CLEAR;
SET TERMOUT ON;
DECLARE
  newline  CONSTANT VARCHAR2(1) := '
';
BEGIN
  IF UPPER('&&continue_installation') = 'NO' OR  UPPER('&&continue_installation') = 'N' OR '&&continue_installation' IS NULL THEN
    RAISE_APPLICATION_ERROR (-20001, 'Aborting installation');
  ELSIF UPPER('&&continue_installation') <> 'YES' AND  UPPER('&&continue_installation') <> 'Y' THEN
    RAISE_APPLICATION_ERROR (-20001, 'Unrecognized response: &&continue_installation, aborting installation');
  END IF;
  dbms_output.put_line (newline);
EXCEPTION
  WHEN OTHERS THEN
    &&imadvisor_cleanup
    RAISE;
END;
/

BEGIN
  IF :imadvisor_user_exists = 1THEN
    dbms_output.put_line ('This installation script will add object definitions to the existing');
    dbms_output.put_line ('&&imadvisor_username schema.');
  ELSE
    dbms_output.put_line ('This installation script will create user &&imadvisor_username and add object');
    dbms_output.put_line ('definitions to the schema.  This user is created using the IDENTIFIED BY');
    dbms_output.put_line ('password method with a random-generated password.  If you prefer to use either');
    dbms_output.put_line ('the IDENTIFIED EXTERNALLY or IDENTIFIED GLOBALLY method, abort this installation');
    dbms_output.put_line ('by pressing ^C.  Then create user &&imadvisor_username using your preferred');
    dbms_output.put_line ('method.  Add no objects or grants to the &&imadvisor_username schema.  Then run');
    dbms_output.put_line ('this installation script again.');
  END IF;
END;
/

PROMPT
DECLARE
  c  NUMBER;
BEGIN
  IF :imadvisor_user_exists = 0 THEN
    BEGIN
      EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM dba_tablespaces' INTO c;
    EXCEPTION
      WHEN OTHERS THEN
        IF SQLCODE = -942 THEN
          RAISE_APPLICATION_ERROR (-20001, 'Current user '||SYS_CONTEXT('USERENV','SESSION_USER')||' lacks SELECT access to dba_tablespaces');
        ELSE
          RAISE_APPLICATION_ERROR (-20001, 'Current user '||SYS_CONTEXT('USERENV','SESSION_USER')||' cannot access tablespaces in dba_tablespaces: '||SQLERRM);
        END IF;
    END;
    IF NVL(c,0) = 0 THEN
      RAISE_APPLICATION_ERROR (-20001, 'User &&imadvisor_username requires default tablespaces: no tablespaces found');
    END IF;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    &&imadvisor_cleanup
    RAISE;
END;
/

--------------------------------------------------------------------------------

DEFINE imadvisor_def_perm_ts_name='SYSTEM';
DEFINE imadvisor_def_temp_ts_name='TEMP';

SET TERMOUT  OFF;
SET FEEDBACK OFF;
SET VERIFY   OFF;

COLUMN newvalue NOPRINT NEW_VALUE imadvisor_perm_tablespace;
SELECT NULL AS newvalue FROM DUAL WHERE NULL IS NOT NULL;
COLUMN newvalue NOPRINT NEW_VALUE imadvisor_temp_tablespace;
SELECT NULL AS newvalue FROM DUAL WHERE NULL IS NOT NULL;

COLUMN newvalue NOPRINT NEW_VALUE imadvisor_setvar;
DEFINE   permanent_tablespace='trash';
UNDEFINE permanent_tablespace;
SELECT DECODE('&&imadvisor_perm_tablespace',
                NULL, DECODE (:imadvisor_user_exists,
                              0, 'imadvisor_trash',
                                 'permanent_tablespace'
                             ),
                      'permanent_tablespace')
       AS newvalue
FROM DUAL;
COLUMN newvalue NOPRINT NEW_VALUE &&imadvisor_setvar;
SELECT '&&imadvisor_perm_tablespace' AS newvalue FROM DUAL;

COLUMN newvalue NOPRINT NEW_VALUE imadvisor_setvar;
DEFINE   temporary_tablespace='trash';
UNDEFINE temporary_tablespace;
SELECT DECODE('&&imadvisor_temp_tablespace',
                NULL, DECODE (:imadvisor_user_exists,
                              0, 'imadvisor_trash',
                                 'temporary_tablespace'
                             ),
                      'temporary_tablespace')
       AS newvalue
FROM DUAL;
COLUMN newvalue NOPRINT NEW_VALUE &&imadvisor_setvar;
SELECT '&&imadvisor_temp_tablespace' AS newvalue FROM DUAL;

SET TERMOUT ON;
SET SERVEROUTPUT ON;
DECLARE
  newline CONSTANT VARCHAR2(1) := '
';
  CURSOR tablespaces IS
    SELECT   tablespace_name
    FROM     dba_tablespaces
    ORDER BY 1;
BEGIN
  IF  :imadvisor_user_exists = 0
  AND (  '&&imadvisor_perm_tablespace' IS NULL 
      OR '&&imadvisor_temp_tablespace' IS NULL
      ) THEN
    dbms_output.put_line ('User &&imadvisor_username requires both a permanent and temporary tablespace.');
    dbms_output.put_line ('Available tablespaces:');
    dbms_output.put_line (newline);
    dbms_output.put_line ('TABLESPACE_NAME');
    dbms_output.put_line ('------------------------------');
    FOR ts IN tablespaces LOOP
      IF ts.tablespace_name = '&&imadvisor_def_perm_ts_name' THEN
        dbms_output.put_line (ts.tablespace_name||' (default permanent tablespace)');
      ELSIF ts.tablespace_name = '&&imadvisor_def_temp_ts_name' THEN
        dbms_output.put_line (ts.tablespace_name||' (default temporary tablespace)');
      ELSE
        dbms_output.put_line (ts.tablespace_name);
      END IF;
    END LOOP;
    dbms_output.put_line (newline);
  END IF;
END;
/

SET TERMOUT OFF;
COLUMN newvalue NOPRINT NEW_VALUE imadvisor_perm_ts_prompt;
SELECT DECODE(:imadvisor_user_exists,0,'Permanent tablespace to be used with &&imadvisor_username: ','') AS newvalue FROM DUAL;
COLUMN newvalue NOPRINT NEW_VALUE imadvisor_temp_ts_prompt;
SELECT DECODE(:imadvisor_user_exists,0,'Temporary tablespace to be used with &&imadvisor_username: ','') AS newvalue FROM DUAL;
SET TERMOUT ON;

SET TERMOUT OFF;
COLUMN newvalue NOPRINT NEW_VALUE imadvisor_def_perm_ts;
DEFINE imadvisor_def_perm_ts='';
SELECT tablespace_name AS newvalue
FROM   dba_tablespaces
WHERE  tablespace_name         = '&&imadvisor_def_perm_ts_name'
  AND  :imadvisor_user_exists  = 0;
SET TERMOUT ON;

SET HEADING OFF;
SELECT '&&imadvisor_perm_ts_prompt'|| NVL(UPPER('&&permanent_tablespace'),'&&imadvisor_def_perm_ts') AS perm_ts_prompt FROM DUAL;
COLUMN newvalue NOPRINT NEW_VALUE imadvisor_perm_tablespace;
SELECT NVL('&&permanent_tablespace','&&imadvisor_def_perm_ts') AS newvalue FROM DUAL;
SET HEADING  ON;



DECLARE
  c NUMBER;
BEGIN
  IF :imadvisor_user_exists = 0 THEN
    SELECT COUNT(*) INTO c
    FROM   dba_tablespaces
    WHERE  tablespace_name = UPPER('&&imadvisor_perm_tablespace');
    IF c = 0 THEN
      IF '&&imadvisor_perm_tablespace' IS NULL THEN
        RAISE_APPLICATION_ERROR (-20001, 'Permanent tablespace must be specified');
      ELSE
        RAISE_APPLICATION_ERROR (-20001, 'Tablespace '||UPPER('&&imadvisor_perm_tablespace')||' not found');
      END IF;
    END IF;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    &&imadvisor_cleanup
    RAISE;
END;
/

SET TERMOUT OFF;
COLUMN newvalue NOPRINT NEW_VALUE imadvisor_def_temp_ts;
DEFINE imadvisor_def_temp_ts='';
SELECT tablespace_name AS newvalue
FROM   dba_tablespaces
WHERE  tablespace_name         = '&&imadvisor_def_temp_ts_name'
  AND  :imadvisor_user_exists  = 0;
SET TERMOUT ON;

SET HEADING OFF;
SELECT '&&imadvisor_temp_ts_prompt'||NVL(UPPER('&&temporary_tablespace'),'&&imadvisor_def_temp_ts') AS temp_ts_prompt FROM DUAL;
COLUMN newvalue NOPRINT NEW_VALUE imadvisor_temp_tablespace;
SELECT NVL('&&temporary_tablespace','&&imadvisor_def_temp_ts') AS newvalue FROM DUAL;
SET HEADING  ON;

DECLARE
  c NUMBER;
BEGIN
  IF :imadvisor_user_exists = 0 THEN
    SELECT COUNT(*) INTO c
    FROM   dba_tablespaces
    WHERE  tablespace_name = UPPER('&&imadvisor_temp_tablespace');
    IF c = 0 THEN
      IF '&&imadvisor_temp_tablespace' IS NULL THEN
        RAISE_APPLICATION_ERROR (-20001, 'Temporary tablespace must be specified');
      ELSE
        RAISE_APPLICATION_ERROR (-20001, 'Tablespace '||UPPER('&&imadvisor_temp_tablespace')||' not found');
      END IF;
    END IF;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    &&imadvisor_cleanup
    RAISE;
END;
/

COLUMN   newvalue CLEAR;
DEFINE   imadvisor_trash='trash';
UNDEFINE imadvisor_trash;
UNDEFINE imadvisor_setvar;
UNDEFINE permanent_tablespace;
UNDEFINE imadvisor_perm_ts_prompt;
UNDEFINE temporary_tablespace;
UNDEFINE imadvisor_temp_ts_prompt;

BEGIN
  IF :imadvisor_user_exists = 0 THEN
    EXECUTE IMMEDIATE
'CREATE USER  &&imadvisor_username'||
' IDENTIFIED BY "'||imadvisor_installation.random_password()||'"'||
' DEFAULT TABLESPACE &&imadvisor_perm_tablespace'||
' TEMPORARY TABLESPACE &&imadvisor_temp_tablespace';
  END IF;
  imadvisor_installation.process_item_list (:imadvisor_sysprivs,       exec_action_part1=>'GRANT ',             exec_action_part2=>' TO &&imadvisor_username');
  imadvisor_installation.process_item_list (:imadvisor_select_grants,  exec_action_part1=>'GRANT SELECT ON ',   exec_action_part2=>' TO &&imadvisor_username');
  imadvisor_installation.process_item_list (:imadvisor_sel_grant_opts, exec_action_part1=>'GRANT SELECT ON ',   exec_action_part2=>' TO &&imadvisor_username'
                                            ||' WITH GRANT OPTION');
  imadvisor_installation.process_item_list (:imadvisor_opt_write_dir_grants,
                                            exec_action_part1=>'GRANT WRITE ON DIRECTORY ',
                                            exec_action_part2=>' TO &&imadvisor_username',
                                            optional=>TRUE);

  IF :imadvisor_local_db_type = 'CDB-root' THEN
    imadvisor_installation.process_item_list
      (:imadvisor_select_grants,
       exec_action_part1=>
         'ALTER USER &&imadvisor_username SET CONTAINER_DATA=ALL FOR ',
       exec_action_part2=>
         ' CONTAINER=CURRENT');
    imadvisor_installation.process_item_list
      (:imadvisor_sel_grant_opts,
       exec_action_part1=>
         'ALTER USER &&imadvisor_username SET CONTAINER_DATA=ALL FOR ',
       exec_action_part2=>
         ' CONTAINER=CURRENT');
  END IF;
  imadvisor_installation.process_item_list (:imadvisor_execute_grants, exec_action_part1=>'GRANT EXECUTE ON ',  exec_action_part2=>' TO &&imadvisor_username');
  IF imadvisor_installation.compare_versions (:db_version, '12.1.0.1') >=0 THEN
    imadvisor_installation.process_item_list (:imadvisor_select_grants_12101, exec_action_part1=>'GRANT SELECT ON ',    exec_action_part2=>' TO &&imadvisor_username');
    IF :imadvisor_local_db_type = 'CDB-root' THEN
      imadvisor_installation.process_item_list
        (:imadvisor_select_grants_12101,
         exec_action_part1=>
           'ALTER USER &&imadvisor_username SET CONTAINER_DATA=ALL FOR ',
         exec_action_part2=>
           ' CONTAINER=CURRENT');
    END IF;
  END IF;
  IF imadvisor_installation.compare_versions (:db_version, '12.1.0.2') >=0 THEN
    imadvisor_installation.process_item_list (:imadvisor_select_grants_12102, exec_action_part1=>'GRANT SELECT ON ',    exec_action_part2=>' TO &&imadvisor_username');
    IF :imadvisor_local_db_type = 'CDB-root' THEN
      imadvisor_installation.process_item_list
        (:imadvisor_select_grants_12102,
         exec_action_part1=>
           'ALTER USER &&imadvisor_username SET CONTAINER_DATA=ALL FOR ',
         exec_action_part2=>
           ' CONTAINER=CURRENT');
    END IF;
    imadvisor_installation.process_item_list (:imadvisor_execute_grants_12102, exec_action_part1=>'GRANT EXECUTE ON ',  exec_action_part2=>' TO &&imadvisor_username');
  END IF;
  IF imadvisor_installation.compare_versions (:db_version, '12.2.0.1') >=0 THEN
    imadvisor_installation.process_item_list (:imadvisor_select_grants_12201, exec_action_part1=>'GRANT SELECT ON ',    exec_action_part2=>' TO &&imadvisor_username');
    IF :imadvisor_local_db_type = 'CDB-root' THEN
      imadvisor_installation.process_item_list
        (:imadvisor_select_grants_12201,
         exec_action_part1=>
           'ALTER USER &&imadvisor_username SET CONTAINER_DATA=ALL FOR ',
         exec_action_part2=>
           ' CONTAINER=CURRENT');
    END IF;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    &&imadvisor_cleanup
    RAISE;
END;
/

BEGIN
  imadvisor_installation.grant_awr_augments ('&&imadvisor_username');
EXCEPTION
  WHEN OTHERS THEN
    &&imadvisor_cleanup
    RAISE;
END;
/

-- NOTE: Schema definitions reference the package specs.  The package bodies
-- reference the schema definitions.  So the order of definitions must be:
-- 1. Package specifications. (Likely ok to do before view clones, but whatever.)
-- 2. Schema definitions.
-- 3. Package bodies.

SET SERVEROUTPUT ON;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
SET LINESIZE 100;
SET PAGESIZE 50000;
DEFINE feedback='OFF';
DEFINE verify='OFF';
SET FEEDBACK &&feedback;
SET VERIFY   &&verify;

-- Define schema objects used by DBMS_INMEMORY_ADVISOR_PRVT
ALTER SESSION SET CURRENT_SCHEMA=&&imadvisor_username;
EXEC &&session_user..imadvisor_installation.dbg ('@@catimadv.sql');
@@catimadv.sql

-- Define the DBMS_INMEMORY_ADVISOR public package specification
ALTER SESSION SET CURRENT_SCHEMA=&&imadvisor_public_schema;
EXEC &&session_user..imadvisor_installation.dbg ('@@dbmsimadv.sql');
@@dbmsimadv.sql

-- Define the DBMS_INMEMORY_ADVISOR_PRVT private package specification
ALTER SESSION SET CURRENT_SCHEMA=&&imadvisor_username;
EXEC &&session_user..imadvisor_installation.dbg ('@@prvsimadvprvt&&imadvisor_11_or_12plus..plb');
@@prvsimadvprvt&&imadvisor_11_or_12plus..plb

-- Define the DBMS_INMEMORY_ADVISOR_INTERNAL private package specification
ALTER SESSION SET CURRENT_SCHEMA=&&imadvisor_username;
EXEC &&session_user..imadvisor_installation.dbg ('@@prvsimadvint.plb');
@@prvsimadvint.plb

-- Define IM Advisor dependent schema objects
ALTER SESSION SET CURRENT_SCHEMA=&&imadvisor_username;
EXEC &&session_user..imadvisor_installation.dbg ('@@prvtimadvdep.plb');
@@prvtimadvdep.plb

-- Define the DBMS_INMEMORY_ADVISOR public package body
ALTER SESSION SET CURRENT_SCHEMA=&&imadvisor_public_schema;
EXEC &&session_user..imadvisor_installation.dbg ('@@prvtimadv_&&imadvisor_cdb_root_or_not..plb');
@@prvtimadv_&&imadvisor_cdb_root_or_not..plb

-- Define the DBMS_INMEMORY_ADVISOR_PRVT private package body
ALTER SESSION SET CURRENT_SCHEMA=&&imadvisor_username;
EXEC &&session_user..imadvisor_installation.dbg ('@@prvtimadvprvt.plb');
@@prvtimadvprvt.plb

-- Define the DBMS_INMEMORY_ADVISOR_INTERNAL private package body
ALTER SESSION SET CURRENT_SCHEMA=&&imadvisor_username;
EXEC &&session_user..imadvisor_installation.dbg ('@@prvtimadvint.plb');
@@prvtimadvint.plb

ALTER SESSION SET CURRENT_SCHEMA=&&session_user;

BEGIN
  dbms_inmemory_advisor.drop_task ('imadvisor installation check');
  RAISE_APPLICATION_ERROR (-20001, 'Installation failure: DROP_TASK(non-existent-task) gave no error');
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE <> -20001 THEN
      &&imadvisor_cleanup
      RAISE;
    END IF;
END;
/

DROP PACKAGE imadvisor_installation;

PROMPT
PROMPT All done!
PROMPT
PROMPT DBMS_INMEMORY_ADVISOR installation successful.
PROMPT
PROMPT Users who will use the DBMS_INMEMORY_ADVISOR package must be granted
PROMPT the ADVISOR privilege.
PROMPT
DECLARE
  newline  CONSTANT VARCHAR2(1) := '
';
BEGIN
  IF '&&imadvisor_installer_is_ideal' <> 'YES' THEN
    dbms_output.put_line ('And as described above, users who will use the DBMS_INMEMORY_ADVISOR package');
    dbms_output.put_line ('must also grant the following:');
    dbms_output.put_line (newline);
    dbms_output.put_line ('GRANT INHERIT PRIVILEGES ON USER <username> TO &&imadvisor_username;');
    dbms_output.put_line (newline);
  END IF;
END;
/
PROMPT
PROMPT DBMS_INMEMORY_ADVISOR installation and setup complete.
PROMPT
PROMPT To uninstall:
PROMPT
PROMPT SQL> @catnoimadv.sql
PROMPT

EXIT
