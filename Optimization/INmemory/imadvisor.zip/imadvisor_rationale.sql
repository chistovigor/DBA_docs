Rem
Rem $Header: rdbms/admin/imadvisor_rationale.sql jraitto_imadvisor_12_2_adefix/3 2016/08/24 14:45:31 jraitto Exp $
Rem
Rem imadvisor_rationale.sql
Rem
Rem Copyright (c) 2015, 2016, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      imadvisor_rationale.sql - <one-line expansion of the name>
Rem
Rem    DESCRIPTION
Rem      <short description of component this file declares/defines>
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/imadvisor_rationale.sql 
Rem    SQL_SHIPPED_FILE: 
Rem    SQL_PHASE: 
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: 
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    jraitto     08/22/16 - Bug 24401898
Rem    jraitto     02/20/16 - Continuing edits
Rem    jraitto     08/10/15 - derived from imadvisor_rationale.sql
Rem                           (rdbms/src/server/svrman/im) 1.0.0.0.1 build #540
Rem    jraitto     08/10/15 - Created, 1.0.0.0.1 build #540 history:
Rem    jraitto     07/06/15 - use task_name instead of task_id
Rem    jraitto     04/27/15 - Determine Advisor schema name dynamically
Rem    jraitto     04/13/15 - diagnostic script
Rem    jraitto     04/13/15 - Created
Rem

SET HEADING       OFF;
SET LINESIZE      200;
SET PAGESIZE      50000;
SET FEEDBACK      OFF;
SET SERVEROUTPUT  ON;
SET VERIFY        OFF;

SET TERMOUT       OFF;
COLUMN imadvisor_schema NOPRINT NEW_VALUE imadvisor_schema;
SELECT owner AS imadvisor_schema
FROM   dba_tables
WHERE  table_name = 'WRI$_IMA_MANIFEST';
COLUMN imadvisor_schema CLEAR;
SET TERMOUT       ON;

WHENEVER SQLERROR EXIT;
BEGIN
  IF '&&imadvisor_schema' IS NULL THEN
    RAISE_APPLICATION_ERROR (-20001, 'DBMS_INMEMORY_ADVISOR is not installed');
  END IF;
END;
/

SET TERMOUT       ON;
COLUMN owner              FORMAT a30;
COLUMN table_name         FORMAT a30;
COLUMN partition_name     FORMAT a30;
COLUMN subpartition_name  FORMAT a30;
COLUMN rationale          FORMAT a100;
SET HEADING       ON;
SET TERMOUT       ON;
SET FEEDBACK      ON;
SET LINESIZE 132;
SET PAGESIZE 75;

PROMPT Rejection Summary
PROMPT
PROMPT Pick the TASK_NAME from the list below:
SELECT   task_name
FROM     user_ima_task_information
ORDER BY 1;

SELECT   rationale, COUNT(*)
FROM     user_ima_recommendations
WHERE    task_name    = '&&task_name'
  AND    NVL(rank,0)  = 0
GROUP BY rationale
ORDER BY 1;

PROMPT If you would like more detail about the candidates rejected with a
PROMPT partitulcar rationale, enter a substring from that rationale.
PROMPT Or enter % for all detail.
PROMPT Or press ENTER for no detail.
SELECT   table_owner, table_name, partition_name, subpartition_name, uncompressed_bytes, compression_type, est_compressed_bytes, non_im_dbtime_secs, est_reduced_dbtime_secs, rationale
FROM     user_ima_recommendations
WHERE    task_name               = '&&task_name'
  AND    NVL(rank,0)             = 0
  AND    rationale               LIKE '%&&rationale_substring%'
  AND    '&&rationale_substring' IS NOT NULL
ORDER BY 1,2,3,4;

UNDEFINE task_name;
UNDEFINE rationale_substring;

