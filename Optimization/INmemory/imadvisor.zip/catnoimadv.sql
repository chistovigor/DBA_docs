Rem
Rem $Header: rdbms/admin/catnoimadv.sql jraitto_imadvisor_12_2_adefix/6 2016/11/10 20:34:50 jraitto Exp $
Rem
Rem catnoimadv.sql
Rem
Rem Copyright (c) 2015, 2017, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      catnoimadv.sql - NO In-Memory ADVisor
Rem
Rem    DESCRIPTION
Rem      Uninstall Oracle Database In-Memory Advisor
Rem
Rem    NOTES
Rem      <other useful comments, qualifications, etc.>
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/catnoimadv.sql 
Rem    SQL_SHIPPED_FILE: 
Rem    SQL_PHASE: 
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: 
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    jraitto     01/10/17 - fix removal of AWR augments on CDB roots
Rem    jraitto     10/31/16 - Allow optional retention of AWR augments for
Rem                           internal testing
Rem    jraitto     08/24/16 - remove SET SERVEROUTPUT ON to avoid deadlocks
Rem    jraitto     08/22/16 - Bug 23094464
Rem    jraitto     08/17/16 - remove WHENEVER SQLERROR EXIT
Rem    jraitto     06/28/16 - clean EM131 compatibility
Rem    jraitto     04/29/16 - Continuing edits
Rem    jraitto     04/08/16 - drop sys.dbms_inmemory_advisor
Rem    jraitto     03/31/16 - drop imadvisor_directory
Rem    jraitto     03/23/16 - Continuing edits
Rem    jraitto     03/02/16 - Continuing edits
Rem    jraitto     02/26/16 - do not drop wri$_ima_manifest with ORA-14452
Rem    jraitto     02/19/16 - Continuing edits
Rem    jraitto     02/05/16 - Make work w/MOS download as well as RDBMS integration
Rem    jraitto     10/21/15 - Uninstall In-Memory Advisor
Rem    jraitto     10/21/15 - Created
Rem

-- @@?/rdbms/admin/sqlsessstart.sql

SET LINESIZE 200;

SET TERMOUT   OFF;
SET VERIFY    OFF;
SET FEEDBACK  OFF;

DEFINE uninstall_blocking_count=0;

COLUMN uninstall_blocking_count NOPRINT NEW_VALUE uninstall_blocking_count;
SET TERMOUT ON;
SET HEADING OFF;
SELECT DECODE(COUNT(*),
         0, 'SELECT ON DBA_TABLES has not been granted',
            NULL) AS err_message,
       DECODE(COUNT(*),
         0, (&&uninstall_blocking_count + 1),
             &&uninstall_blocking_count) AS uninstall_blocking_count
FROM   all_views
WHERE  view_name = 'DBA_TABLES';
SELECT DECODE(COUNT(*),
         0, 'SELECT ON DBA_SYNONYMS has not been granted',
            NULL) AS err_message,
       DECODE(COUNT(*),
         0, (&&uninstall_blocking_count + 1),
             &&uninstall_blocking_count) AS uninstall_blocking_count
FROM   all_views
WHERE  view_name = 'DBA_SYNONYMS';
SELECT DECODE(COUNT(*),
         0, 'SELECT ON DBA_PROCEDURES has not been granted',
            NULL) AS err_message,
       DECODE(COUNT(*),
         0, (&&uninstall_blocking_count + 1),
             &&uninstall_blocking_count) AS uninstall_blocking_count
FROM   all_views
WHERE  view_name = 'DBA_PROCEDURES';
SET HEADING ON;
SET TERMOUT OFF;
COLUMN uninstall_blocking_count CLEAR;


COLUMN imadvisor_schema NOPRINT NEW_VALUE imadvisor_schema;
SELECT NULL AS imadvisor_schema FROM DUAL WHERE NULL IS NOT NULL;
COLUMN imadvisor_schema CLEAR;

DEFINE imadvisor_install_count='';
COLUMN imadvisor_install_count NOPRINT NEW_VALUE imadvisor_install_count;
SELECT COUNT(*) AS imadvisor_install_count
FROM   dba_tables
WHERE  table_name IN ('IMADVISOR_MANIFEST', 'WRI$_IMA_MANIFEST')
  AND  '&&imadvisor_schema' IS NULL;
COLUMN imadvisor_install_count CLEAR;

COLUMN uninstall_blocking_count NOPRINT NEW_VALUE uninstall_blocking_count;
SELECT (&&uninstall_blocking_count + 1) AS uninstall_blocking_count
FROM   DUAL
WHERE  '&&imadvisor_install_count' IS NULL OR TO_NUMBER('&&imadvisor_install_count') > 1;
COLUMN uninstall_blocking_count CLEAR;

SET TERMOUT   ON;

SET HEADING OFF;
SELECT 'DBMS_INMEMORY_ADVISOR has been installed in multiple schemes:'
FROM   DUAL
WHERE  &&imadvisor_install_count > 1;
SET HEADING ON;

SELECT   owner AS "In-Memory Advior Schema Name"
FROM     dba_tables
WHERE    table_name IN ('IMADVISOR_MANIFEST', 'WRI$_IMA_MANIFEST')
  AND    &&imadvisor_install_count > 1
ORDER BY 1;

SET HEADING OFF;
SELECT '"DEFINE imadvisor_schema=''<schema_name>'';" prior to running this script'
FROM   DUAL
WHERE  &&imadvisor_install_count > 1;
SET HEADING ON;

SET TERMOUT OFF;

DEFINE imadvisor_public_schema='';
COLUMN imadvisor_public_schema NOPRINT NEW_VALUE imadvisor_public_schema;
SELECT table_owner AS imadvisor_public_schema
FROM   dba_synonyms
WHERE  owner         = 'PUBLIC'
  AND  synonym_name  = 'DBMS_INMEMORY_ADVISOR';
COLUMN imadvisor_public_schema CLEAR;

COLUMN imadvisor_schema NOPRINT NEW_VALUE imadvisor_schema;
SELECT NVL('&&imadvisor_schema',owner) AS imadvisor_schema
FROM   dba_tables
WHERE  table_name IN ('IMADVISOR_MANIFEST', 'WRI$_IMA_MANIFEST')
  AND  '&&imadvisor_schema' IS NULL;
COLUMN imadvisor_schema CLEAR;

DEFINE imadvisor_manifest='';
COLUMN imadvisor_manifest NOPRINT NEW_VALUE imadvisor_manifest;
SELECT DECODE('&&imadvisor_schema',NULL,'','&&imadvisor_schema . '||table_name) AS imadvisor_manifest
FROM   dba_tables
WHERE  owner = UPPER('&&imadvisor_schema')
  AND  table_name IN  ('IMADVISOR_MANIFEST', 'WRI$_IMA_MANIFEST');
COLUMN imadvisor_manifest CLEAR;

COLUMN imadvisor_comment_manifest NOPRINT NEW_VALUE imadvisor_comment_manifest;
SELECT DECODE(&&uninstall_blocking_count,
         0, DECODE('&&imadvisor_manifest',
              NULL, '-- ',
                    ''),
            '--') AS imadvisor_comment_manifest
FROM   DUAL;
COLUMN imadvisor_comment_manifest CLEAR;

SET TERMOUT ON;

COLUMN uninstall_blocking_count NOPRINT NEW_VALUE uninstall_blocking_count;
SET HEADING OFF;
SELECT 'Cannot uninstall DBMS_INMEMORY_ADVISOR when logged in as '||UPPER('&&imadvisor_schema') AS err_message,
       (&&uninstall_blocking_count + 1) AS uninstall_blocking_count
FROM   DUAL
WHERE  UPPER('&&imadvisor_schema') IN ('IMADVISOR', 'C##IMADVISOR')
  AND  (  UPPER('&&imadvisor_schema') = SYS_CONTEXT('USERENV','SESSION_USER')
       OR UPPER('&&imadvisor_schema') = USER
       );
COLUMN uninstall_blocking_count CLEAR;
SET HEADING ON;

COLUMN retain_awr_augments NOPRINT NEW_VALUE retain_awr_augments;
SET TERMOUT OFF;
SELECT NULL AS retain_awr_augments FROM DUAL WHERE NULL IS NOT NULL;
SELECT NVL('&&retain_awr_augments','NO') AS retain_awr_augments FROM DUAL;
SET TERMOUT ON;
COLUMN retain_awr_augments CLEAR;

DECLARE
  s               NUMBER;
  is_awr_augment  BOOLEAN;

&&imadvisor_comment_manifest  CURSOR imadvisor_objects IS
&&imadvisor_comment_manifest    SELECT   object_type,
&&imadvisor_comment_manifest             object_name,
&&imadvisor_comment_manifest             is_task_table,
&&imadvisor_comment_manifest             is_temp_table,
&&imadvisor_comment_manifest             is_awr_augment
&&imadvisor_comment_manifest    FROM     &&imadvisor_manifest
&&imadvisor_comment_manifest    WHERE    UPPER(object_name) NOT IN ('IMADVISOR_MANIFEST', 'WRI$_IMA_MANIFEST')
&&imadvisor_comment_manifest    ORDER BY is_temp_table DESC, object_type, object_name;

  CURSOR awr_augment_procs IS
    SELECT   owner
    FROM     dba_procedures
    WHERE    object_name = 'DBMS_IMADVISOR_AWR_AUGMENTTABS'
    ORDER BY owner;

    CURSOR awr_augment_schemes IS
      SELECT   owner AS awr_augment_schema
      FROM     sys.dba_tables
      WHERE    (  owner LIKE 'IMADVISOR\_%'     ESCAPE '\'
               OR owner LIKE 'C##IMADVISOR\_%'  ESCAPE '\'
               )
        AND    table_name = 'IMADVISOR_AWR_AUGMENT'
      ORDER BY owner;

  PROCEDURE drop_it (object_type IN VARCHAR2, obj1 IN VARCHAR2, obj2 IN VARCHAR2 := NULL) IS
    cmd             VARCHAR2(32767);
  BEGIN
    IF object_type = 'PUBLIC SYNONYM' THEN
      cmd := 'DROP '||object_type||' '||NVL(obj2,obj1);
    ELSIF object_type = 'USER' THEN
      cmd := 'DROP '||object_type||' '||obj1||' '||obj2;
    ELSIF object_type = 'DIRECTORY' THEN
      cmd := 'DROP '||object_type||' '||obj1;
    ELSE
      cmd := 'DROP '||object_type||' '||obj1||'.'||obj2;
    END IF;
    BEGIN
      EXECUTE IMMEDIATE cmd;
    EXCEPTION
      WHEN OTHERS THEN
        IF SQLCODE = -14452 THEN
          RAISE_APPLICATION_ERROR (-20001, 'Cannot uninstall DBMS_INMEMORY_ADVISOR: there is an active session');
        END IF;
        IF SQLCODE NOT IN (-942, -1432, -1434, -1435, -1918, -2289, -4043) THEN
          RAISE;
        END IF;
    END;
  END drop_it;

BEGIN

  IF &&uninstall_blocking_count = 0 THEN
  
&&imadvisor_comment_manifest    FOR io IN imadvisor_objects LOOP
&&imadvisor_comment_manifest      drop_it (io.object_type, '&&imadvisor_schema', io.object_name);
&&imadvisor_comment_manifest    END LOOP;
&&imadvisor_comment_manifest    drop_it ('TABLE', '&&imadvisor_schema', 'wri$_ima_manifest');

    IF UPPER('&&imadvisor_schema') IN ('IMADVISOR', 'C##IMADVISOR') THEN
      drop_it ('USER', '&&imadvisor_schema', 'CASCADE');
    END IF;

    -- If imadvisor_schema was dropped, we lost the manifest.
    -- Drop anything outside of the imadvisor_schema:

    IF  '&&imadvisor_public_schema' IS NOT NULL
    THEN
      drop_it ('PACKAGE', '&&imadvisor_public_schema', 'DBMS_INMEMORY_ADVISOR');
    END IF;

    drop_it ('PACKAGE',      'SYS', 'DBMS_INMEMORY_ADVISOR');
    drop_it ('PACKAGE BODY', 'SYS', 'DBMS_INMEMORY_ADVISOR');
    drop_it ('PACKAGE',      'SYS', 'DBMS_INMEMORY_ADVISOR_PRVT');
    drop_it ('PACKAGE BODY', 'SYS', 'DBMS_INMEMORY_ADVISOR_PRVT');
    drop_it ('PACKAGE',      'SYS', 'DBMS_INMEMORY_ADVISOR_INTERNAL');
    drop_it ('PACKAGE BODY', 'SYS', 'DBMS_INMEMORY_ADVISOR_INTERNAL');

    drop_it ('PUBLIC SYNONYM', 'DBMS_INMEMORY_ADVISOR');

    drop_it ('PUBLIC SYNONYM', 'CDB_IMA_AWR_AUGMENTS');
    drop_it ('PUBLIC SYNONYM', 'CDB_IMA_BENEFIT_COST');
    drop_it ('PUBLIC SYNONYM', 'CDB_IMA_RECOMMENDATIONS');
    drop_it ('PUBLIC SYNONYM', 'CDB_IMA_RECOMMENDATION_FILES');
    drop_it ('PUBLIC SYNONYM', 'CDB_IMA_RECOMMENDATION_LINES');
    drop_it ('PUBLIC SYNONYM', 'CDB_IMA_TASK_INFORMATION');

    drop_it ('PUBLIC SYNONYM', 'DBA_IMA_AWR_AUGMENTS');
    drop_it ('PUBLIC SYNONYM', 'DBA_IMA_BENEFIT_COST');
    drop_it ('PUBLIC SYNONYM', 'DBA_IMA_RECOMMENDATIONS');
    drop_it ('PUBLIC SYNONYM', 'DBA_IMA_RECOMMENDATION_FILES');
    drop_it ('PUBLIC SYNONYM', 'DBA_IMA_RECOMMENDATION_LINES');
    drop_it ('PUBLIC SYNONYM', 'DBA_IMA_TASK_INFORMATION');

    drop_it ('PUBLIC SYNONYM', 'USER_IMA_BENEFIT_COST');
    drop_it ('PUBLIC SYNONYM', 'USER_IMA_RECOMMENDATIONS');
    drop_it ('PUBLIC SYNONYM', 'USER_IMA_RECOMMENDATION_FILES');
    drop_it ('PUBLIC SYNONYM', 'USER_IMA_RECOMMENDATION_LINES');
    drop_it ('PUBLIC SYNONYM', 'USER_IMA_TASK_INFORMATION');

    drop_it ('DIRECTORY', 'IMADVISOR_DIRECTORY');

    -- EM13.1 db plug-in GUI compatibility
    drop_it ('SYNONYM', 'SYS', 'IMADVISOR_RECOMMENDATIONS');
    drop_it ('SYNONYM', 'SYS', 'IMADVISOR_FILE_LINES');

    -- Procedure DBMS_IMADVISOR_AWR_AUGMENTTABS can be left behind
    -- only if script rdbms/admin/imadvisor_awr_augment_export.sql crashes
    -- or MOS download installation instimadv.sql crashes.  The procedure
    -- will be owned by the user that ran the crashed sript.
    FOR aap IN awr_augment_procs LOOP
      EXECUTE IMMEDIATE 'DROP PROCEDURE '||aap.owner||'.DBMS_IMADVISOR_AWR_AUGMENTTABS';
    END LOOP;

   IF UPPER('&&retain_awr_augments') NOT IN ('YES','Y','TRUE','T') THEN
     FOR aas IN awr_augment_schemes LOOP
       IF aas.awr_augment_schema LIKE 'C##IMADVISOR\_%' ESCAPE '\' THEN
         s := LENGTH ('C##IMADVISOR_') + 1;
       ELSE
         s := LENGTH ('IMADVISOR_') + 1;
       END IF;
       is_awr_augment := TRUE;
       FOR i IN s .. LENGTH( aas.awr_augment_schema) LOOP
         IF SUBSTR(aas.awr_augment_schema, i, 1) NOT IN ('_','0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F') THEN
           is_awr_augment := FALSE;
           EXIT;
         END IF;
       END LOOP;
       IF is_awr_augment THEN
         EXECUTE IMMEDIATE 'DROP USER '||aas.awr_augment_schema||' CASCADE';
       END IF;
     END LOOP;
   END IF;

  END IF;

END;
/

SET HEADING OFF;
SELECT 'catnoimadv.sql aborted'
FROM   DUAL
WHERE  &&uninstall_blocking_count>0;
SET HEADING ON;

DEFINE uninstall_blocking_count='trash';
UNDEFINE uninstall_blocking_count;
DEFINE imadvisor_schema='trash';
UNDEFINE imadvisor_schema;
DEFINE imadvisor_install_count='trash';
UNDEFINE imadvisor_install_count;
DEFINE imadvisor_public_schema='trash';
UNDEFINE imadvisor_public_schema;
DEFINE imadvisor_manifest='trash';
UNDEFINE imadvisor_manifest;
DEFINE imadvisor_comment_manifest='trash';
UNDEFINE imadvisor_comment_manifest;
DEFINE retain_awr_augments='trash';
UNDEFINE retain_awr_augments;

SET FEEDBACK     ON;
SET VERIFY       ON;
SET LINESIZE     80;

-- @?/rdbms/admin/sqlsessend.sql
