Rem
Rem $Header: rdbms/admin/imadvisor_recommendations.sql jraitto_imadvisor_12_2_adefix/7 2017/01/05 16:13:59 jraitto Exp $
Rem
Rem imadvisor_recommendations.sql
Rem
Rem Copyright (c) 2016, 2017, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      imadvisor_recommendations.sql - [create task] [gather stats] [analyze] generate recommendations
Rem
Rem    DESCRIPTION
Rem      Interactactive wrapper script on top of DBMS_INMEMORY_ADVISOR PL/SQL API.
Rem
Rem      Works with live workloads or imported, augmented AWR workloads.
Rem
Rem      Works with a non-CDB, CDB root or a PDB.
Rem
Rem      Works with a non-RAC or a RAC.
Rem
Rem    NOTES
Rem      Derived from an earlier version of imadvisor_analyze_and_report.sql.
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/imadvisor_recommendations.sql 
Rem    SQL_SHIPPED_FILE: 
Rem    SQL_PHASE: 
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: 
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    jraitto     01/09/17 - Bug 25360695
Rem    jraitto     01/05/17 - Continuing edits
Rem    jraitto     01/04/17 - add object filter option
Rem    jraitto     01/03/17 - Bug 25341231
Rem    jraitto     12/15/16 - Continuing edits
Rem    jraitto     12/08/16 - Bug 25226550
Rem    jraitto     12/02/16 - Bug 23478573
Rem    jraitto     05/16/16 - remove bytes column from benefit table
Rem    jraitto     04/06/16 - catch in-memory size errors
Rem    jraitto     03/25/16 - Replace deprecated imadvisor_analyze_and_report.sql
Rem                           (derived from rdbms/admin/imadvisor_analyze_and_report.sql)
Rem    jraitto     03/25/16 - Created 

WHENEVER SQLERROR CONTINUE;

SET ECHO       OFF;
SET NUMWIDTH   10;
SET LINESIZE   80;

SET FEEDBACK      OFF;
SET VERIFY        OFF;
SET TRIMSPOOL     ON;
SET TAB           OFF;
SET PAGESIZE      100;
SET SERVEROUTPUT  ON;

COLUMN script_in_progress NOPRINT NEW_VALUE script_in_progress;
SET TERMOUT OFF;
SELECT NULL AS script_in_progress FROM DUAL WHERE NULL IS NOT NULL;
SET TERMOUT ON;
COLUMN script_in_progress CLEAR;

WHENEVER SQLERROR EXIT SQL.SQLCODE;
DECLARE
  newline  CONSTANT VARCHAR2(1) := '
';
BEGIN
  IF '&&script_in_progress' IS NOT NULL THEN
    dbms_output.put_line (newline);
    dbms_output.put_line ('It appears this script or a related script was interrupted prior to the current');
    dbms_output.put_line ('run of this script.  When one of these scripts is interrupted, you must start a');
    dbms_output.put_line ('new sqlplus session to run these scripts again.'||newline);

    dbms_output.put_line ('Restarting your sqlplus session is only necessary when one of these scripts has');
    dbms_output.put_line ('been interrupted.  You can otherwise run any of these scripts any number of');
    dbms_output.put_line ('times in a single sqlplus session.'||newline);

    RAISE_APPLICATION_ERROR (-20001, 'Aborting.  Restart your sqlplus session and try again.');
  END IF;
END;
/

WHENEVER SQLERROR CONTINUE;

DEFINE script_in_progress='TRUE';

DEFINE imadvisor_time_format = 'YYYY-MON-DD HH24:MI:SS.FF';
DEFINE imadvisor_date_format = 'YYYY-MON-DD HH24:MI:SS';

Rem exit if DBMS_INMEMORY_ADVISOR is not installed.
WHENEVER SQLERROR EXIT SQL.SQLCODE;
DECLARE
  local_db_type VARCHAR2(1000);
  errm  VARCHAR2(32767);
BEGIN
  EXECUTE IMMEDIATE
    'SELECT dbms_inmemory_advisor.local_database_type() FROM DUAL'
  INTO local_db_type;
EXCEPTION
  WHEN OTHERS THEN
    errm := SQLERRM;
    RAISE_APPLICATION_ERROR (-20001,
'Package DBMS_INMEMORY_ADVISOR is not available: '||errm);
END;
/

WHENEVER SQLERROR CONTINUE;

PROMPT
PROMPT
PROMPT This script creates and runs an In-Memory Advisor task that analyzes
PROMPT your workload to determine an optimal In-Memory configuration.
PROMPT
PROMPT This script then generates an HTML recommendation report file in the
PROMPT current working  directory: imadvisor_<task_name>.html
PROMPT
PROMPT This script also generates a sqlplus DDL script to implement the
PROMPT recommendations: imadvisor_<task_name>.sql
PROMPT

COLUMN existing_task_count NOPRINT NEW_VALUE existing_task_count;
SET TERMOUT OFF;
SELECT COUNT(*) AS existing_task_count FROM user_ima_task_information;
SET TERMOUT ON;
COLUMN existing_task_count CLEAR;

DECLARE
  newline  CONSTANT VARCHAR2(1) := '
';
BEGIN
  IF TO_NUMBER('&&existing_task_count') > 0 THEN
    dbms_output.put_line ('NOTE: You may specify one of your existing tasks if you wish to optimize for a');
    dbms_output.put_line ('different In-Memory size.'||newline);
    dbms_output.put_line ('Using an existing, executed task is faster than a new task since a new task');
    dbms_output.put_line ('requires statistics gathering and analysis.'||newline);
    dbms_output.put_line ('But if you wish to analyze a different workload or use a different statistics');
    dbms_output.put_line ('capture window or add a SQLSET, you must specify a new task.'||newline);
    dbms_output.put_line ('The following is a list of your existing tasks:'||newline);
  ELSE
    dbms_output.put_line ('NOTE: Once you have existing tasks, you can use this script again with a task');
    dbms_output.put_line ('that has already gathered and analyzed statistics to optimize for a different');
    dbms_output.put_line ('In-Memory size.'||newline);
  END IF;
END;
/

COLUMN task_name FORMAT A30;
SELECT   task_name, TO_CHAR(date_created,'&&imadvisor_date_format') AS date_created
FROM     user_ima_task_information
ORDER BY date_created ASC, task_name;
COLUMN task_name CLEAR;

Rem im_task_name is deprecated and replaced by task_name
Rem If both are specified, task_name takes precedence.
COLUMN im_task_name NOPRINT NEW_VALUE im_task_name;
SET TERMOUT OFF;
SELECT NULL AS im_task_name FROM DUAL WHERE NULL IS NOT NULL;
COLUMN im_task_name CLEAR;
SET TERMOUT ON;

SET HEADING OFF;
SELECT DECODE('&&im_task_name',
                NULL, '',
                      'Info: substitution variable IM_TASK_NAME has been deprecated and replaced with TASK_NAME'
             ) AS info_message
FROM   DUAL
WHERE  '&&im_task_name' IS NOT NULL;
SET HEADING ON;

COLUMN task_name NOPRINT NEW_VALUE task_name;
SET TERMOUT OFF;
SELECT NULL AS task_name FROM DUAL WHERE NULL IS NOT NULL;
COLUMN task_name CLEAR;
SET TERMOUT ON;

SET HEADING OFF;
SELECT DECODE('&&task_name',
                NULL, DECODE('&&im_task_name',
                               NULL, '',
                                     'Info: TASK_NAME=''&&im_task_name'' taken from deprecated substitution variable IM_TASK_NAME'
                            ),
                      DECODE('&&im_task_name',
                               NULL, '',
                                     'Info: TASK_NAME=''&&task_name'' supersedes deprecated substitution variable IM_TASK_NAME'
                            )
             ) AS info_message
FROM DUAL;
SET HEADING ON;

COLUMN task_name NOPRINT NEW_VALUE task_name;
SET TERMOUT OFF;
SELECT NVL('&&task_name','&&im_task_name') AS task_name FROM DUAL;
SET TERMOUT ON;
COLUMN task_name CLEAR;
UNDEFINE im_task_name;

COLUMN save_task_name NOPRINT NEW_VALUE save_task_name;
SET TERMOUT OFF;
SELECT '&&task_name' AS save_task_name FROM DUAL;
SET TERMOUT ON;
COLUMN save_task_name CLEAR;
UNDEFINE task_name;
COLUMN setvar NOPRINT NEW_VALUE setvar;
SET TERMOUT OFF;
SELECT DECODE('&&save_task_name',NULL,'imadvisor_trash','task_name') AS setvar FROM DUAL;
SET TERMOUT ON;
COLUMN setvar CLEAR;
COLUMN &&setvar NOPRINT NEW_VALUE &&setvar;
SET TERMOUT OFF;
SELECT '&&save_task_name' AS &&setvar FROM DUAL;
SET TERMOUT ON;
COLUMN &&setvar NOPRINT;
COLUMN &&setvar CLEAR;
UNDEFINE setvar;
UNDEFINE imadvisor_trash;

COLUMN default_task_name NOPRINT NEW_VALUE default_task_name;
SET TERMOUT OFF;
SELECT 'im_advisor_task_'||TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS') AS default_task_name FROM DUAL;
SET TERMOUT ON;
COLUMN default_task_name CLEAR;

SET HEADING OFF;
SELECT 'Default task_name (new task): &&default_task_name'
FROM   DUAL
WHERE  '&&save_task_name' IS NULL;
SET HEADING ON;

COLUMN task_name NOPRINT NEW_VALUE task_name;
SET HEADING OFF;
SELECT 'Advisor task name specified: '||
        (CASE WHEN '&&task_name' IS NULL
              THEN '&&default_task_name (default)'
              ELSE '&&task_name' END) AS task_name_description,
       (CASE WHEN '&&task_name' IS NULL
              THEN '&&default_task_name'
              ELSE '&&task_name' END) AS task_name 
FROM DUAL;
SET HEADING ON;
UNDEFINE default_task_name;
COLUMN task_name CLEAR;

COLUMN task_exists   NOPRINT NEW_VALUE task_exists;
COLUMN stats_added   NOPRINT NEW_VALUE stats_added;
COLUMN task_executed NOPRINT NEW_VALUE task_executed;
SET TERMOUT OFF;
SELECT 'Y'          AS task_exists,
       stats_added  AS stats_added,
       executed     AS task_executed
FROM   user_ima_task_information
WHERE  task_name='&&task_name';
SELECT NVL('&&task_exists','N')    AS task_exists,
       NVL('&&stats_added','N')    AS stats_added,
       NVL('&&task_executed','N')  AS task_executed
FROM   DUAL;
SET TERMOUT ON;
COLUMN task_exists    CLEAR;
COLUMN stats_added    CLEAR;
COLUMN task_executed  CLEAR;

SET HEADING OFF;
SELECT 'New Advisor task will be named: &&task_name....'
FROM    DUAL
WHERE   '&&task_exists' = 'N';
SET HEADING ON;

--------------------------------------------------------------------------------
Rem Show any augments.  If any, prompt for the dbid.
Rem Then check for instance numbers and pdb_names.

COLUMN local_dbid             NOPRINT NEW_VALUE  local_dbid;
COLUMN augmented_awrs         NOPRINT NEW_VALUE  augmented_awrs;

SET TERMOUT OFF;

SELECT dbid AS local_dbid
FROM   v$database;

SELECT 'Y' AS augmented_awrs
FROM   dba_ima_awr_augments diaa
WHERE  diaa.dbid             <> &&local_dbid
  AND  diaa.augment_enabled  =  'Y'
  AND  diaa.awr_loaded       =  'Y'
  AND  ROWNUM                =  1;
SELECT NVL('&&augmented_awrs','N') AS augmented_awrs
FROM   DUAL;

SET TERMOUT ON;

COLUMN local_dbid           CLEAR;
COLUMN augmented_awrs       CLEAR;

COLUMN run_against_augmented_awr      NOPRINT NEW_VALUE run_against_augmented_awr;
COLUMN run_against_augmented_awr_save NOPRINT NEW_VALUE run_against_augmented_awr_save;
COLUMN setvar                         NOPRINT NEW_VALUE setvar;
SET TERMOUT OFF;
SELECT NULL AS run_against_augmented_awr FROM DUAL WHERE NULL IS NOT NULL;
SELECT '&&run_against_augmented_awr' AS run_against_augmented_awr_save FROM DUAL;
UNDEFINE run_against_augmented_awr;
SELECT CASE WHEN '&&task_exists'    = 'Y'
              OR '&&augmented_awrs' = 'N'
              OR '&&run_against_augmented_awr_save' IS NOT NULL
            THEN 'run_against_augmented_awr'
            ELSE 'imadvisor_trash'
       END AS setvar
FROM DUAL;
COLUMN &&setvar NOPRINT NEW_VALUE &&setvar;
SELECT '&&run_against_augmented_awr_save' AS &&setvar FROM DUAL;
SET TERMOUT ON;
COLUMN run_against_augmented_awr      CLEAR;
COLUMN run_against_augmented_awr_save CLEAR;
COLUMN setvar   CLEAR;
COLUMN &&setvar NOPRINT;
COLUMN &&setvar CLEAR;

DECLARE
  newline  CONSTANT VARCHAR2(1) := '
';
BEGIN
  IF  '&&task_exists'     = 'N'
  AND '&&augmented_awrs'  = 'Y' THEN
    dbms_output.put_line (newline||'By default, the Advisor runs against a live workload on this database.');
    dbms_output.put_line ('This database also has imported, augmented AWR workloads.'||newline);
    dbms_output.put_line ('Press ENTER or respond NO to run against a live workload.');
    dbms_output.put_line ('Respond YES to run against an augmented AWR workload.'||newline);
  END IF;
END;
/

SET HEADING OFF;
SELECT '&&run_against_augmented_awr' FROM DUAL WHERE NULL IS NOT NULL;
SET HEADING ON;

DECLARE
  newline                CONSTANT VARCHAR2(1) := '
';

  CURSOR augmented_awr_imports IS
    SELECT   diaa.dbid
    FROM     dba_ima_awr_augments diaa
    WHERE    diaa.augment_enabled  =  'Y'
      AND    diaa.dbid             <> &&local_dbid -- this should never happen
      AND    diaa.awr_loaded       =  'Y'
    ORDER BY diaa.dbid;

BEGIN

  IF  '&&task_exists'    = 'N'
  AND '&&augmented_awrs' = 'Y'
  AND UPPER('&&run_against_augmented_awr') IN ('YES','Y') THEN

    dbms_output.put_line (newline||'The Advisor can use the following augmented AWR imports:'||newline);
    dbms_output.put_line ('Augmented AWR Import DBID');
    dbms_output.put_line ('-------------------------');
    FOR aai IN augmented_awr_imports LOOP
      dbms_output.put_line (aai.dbid);
    END LOOP;

  END IF;

END;
/

SET HEADING OFF;
SELECT ''
FROM   DUAL
WHERE  '&&task_exists'   = 'N'
  AND '&&augmented_awrs' = 'Y'
  AND UPPER('&&run_against_augmented_awr') IN ('YES','Y');
SET HEADING ON;

--------------------------------------------------------------------------------

COLUMN setvar NOPRINT NEW_VALUE setvar;
SET TERMOUT OFF;
SELECT CASE WHEN '&&task_exists'    = 'Y'
              OR '&&augmented_awrs' = 'N'
              OR NVL(UPPER('&&run_against_augmented_awr'),'NO') NOT IN ('YES','Y')
            THEN 'dbid'
            ELSE 'imadvisor_trash'
       END AS setvar
FROM   DUAL;

COLUMN &&setvar NOPRINT NEW_VALUE &&setvar;
SELECT &&local_dbid AS &&setvar FROM DUAL;
SET TERMOUT ON;
COLUMN setvar CLEAR;
COLUMN &&setvar NOPRINT;
COLUMN &&setvar CLEAR;

SET HEADING OFF;
COLUMN dbid NOPRINT NEW_VALUE dbid;
SELECT CASE WHEN '&&task_exists'    = 'N'
             AND '&&augmented_awrs' = 'Y'
             AND NVL(UPPER('&&run_against_augmented_awr'),'NO') IN ('YES','Y')
            THEN '&&dbid'
            ELSE NVL('&&dbid','&&local_dbid')
       END AS dbid FROM DUAL;
COLUMN dbid CLEAR;
SET HEADING ON;

WHENEVER SQLERROR EXIT SQL.SQLCODE;
DECLARE
  c  NUMBER;
BEGIN
  IF  '&&task_exists'    = 'N' THEN
    IF '&&augmented_awrs' = 'Y'
    AND NVL(UPPER('&&run_against_augmented_awr'),'NO') IN ('YES','Y') THEN
      IF '&&dbid' IS NULL THEN
        RAISE_APPLICATION_ERROR (-20001, 'You must specify the DBID to run against an augmented AWR workload');
      END IF;
      SELECT COUNT(*) INTO c
      FROM   dba_ima_awr_augments
      WHERE  dbid = '&&dbid'
        AND  augment_enabled = 'Y'
        AND  awr_loaded      = 'Y';
      IF c = 0 THEN
        RAISE_APPLICATION_ERROR (-20001, 'DBID &&dbid not found in augmented AWR workloads');
      END IF;
      dbms_output.put_line ('Analyzing and reporting on an augmented AWR workload with DBID='||TRIM('&&dbid')||'...');
    ELSE
      dbms_output.put_line ('Analyzing and reporting on a live workload on this database (DBID='||TRIM('&&local_dbid')||')...');
    END IF;
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;

COLUMN setvar NOPRINT NEW_VALUE setvar;
SET TERMOUT OFF;
SELECT DECODE('&&task_exists',
                'Y', 'pdb_name',                                                                 -- The pdb_name need not be set with any existing task: set pdb_name=NULL
                     DECODE(&&dbid,
                              &&local_dbid, DECODE(dbms_inmemory_advisor.local_database_type(),
                                                     'CDB-root', 'imadvisor_trash',              -- The pdb_name is required a w/CDB root with a new task: set imadvisor_trash=NULL
                                                     'pdb_name'                                  -- Otherwise, the pdb_name not needed: set pdb_name=NULL
                                                  ),
                                            ( SELECT DECODE(cdb_root, 'Y', 'imadvisor_trash',
                                                                           'pdb_name'
                                                           )
                                              FROM   dba_ima_awr_augments
                                              WHERE  dbid=&&dbid
                                                AND  augment_enabled = 'Y'
                                                AND  awr_loaded      = 'Y'
                                                AND  ROWNUM          = 1
                                            )
                           )
             ) AS setvar
FROM   DUAL;
SET TERMOUT ON;
COLUMN setvar CLEAR;
SET TERMOUT OFF;
COLUMN &&setvar NOPRINT NEW_VALUE &&setvar;
SELECT NULL AS &&setvar FROM DUAL;
SET TERMOUT ON;
COLUMN &&setvar NOPRINT;
COLUMN &&setvar CLEAR;
UNDEFINE setvar;
UNDEFINE imadvisor_trash;

 -- Will prompt for pdb_name if not set null:
SET HEADING OFF;
SELECT '&&pdb_name' AS pdb_name FROM DUAL;
SET HEADING ON;

--------------------------------------------------------------------------------
-- Changes for the 12.2+ PDB AWR store feature
COLUMN awr_pdb_count   NOPRINT NEW_VALUE awr_pdb_count;
COLUMN cdb_hist_count  NOPRINT NEW_VALUE cdb_hist_count;
SET TERMOUT OFF;
SELECT COUNT(*) AS awr_pdb_count
FROM   dba_views
WHERE  owner      = 'SYS'
  AND  view_name  = 'AWR_PDB_ASH_SNAPSHOT';
SELECT COUNT(*) AS cdb_hist_count
FROM   dba_views
WHERE  owner      = 'SYS'
  AND  view_name  = 'CDB_HIST_ASH_SNAPSHOT';

SET TERMOUT ON;
COLUMN awr_pdb_count   CLEAR;
COLUMN cdb_hist_count  CLEAR;

COLUMN setvar NOPRINT NEW_VALUE setvar;
SET TERMOUT OFF;
SELECT DECODE('&&task_exists',
                'Y', 'awr_store',                                                                                                -- awr_store prompt not needed with existing tasks: set awr_store=NULL
                     DECODE(&&dbid,
                              &&local_dbid, DECODE(dbms_inmemory_advisor.local_database_type(),                                  -- awr_store prompt only needed with a 12.2+ PDB live workload
                                                     'PDB', DECODE(TO_NUMBER(NVL(&&awr_pdb_count,0)), 0, 'awr_store',            -- awr_store prompt not need before 12.2: set awr_store=NULL
                                                                                                         'imadvisor_trash'       -- awr_store required w/12.2+ PDB live workload: set imadvisor_trash=NULL
                                                                  ),
                                                     'awr_store'                                                                 -- Otherwise, awr_store prompt not needed: set awr_store=NULL
                                                  ),
                                            'awr_store'                                                                          -- No awr_store prompts w/augmented AWR workloads: set awr_store=NULL
                           )
             ) AS setvar
FROM   DUAL;
SET TERMOUT ON;
COLUMN setvar CLEAR;
SET TERMOUT OFF;
COLUMN &&setvar NOPRINT NEW_VALUE &&setvar;
SELECT NULL AS &&setvar FROM DUAL;
SET TERMOUT ON;
COLUMN &&setvar NOPRINT;
COLUMN &&setvar CLEAR;

SET HEADING OFF;
SELECT
'When analyzing a live workload on a PDB, you have the option to use the
AWR root store (default) or AWR PDB store.
Press ENTER or specify ROOT or PDB:'
FROM   DUAL
WHERE  '&&setvar' = 'imadvisor_trash';
COLUMN awr_store NOPRINT NEW_VALUE awr_store;
SELECT NVL('&&awr_store','ROOT') AS awr_store
FROM   DUAL
WHERE  '&&setvar' = 'imadvisor_trash';
SET HEADING ON;
COLUMN awr_store CLEAR;
UNDEFINE setvar;
UNDEFINE imadvisor_trash;
WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF &&awr_pdb_count <> 0 AND UPPER('&&awr_store') NOT IN ('ROOT','PDB') THEN
    RAISE_APPLICATION_ERROR (-20001, 'Unrecognized AWR store: '||UPPER('&&awr_store')||', specify ROOT or PDB or press ENTER');
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;

COLUMN awr_view_prefix NOPRINT NEW_VALUE awr_view_prefix;
SET TERMOUT OFF;
SELECT DECODE(&&awr_pdb_count,
                0, DECODE(&&cdb_hist_count,                                                     -- With no AWR_PDB views, look for CDB_HIST views (AWR_PDB/AWR_ROOT added w/12.2)
                              0, 'dba_hist',                                                    -- With no CDB_HIST views, use DBA_HIST views
                                 'cdb_hist'                                                     -- With CDB_HIST views and no AWR_PDB views, use CDB_HIST
                           ),
                     DECODE(dbms_inmemory_advisor.local_database_type(),                        -- With AWR_PDB views, check the DB type
                              'PDB', DECODE(UPPER(SUBSTR('&&run_against_augmented_awr',1,1)),   -- With AWR_PDB views on a PDB, check if using augmented AWR workloads
                                       'Y', 'awr_pdb',                                          -- With AWR_PDB views on a PDB and augmented AWR workloads, use AWR_PDB
                                            DECODE(UPPER('&&awr_store'),                        -- With AWR_PDB views on a PDB and live workloads use awr_store setting
                                              'ROOT', 'awr_root',                               -- With AWR_PDB views on a PDB and live workloads and awr_store=ROOT, use awr_root
                                                      'awr_pdb'                                 -- With AWR_PDB views on a PDB and live workloads and awr_store<>ROOT, use awr_pdb
                                                  )
                                           ),
                                     'awr_pdb'                                                  -- With AWR_PDB views on a CDB-root or non-CDB, use awr_pdb (==> root store in this context)
                           )
             ) AS awr_view_prefix
FROM DUAL;
SET TERMOUT ON;
COLUMN awr_view_prefix CLEAR;


--------------------------------------------------------------------------------

COLUMN instance_count NOPRINT NEW_VALUE instance_count;
SET TERMOUT OFF;
SELECT COUNT(DISTINCT instance_number) AS instance_count
FROM   &&awr_view_prefix._ash_snapshot
WHERE  dbid=&&dbid;
SET TERMOUT ON;
COLUMN instance_count CLEAR;

COLUMN setvar NOPRINT NEW_VALUE setvar;
SET TERMOUT OFF;
SELECT  DECODE('&&task_exists',
                'Y', 'instance_number',
                     CASE WHEN &&instance_count > 1 THEN 'imadvisor_trash' ELSE 'instance_number' END
              ) AS setvar
FROM DUAL;
SET TERMOUT ON;

COLUMN setvar CLEAR;
COLUMN &&setvar NOPRINT NEW_VALUE &&setvar;
SET TERMOUT OFF;
SELECT NULL AS &&setvar FROM DUAL WHERE NULL IS NOT NULL;
SET TERMOUT ON;
COLUMN &&setvar NOPRINT;
COLUMN &&setvar CLEAR;

COLUMN min_instance_number NOPRINT NEW_VALUE min_instance_number;
SET TERMOUT OFF;
SELECT MIN(instance_number) AS min_instance_number
FROM   &&awr_view_prefix._ash_snapshot
WHERE  dbid=&&dbid;
SET TERMOUT ON;
COLUMN min_instance_number CLEAR;

SET HEADING OFF;
SELECT '' FROM DUAL WHERE &&instance_count > 1;
SELECT 'Choose one of the following instance numbers for this workload:'
FROM   DUAL
WHERE  &&instance_count > 1;
SELECT '' FROM DUAL WHERE &&instance_count > 1;
SET HEADING ON;
SELECT   snp.instance_number AS instance_number,
         DECODE(snp.instance_number,
                  TO_NUMBER('&&min_instance_number'), '       *        ',
                                                      '                '
               ) AS default_instance
FROM     ( SELECT DISTINCT instance_number
           FROM   &&awr_view_prefix._ash_snapshot
           WHERE  dbid=&&dbid
         ) snp         
WHERE    &&instance_count > 1
ORDER BY instance_number;

SET HEADING OFF;
SELECT '' FROM DUAL WHERE &&instance_count > 1;
SELECT 'The Advisor will analyze the workload from instance number '||TRIM(NVL('&&instance_number','&&min_instance_number'))||'.' AS status_update
FROM   DUAL
WHERE  &&instance_count > 1;
SET HEADING ON;

COLUMN instance_number NOPRINT NEW_VALUE instance_number;
SELECT TRIM(NVL('&&instance_number','&&min_instance_number')) AS instance_number
FROM   DUAL
WHERE  &&instance_count > 1;
COLUMN instance_number CLEAR;

-- ********************************************************************************
COLUMN inmemory_size NOPRINT NEW_VALUE inmemory_size;
SET TERMOUT OFF;
SELECT NULL AS inmemory_size FROM DUAL WHERE NULL IS NOT NULL;
SET TERMOUT ON;
COLUMN inmemory_size CLEAR;

DECLARE
  newline  CONSTANT VARCHAR2(1) := '
';
BEGIN
  IF '&&task_executed' = 'N' AND '&&inmemory_size' IS NULL THEN
    dbms_output.put_line (newline||'The In-Memory Advisor optimizes the In-Memory configuration for a specific');
    dbms_output.put_line ('In-Memory size that you choose.'||newline);

    dbms_output.put_line ('After analysis, the In-Memory Advisor can provide you a list of performance');
    dbms_output.put_line ('benefit estimates for a range of In-Memory sizes.  You may then choose the');
    dbms_output.put_line ('In-Memory size for which you wish to optimize.'||newline);

    dbms_output.put_line ('If you already know the specific In-Memory size you wish, please enter');
    dbms_output.put_line ('the value now.  Format: nnnnnnn[KB|MB|GB|TB]'||newline);

    dbms_output.put_line ('Or press <ENTER> to get performance estimates first.');
  END IF;
END;
/

COLUMN inmemory_size_save NOPRINT NEW_VALUE inmemory_size_save;
SET TERMOUT OFF;
SELECT '&&inmemory_size' AS inmemory_size_save FROM DUAL;
SET TERMOUT ON;
COLUMN inmemory_size_save CLEAR;

UNDEFINE inmemory_size;

COLUMN setvar NOPRINT NEW_VALUE setvar;
SET TERMOUT OFF;
SELECT DECODE('&&task_executed',
                'Y', 'inmemory_size',
                     DECODE('&&inmemory_size_save',
                              NULL, 'imadvisor_trash',
                                    'inmemory_size'
                           )
             ) AS setvar
FROM   DUAL;
SET TERMOUT ON;
COLUMN &&setvar NOPRINT NEW_VALUE &&setvar;
SET TERMOUT OFF;
SELECT '&&inmemory_size_save' AS &&setvar FROM DUAL;
SET TERMOUT ON;
COLUMN setvar   CLEAR;
COLUMN &&setvar CLEAR;

WHENEVER SQLERROR EXIT SQL.SQLCODE;
DECLARE
  imsize            VARCHAR2(1000) := UPPER(TRIM('&&inmemory_size'));
  imsize_suffix     VARCHAR2(2);
  imsize_prefix     VARCHAR2(1000);
  imsize_num        NUMBER;
BEGIN
  IF imsize IS NOT NULL THEN
    imsize_suffix := SUBSTR(imsize, LENGTH(imsize)-1);
    IF imsize_suffix IN ('KB','MB','GB','TB','PB','EB','ZB','YB') THEN
      imsize_prefix := SUBSTR(imsize, 1, LENGTH(imsize)-2);
    ELSE
      imsize_suffix := SUBSTR(imsize, LENGTH(imsize)-0);
      IF imsize_suffix IN ('K','M','G','T','P','E','Z','Y') THEN
        imsize_prefix := SUBSTR(imsize, 1, LENGTH(imsize)-1);
      ELSE
        imsize_prefix := imsize;
      END IF;
    END IF;
    BEGIN
      imsize_num := TO_NUMBER(imsize_prefix);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR (-20001, 'Unrecognized In-Memory size pattern: &&inmemory_size');
    END;
    IF imsize_num < 0 THEN
      RAISE_APPLICATION_ERROR (-20001, 'The In-Memory size you specified is '||UPPER(TRIM('&&inmemory_size'))||' bytes; the In-Memory size must not be less than zero');
    END IF;
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;

SET HEADING OFF;

SELECT 'The In-Memory Advisor will optimize for this In-Memory size: '||UPPER(TRIM('&&inmemory_size'))
FROM   DUAL
WHERE  '&&task_executed' = 'N'
  AND  '&&inmemory_size' IS NOT NULL;

SELECT 'The In-Memory Advisor will display performance benefit estimates after analysis.'
FROM   DUAL
WHERE  '&&task_executed' = 'N'
  AND  '&&inmemory_size' IS NULL;

SELECT '' FROM DUAL
WHERE  '&&task_executed' = 'N';

SET HEADING ON;

-- ********************************************************************************
DEFINE capture_time_format='MM/DD/YY HH24:MI:SS';

-- Accept the time interval
Rem
Rem Get btime
Rem =========
DECLARE
  newline  CONSTANT VARCHAR2(1) := '
';
  default_begin_time  VARCHAR2(100);
BEGIN
  IF '&&stats_added' = 'N' THEN
    dbms_output.put_line ('Enter begin time for report:'||newline);
    dbms_output.put_line ('--    Valid input formats:');
    dbms_output.put_line ('--      To specify absolute begin time:');
    dbms_output.put_line ('--        [MM/DD[/YY]] HH24:MI[:SS]');
    dbms_output.put_line ('--        Examples: 02/23/03 14:30:15');
    dbms_output.put_line ('--                  02/23 14:30:15');
    dbms_output.put_line ('--                  14:30:15');
    dbms_output.put_line ('--                  14:30');
    dbms_output.put_line ('--      To specify relative begin time: (start with ''-'' sign)');
    dbms_output.put_line ('--        -[HH24:]MI');
    dbms_output.put_line ('--        Examples: -1:15  (SYSDATE - 1 Hr 15 Mins)');
    dbms_output.put_line ('--                  -25    (SYSDATE - 25 Mins)'||newline);
    IF &&dbid = &&local_dbid THEN
      dbms_output.put_line ('Default begin time: -60');
    ELSE
      SELECT TO_CHAR(MIN(begin_interval_time),'&&capture_time_format')
      INTO   default_begin_time
      FROM   &&awr_view_prefix._ash_snapshot
      WHERE  dbid=&&dbid;
      dbms_output.put_line ('Default begin time: '||default_begin_time);
    END IF;
  END IF;
END;
/

COLUMN setvar NOPRINT NEW_VALUE setvar;
SET TERMOUT OFF;
SELECT DECODE('&&stats_added',
                'N', 'imadvisor_trash',
                     'begin_time'
             ) AS setvar
FROM DUAL;
COLUMN &&setvar NOPRINT NEW_VALUE &&setvar;
SELECT NULL AS &&setvar FROM DUAL;
SET TERMOUT ON;
COLUMN setvar CLEAR;
COLUMN &&setvar NOPRINT;
COLUMN &&setvar CLEAR;
UNDEFINE setvar;
UNDEFINE imadvisor_trash;
SET HEADING OFF;
SELECT 'Report begin time specified: &&begin_time' AS begin_time
FROM   DUAL
WHERE  '&&stats_added' = 'N';
SET HEADING ON;

PROMPT;


--
--  Set up the binds for btime
WHENEVER SQLERROR EXIT SQL.SQLCODE;
VARIABLE btime varchar2(30);
DECLARE
  lbtime_in         varchar2(100);
  begin_time        TIMESTAMP;

  FUNCTION get_time_from_begin_time( btime_in IN VARCHAR2 )
    RETURN TIMESTAMP
  IS
    first_char    VARCHAR2(2);
    in_str        VARCHAR2(100);

    past_hrs      NUMBER;
    past_mins     NUMBER;
    pos           NUMBER;

    num_slashes   NUMBER := 0;
    num_colons    NUMBER := 0;
    date_part     VARCHAR2(100);
    time_part     VARCHAR2(100);

    my_fmt        VARCHAR2(100) := '&&capture_time_format';
  BEGIN
    in_str := TRIM(btime_in);
    first_char := SUBSTR(in_str, 1, 1);

    /* Handle relative input format starting with a -ve sign, first */
    IF (first_char = '-') THEN
      in_str := SUBSTR(in_str, 2);
      pos := INSTR(in_str,':');
      IF (pos = 0) THEN
        past_hrs := 0;
        past_mins := TO_NUMBER(in_str);
      ELSE
        past_hrs := TO_NUMBER(SUBSTR(in_str,1,pos-1));
        past_mins := TO_NUMBER(SUBSTR(in_str,pos+1));
      END IF;
      
      IF (past_mins = 0 AND past_hrs = 0) THEN
        /* Invalid input */
        raise_application_error( -20001, 
                                 'Invalid input! Cannot recognize ' ||
                                 'input format for begin_time ' || '"' || 
                                 TRIM(btime_in) || '"' );
        RETURN NULL;
      END IF;

      RETURN (systimestamp - past_hrs/24 - past_mins/1440);
    END IF;

    /* Handle absolute input format now.
       Fill out all the missing optional parts of the input string
       to make it look like 'my_fmt' first. Then just do "return to_date()".
     */
    FOR pos in 1..NVL(LENGTH(in_str),0) LOOP
      IF (SUBSTR(in_str,pos,1) = '/') THEN
        num_slashes := num_slashes + 1;
      END IF;
      IF (SUBSTR(in_str,pos,1) = ':') THEN
        num_colons := num_colons + 1;
      END IF;
    END LOOP;

    IF (num_slashes > 0) THEN
      pos := INSTR(in_str,' ');
      date_part := TRIM(SUBSTR(in_str,1,pos-1));
      time_part := TRIM(SUBSTR(in_str,pos+1));

      IF (num_slashes = 1) THEN
        date_part := date_part || '/' || TO_CHAR(sysdate,'YY');
      END IF;
    ELSE
      date_part := TO_CHAR(sysdate,'MM/DD/YY');
      time_part := in_str;
    END IF;

    IF (num_colons > 0) THEN
      IF (num_colons = 1) THEN
        time_part := time_part || ':00';
      END IF;
      in_str := date_part || ' ' || time_part;
      BEGIN
        RETURN TO_TIMESTAMP(in_str, my_fmt);
      EXCEPTION
        WHEN OTHERS THEN
        /* Invalid input */
        raise_application_error( -20001, 
                                 'Invalid input! Cannot recognize ' ||
                                 'input format for begin_time ' || '"' || 
                                 TRIM(btime_in) || '"' );
      END;
    END IF;

    /* Invalid input */
    raise_application_error( -20001, 
                             'Invalid input! Cannot recognize ' ||
                             'input format for begin_time ' || '"' || 
                             TRIM(btime_in) || '"' );
    RETURN NULL;

  END get_time_from_begin_time;

BEGIN
  IF &&dbid = &&local_dbid THEN
    lbtime_in  := NVL('&&begin_time', '-60');
  ELSE
    SELECT TO_CHAR(MIN(begin_interval_time),'&&capture_time_format')
    INTO   lbtime_in
    FROM   &&awr_view_prefix._ash_snapshot
    WHERE  dbid=&&dbid;
  END IF;
  begin_time := get_time_from_begin_time(lbtime_in);
  :btime := to_char( begin_time, '&&imadvisor_time_format' );
END;
/
WHENEVER SQLERROR CONTINUE;


Rem
Rem Get etime
Rem =========
PROMPT
BEGIN
  IF '&&stats_added' = 'N' THEN
    dbms_output.put_line ('Enter duration in minutes starting from begin time:');
    IF &&dbid = &&local_dbid THEN
      dbms_output.put_line ('(defaults to SYSDATE - begin_time)');
    ELSE
      dbms_output.put_line ('(defaults to <latest-snapshot-end-time> - begin_time)');
    END IF;
  END IF;
END;
/

PROMPT
COLUMN setvar NOPRINT NEW_VALUE setvar;
SET TERMOUT OFF;
SELECT DECODE('&&stats_added',
                'N', 'imadvisor_trash',
                     'duration'
             ) AS setvar
FROM DUAL;
COLUMN &&setvar NOPRINT NEW_VALUE &&setvar;
SELECT NULL AS &&setvar FROM DUAL;
SET TERMOUT ON;
COLUMN setvar CLEAR;
COLUMN &&setvar NOPRINT;
COLUMN &&setvar CLEAR;
UNDEFINE imadvisor_trash;

SET HEADING OFF;
SELECT 'Report duration specified:   &&duration' AS duration
FROM   DUAL
WHERE  '&&stats_added' = 'N';
SET HEADING ON;

--
--  Set up the binds for etime
VARIABLE etime VARCHAR2(30);
DECLARE
  begin_date_stamp     DATE;
  end_date_stamp       DATE;
  duration             NUMBER;
  since_begin_time     NUMBER;
  begin_time           TIMESTAMP;
  end_time             TIMESTAMP;
BEGIN
  -- First calculate minutes since begin_time
  begin_time         := to_timestamp(:btime, '&&imadvisor_time_format');
  begin_date_stamp   := begin_time; -- auto conversion from timestamp to date

  IF &&dbid = &&local_dbid THEN
    end_date_stamp := SYSDATE;
  ELSE
    SELECT MAX(end_interval_time)
    INTO   end_date_stamp         -- auto conversion from timestamp to date
    FROM   &&awr_view_prefix._ash_snapshot
    WHERE  dbid=&&dbid;
  END IF;

  since_begin_time := (end_date_stamp - begin_date_stamp) * 24 * 60;

  -- Default to since_begin_time
  duration   := NVL('&&duration', since_begin_time);

  -- Put upper bound on user input to not go into the future
  -- only if begin_time is not already in the future
  IF (duration > since_begin_time AND since_begin_time > 0) THEN
    duration := since_begin_time;
  END IF;

  -- Calculate end_time and :etime
 
  end_time := begin_time + duration/(60 * 24);
  :etime := to_char( end_time, '&&imadvisor_time_format' );

END;
/

COLUMN nl80 FORMAT A80 NEWLINE;
SET HEADING OFF;

SELECT 'Using ' || :btime || ' as report begin time' AS nl80,
       'Using ' || :etime || ' as report end time'   AS nl80
FROM   DUAL
WHERE  '&&stats_added' = 'N';
COLUMN nl80 CLEAR;

BEGIN
  IF '&&task_exists' = 'N' THEN
    dbms_output.put_line ('
You may optionally specify a comma separated list of object owner');
    dbms_output.put_line ('and name patterns to be considered for In Memory Placement.');
    dbms_output.put_line ('Example:');
    dbms_output.put_line ('
GEEK_SUMMARY.%,%.GEEK_%');
    dbms_output.put_line ('
Press ENTER to consider all objects.');
  END IF;
END;
/
COLUMN setvar NOPRINT NEW_VALUE setvar;
SELECT DECODE('&&task_exists', 'Y', 'consider_objects_like',
                                     'imadvisor_trash') AS setvar
FROM DUAL;
COLUMN setvar CLEAR;
COLUMN &&setvar NOPRINT NEW_VALUE &&setvar;
SELECT NULL AS &&setvar FROM DUAL WHERE NULL IS NOT NULL;
COLUMN &&setvar CLEAR;
UNDEFINE imadvisor_trash;
SELECT DECODE ('&&consider_objects_like', NULL, 'Considering all objects for In Memory placement.',
                                                'Considering only objects matching these patterns for In Memory placement:')
FROM DUAL
WHERE '&&task_exists' = 'N';
SELECT '&&consider_objects_like'
FROM DUAL
WHERE '&&task_exists' = 'N' AND '&&consider_objects_like' IS NOT NULL;

SELECT 'In-Memory Advisor: Adding statistics...' AS status_message
FROM   DUAL
WHERE  '&&stats_added' = 'N';

SET HEADING ON;

WHENEVER SQLERROR EXIT SQL.SQLCODE;

DECLARE
  ts_format            CONSTANT CHAR(25)    := '&&imadvisor_time_format';
BEGIN

  -- create the task in IM
  -- Note: instance number can be NULL, so it must be quoted for compilation
  IF '&&task_exists' = 'N' THEN
    DBMS_INMEMORY_ADVISOR.CREATE_TASK('&&task_name', dbid=>&&dbid, pdb_name=>'&&pdb_name', instance_number=>TO_NUMBER('&&instance_number'), awr_store_source=>'&&awr_store');
  END IF;
  IF '&&stats_added' = 'N' THEN
    DBMS_INMEMORY_ADVISOR.ADD_STATISTICS('&&task_name', 
                   to_timestamp(:btime, ts_format),
                   to_timestamp(:etime, ts_format));
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;

SET HEADING OFF;

SELECT 'In-Memory Advisor: Finished adding statistics.' AS status_message
FROM   DUAL
WHERE  '&&stats_added' = 'N';

SELECT 'In-Memory Advisor: Analyzing statistics...' AS status_message
FROM   DUAL
WHERE  '&&task_executed' = 'N';

SET HEADING ON;

WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF '&&task_executed' = 'N' THEN
    DBMS_INMEMORY_ADVISOR.EXECUTE_TASK('&&task_name', consider_objects_like=>'&&consider_objects_like');
  END IF;
END;
/

WHENEVER SQLERROR CONTINUE;

SET HEADING OFF;
SELECT 'In-Memory Advisor: Finished analyzing statistics.' AS status_message
FROM   DUAL
WHERE  '&&task_executed' = 'N';
SET HEADING ON;

COLUMN inmemory_size NOPRINT NEW_VALUE inmemory_size;
SET TERMOUT OFF;
SELECT NULL AS inmemory_size FROM DUAL WHERE NULL IS NOT NULL;
SET TERMOUT ON;
COLUMN inmemory_size CLEAR;

SET HEADING OFF;
SELECT '' FROM DUAL WHERE '&&inmemory_size' IS NULL;
SELECT 'The Advisor estimates the following performance benefits:' FROM DUAL WHERE '&&inmemory_size' IS NULL;
SELECT '' FROM DUAL WHERE '&&inmemory_size' IS NULL;
DECLARE

  read_perf_factor  CONSTANT VARCHAR2(1000) := TRIM(TO_CHAR (dbms_inmemory_advisor.get_parameter ('INMEMORY_READ_PERF_FACTOR'), 999.9)||'X');
  spaces            CONSTANT VARCHAR2(100)  := '                                                                                                    ';

  CURSOR benefit_cost IS
    SELECT    bc.pct_max_recommended_imsize         AS pct_recommended_imsize,
              bc.inmemory_size                      AS inmemory_size,
              ROUND(bc.inmemory_size_bytes)         AS inmemory_size_bytes,
              ROUND(bc.pct_sga_max_size)            AS pct_sga_max_size,
              ROUND(bc.est_reduced_analytics_secs)  AS est_reduced_secs,
              bc.est_perf_improvement_factor        AS est_perf_factor
    FROM      user_ima_benefit_cost bc
    WHERE     task_name                 = '&&task_name'
      AND     is_incremental_step_size  = 'Y'
    ORDER  BY bc.inmemory_size_bytes DESC;

  FUNCTION justify_center_str (str IN VARCHAR2, col_width IN NUMBER) RETURN VARCHAR2 IS
    str_length   NUMBER;
    left_spaces  NUMBER;
    right_spaces NUMBER;
  BEGIN
    str_length   := NVL(LENGTH(TRIM(str)),0);
    left_spaces  := FLOOR((col_width-str_length) / 2);
    right_spaces := col_width - (str_length + left_spaces);
    RETURN SUBSTR (spaces, 1, left_spaces) || TRIM(str) || SUBSTR (spaces, 1, right_spaces);
  END justify_center_str;

  FUNCTION justify_center_num (num IN NUMBER, col_width IN NUMBER) RETURN VARCHAR2 IS
  BEGIN
    RETURN justify_center_str (TO_CHAR(num,'999999999999999999999999999999'), col_width);
  END justify_center_num;

BEGIN
  IF  '&&inmemory_size' IS NULL THEN
    dbms_output.put_line ('________________________________________________________________________');
    dbms_output.put_line ('|                                                                      |');
    dbms_output.put_line ('|                                    ESTIMATED      ESTIMATED          |');
    dbms_output.put_line ('|                                    ANALYTICS      ANALYTICS          |');
    dbms_output.put_line ('|                                    PROCESSING    PROCESSING          |');
    dbms_output.put_line ('|                    PERCENTAGE         TIME       PERFORMANCE         |');
    dbms_output.put_line ('|         IN-MEMORY  OF MAXIMUM      REDUCTION     IMPROVEMENT         |');
    dbms_output.put_line ('|           SIZE      SGA SIZE       (SECONDS)*      FACTOR*           |');
    dbms_output.put_line ('|         ---------  ----------  ----------------  -----------         |');
    FOR bc IN benefit_cost LOOP
    dbms_output.put_line
      ('|          ' 
       ||justify_center_str (bc.inmemory_size,           9)||'  '
       ||justify_center_num (bc.pct_sga_max_size,       10)||' '
       ||justify_center_num (bc.est_reduced_secs,       16)||' '
       ||justify_center_str (bc.est_perf_factor,        11)
       ||'          |'
      );
    END LOOP;
    dbms_output.put_line ('|                                                                      |');
    dbms_output.put_line ('| *Estimates: The In-Memory Advisor''s estimates are useful for making  |');
    dbms_output.put_line ('|  In-Memory decisions.  But they are not precise.  Due to performance |');
    dbms_output.put_line ('|  variations caused by workload diversity, the Advisor''s performance  |');
    dbms_output.put_line ('|  estimates are conservatively limited to no more than '||read_perf_factor||SUBSTR(spaces,1,15-LENGTH(read_perf_factor))||'|');
    dbms_output.put_line ('|  faster.                                                             |');
    dbms_output.put_line ('|                                                                      |');
    dbms_output.put_line ('|______________________________________________________________________|');
  END IF;
END;
/


COLUMN max_inmemory_size_bytes NOPRINT NEW_VALUE max_inmemory_size_bytes;
SET TERMOUT OFF;
SELECT TO_CHAR(NVL(MAX(inmemory_size_bytes),0),'999999999999999999999999999999') AS max_inmemory_size_bytes
FROM   user_ima_benefit_cost
WHERE  task_name = '&&task_name';
SET TERMOUT ON;
COLUMN max_inmemory_size_bytes CLEAR;

COLUMN max_inmemory_size NOPRINT NEW_VALUE max_inmemory_size;
SET TERMOUT OFF;
SELECT NVL(inmemory_size,0) AS max_inmemory_size
FROM   user_ima_benefit_cost
WHERE  task_name = '&&task_name'
  AND  inmemory_size_bytes >= &&max_inmemory_size_bytes;
SET TERMOUT ON;

COLUMN inmemory_size NOPRINT NEW_VALUE inmemory_size;
SET TERMOUT OFF;
SELECT DECODE(UPPER('&&inmemory_size'),
                'MAX', '&&max_inmemory_size',
                       '&&inmemory_size'
             ) AS inmemory_size
FROM DUAL;
SET TERMOUT ON;
COLUMN inmemory_size CLEAR;

SET HEADING OFF;
SELECT ''
FROM   DUAL
WHERE  '&&inmemory_size' IS NULL;
SELECT 'Choose the In-Memory size you wish for optimization (default=&&max_inmemory_size):'
FROM   DUAL
WHERE  '&&inmemory_size' IS NULL;
SET HEADING ON;

COLUMN inmemory_size_save NOPRINT NEW_VALUE inmemory_size_save;
SET TERMOUT OFF;
SELECT '&&inmemory_size' AS inmemory_size_save FROM DUAL;
SET TERMOUT ON;
COLUMN inmemory_size_save CLEAR;

UNDEFINE inmemory_size;

COLUMN setvar NOPRINT NEW_VALUE setvar;
SET TERMOUT OFF;
SELECT CASE WHEN '&&inmemory_size_save' IS NULL
            THEN 'imadvisor_trash'
            ELSE 'inmemory_size'
       END  AS setvar
FROM   DUAL;
COLUMN &&setvar NOPRINT NEW_VALUE &&setvar;
SELECT '&&inmemory_size_save' AS &&setvar FROM DUAL;
SET TERMOUT ON;
COLUMN setvar   CLEAR;
COLUMN &&setvar NOPRINT;
COLUMN &&setvar CLEAR;

COLUMN inmemory_size NOPRINT NEW_VALUE inmemory_size;
SET TERMOUT OFF;
SELECT DECODE(UPPER('&&inmemory_size'),
                'MAX', '&&max_inmemory_size',
                NULL,  '&&max_inmemory_size',
                       '&&inmemory_size'
             ) AS inmemory_size
FROM DUAL;
SET TERMOUT ON;
COLUMN inmemory_size CLEAR;

UNDEFINE inmemory_size_bytes;
COLUMN inmemory_size_bytes NOPRINT NEW_VALUE inmemory_size_bytes;
SET TERMOUT OFF;

Rem First try to get inmemory_size_bytes as an exact match with wri$_ima_benefit_cost.inmemory_size.
SELECT TO_CHAR(inmemory_size_bytes,'999999999999999999999999999999') AS inmemory_size_bytes
FROM   user_ima_benefit_cost
WHERE  TRIM(UPPER('&&inmemory_size')) = inmemory_size;

Rem If that came up NULL, convert the user-specified inmemory_size to inmemory_size_bytes.
SELECT TO_CHAR (
         DECODE  (inmemory_size,
                    '&&max_inmemory_size', TO_NUMBER('&&max_inmemory_size_bytes'),
                    CASE inmemory_size_suffix2
                      WHEN 'KB' THEN TO_NUMBER(inmemory_size_prefix2)*1024
                      WHEN 'MB' THEN TO_NUMBER(inmemory_size_prefix2)*1024*1024
                      WHEN 'GB' THEN TO_NUMBER(inmemory_size_prefix2)*1024*1024*1024
                      WHEN 'TB' THEN TO_NUMBER(inmemory_size_prefix2)*1024*1024*1024*1024
                      WHEN 'PB' THEN TO_NUMBER(inmemory_size_prefix2)*1024*1024*1024*1024*1024
                      WHEN 'EB' THEN TO_NUMBER(inmemory_size_prefix2)*1024*1024*1024*1024*1024*1024
                      WHEN 'ZB' THEN TO_NUMBER(inmemory_size_prefix2)*1024*1024*1024*1024*1024*1024*1024
                      WHEN 'YB' THEN TO_NUMBER(inmemory_size_prefix2)*1024*1024*1024*1024*1024*1024*1024*1024
                      ELSE CASE inmemory_size_suffix1
                        WHEN 'K' THEN TO_NUMBER(inmemory_size_prefix1)*1024
                        WHEN 'M' THEN TO_NUMBER(inmemory_size_prefix1)*1024*1024
                        WHEN 'G' THEN TO_NUMBER(inmemory_size_prefix1)*1024*1024*1024
                        WHEN 'T' THEN TO_NUMBER(inmemory_size_prefix1)*1024*1024*1024*1024
                        WHEN 'P' THEN TO_NUMBER(inmemory_size_prefix1)*1024*1024*1024*1024*1024
                        WHEN 'E' THEN TO_NUMBER(inmemory_size_prefix1)*1024*1024*1024*1024*1024*1024
                        WHEN 'Z' THEN TO_NUMBER(inmemory_size_prefix1)*1024*1024*1024*1024*1024*1024*1024
                        WHEN 'Y' THEN TO_NUMBER(inmemory_size_prefix1)*1024*1024*1024*1024*1024*1024*1024*1024
                        ELSE TO_NUMBER(inmemory_size)
                      END
                    END
                 ),
                 '999999999999999999999999999999'
               ) AS inmemory_size_bytes
FROM ( SELECT TRIM('&&inmemory_size')                                                           AS inmemory_size,
              SUBSTR(TRIM('&&inmemory_size'),1,NVL(LENGTH(TRIM('&&inmemory_size')),0)-1)        AS inmemory_size_prefix1,
              UPPER(SUBSTR(TRIM('&&inmemory_size'),NVL(LENGTH(TRIM('&&inmemory_size')),0)-0))   AS inmemory_size_suffix1,
              SUBSTR(TRIM('&&inmemory_size'),1,NVL(LENGTH(TRIM('&&inmemory_size')),0)-2)        AS inmemory_size_prefix2,
              UPPER(SUBSTR(TRIM('&&inmemory_size'),NVL(LENGTH(TRIM('&&inmemory_size')),0)-1))   AS inmemory_size_suffix2
       FROM   DUAL
     )
WHERE '&&inmemory_size_bytes' IS NULL;

SELECT NULL AS inmemory_size_bytes FROM DUAL WHERE NULL IS NOT NULL;
SET TERMOUT ON;
COLUMN inmemory_size_bytes CLEAR;

WHENEVER SQLERROR EXIT SQL.SQLCODE;
BEGIN
  IF '&&inmemory_size_bytes' IS NULL THEN
    RAISE_APPLICATION_ERROR (-20001, 'Unrecognized In-Memory size pattern: &&inmemory_size');
  END IF;
  IF TO_NUMBER('&&inmemory_size_bytes') < 0 THEN
    RAISE_APPLICATION_ERROR (-20001, 'The In-Memory size you specified is '||UPPER(TRIM('&&inmemory_size'))||' bytes; the In-Memory size must not be less than zero');
  END IF;
END;
/
WHENEVER SQLERROR CONTINUE;

SET HEADING OFF;
SELECT 'The Advisor is optimizing for an In-Memory size of '||UPPER('&&inmemory_size')||'...' AS status_update
FROM DUAL;
SET HEADING ON;

EXEC dbms_inmemory_advisor.generate_recommendations ('&&task_name', inmemory_size=>TO_NUMBER('&&inmemory_size_bytes'), single_page_report=>TRUE, directory_name=>NULL);

DEFINE client_directory_path='.';
@@imadvisor_fetch_recommendations.sql

PROMPT
PROMPT You can re-run this task with this script and specify a different an In-Memory
PROMPT size.  Re-running a task to optimize for a different In-Memory size is faster
PROMPT than creatng and running a new task from scratch.
PROMPT

-- UNDEFINE variables
UNDEFINE imadvisor_time_format;
UNDEFINE imadvisor_date_format;
UNDEFINE capture_time_format;
UNDEFINE client_directory_path;
UNDEFINE existing_task_count;
UNDEFINE im_task_name;
UNDEFINE task_name;
UNDEFINE save_task_name;
UNDEFINE setvar;
UNDEFINE imadvisor_trash;
UNDEFINE default_task_name;
UNDEFINE task_exists;
UNDEFINE stats_added;
UNDEFINE task_executed;
UNDEFINE run_against_augmented_awr;
UNDEFINE run_against_augmented_awr_save;
UNDEFINE local_dbid;
UNDEFINE dbid;
UNDEFINE awr_pdb_count;
UNDEFINE cdb_hist_count;
UNDEFINE instance_count;
UNDEFINE min_instance_number;
UNDEFINE instance_number;
UNDEFINE pdb_name;
UNDEFINE awr_store;
UNDEFINE awr_view_prefix;
UNDEFINE inmemory_size;
UNDEFINE inmemory_size_save;
UNDEFINE max_inmemory_size_bytes;
UNDEFINE max_inmemory_size;
UNDEFINE augmented_awrs;
UNDEFINE begin_time;
UNDEFINE duration;

SET FEEDBACK OFF;
EXEC :btime := NULL;

SET FEEDBACK      ON;
SET VERIFY        ON;
SET TRIMSPOOL     OFF;
SET TAB           ON;
SET PAGESIZE      14;
SET SERVEROUTPUT  OFF;

WHENEVER SQLERROR CONTINUE;

UNDEFINE script_in_progress;
