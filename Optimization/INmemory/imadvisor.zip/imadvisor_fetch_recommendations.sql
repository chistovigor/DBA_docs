Rem
Rem $Header: rdbms/admin/imadvisor_fetch_recommendations.sql jraitto_imadvisor_12_2_adefix/2 2016/08/15 12:09:13 jraitto Exp $
Rem
Rem imadvisor_fetch_recommendations.sql
Rem
Rem Copyright (c) 2015, 2016, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      imadvisor_fetch_recommendations.sql - fetch generated recommendations
Rem
Rem    DESCRIPTION
Rem      fetch generated recommendations to client-side files
Rem
Rem    NOTES
Rem      1.  Use of this script requires write access to the current working
Rem          directory.
Rem
Rem      2.  Temporary fetch script imadvisor_fetch_temp.sql will be left in
Rem          the current working directory.
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/admin/imadvisor_fetch_recommendations.sql 
Rem    SQL_SHIPPED_FILE: 
Rem    SQL_PHASE: 
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: 
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    jraitto     06/28/16 - change imadvisor_analyze_and_report to imadvisor_recommendations
Rem    jraitto     03/01/16 - Continuing edits
Rem    jraitto     02/20/16 - Continuing edits
Rem    jraitto     10/02/15 - Continuing edits
Rem    jraitto     08/21/15 - port to 12.2
Rem    jraitto     08/07/15 - derived from imadvisor_fetch_recommendations.sql
Rem                           (rdbms/src/server/svrman/im/) 1.0.0.0.1 build
Rem                           #540
Rem    jraitto     08/07/15 - Created, 1.0.0.0.1 build #540 history:
Rem    jraitto     04/27/15 - Determine Advisor schema name dynamically
Rem    jraitto     02/27/15 - bug 19404480
Rem    jraitto     01/26/15 - Continuing edits
Rem    jraitto     12/19/14 - fetch generated recommendations to client-side
Rem                           files
Rem    jraitto     12/19/14 - Created
Rem

WHENEVER SQLERROR EXIT SQL.SQLCODE;

SET HEADING       OFF;
SET NEWPAGE       NONE;
SET LINESIZE      200;
SET PAGESIZE      50000;
SET FEEDBACK      OFF;
SET VERIFY        OFF;
SET TRIMSPOOL     ON;
SET SERVEROUTPUT  ON;

SET TERMOUT       OFF;
COLUMN imadvisor_schema NOPRINT NEW_VALUE imadvisor_schema;
SELECT owner AS imadvisor_schema
FROM   dba_tables
WHERE  table_name = 'WRI$_IMA_MANIFEST';
COLUMN imadvisor_schema CLEAR;
SET TERMOUT       ON;

BEGIN
  IF '&&imadvisor_schema' IS NULL THEN
    RAISE_APPLICATION_ERROR (-20001, 'DBMS_INMEMORY_ADVISOR is not installed');
  END IF;
END;
/

COLUMN existing_task_count NOPRINT NEW_VALUE existing_task_count;
SET TERMOUT OFF;
SELECT COUNT(*) AS existing_task_count FROM user_ima_task_information;
SET TERMOUT ON;
COLUMN existing_task_count CLEAR;

BEGIN
  IF &&existing_task_count = 0 THEN
    RAISE_APPLICATION_ERROR (-20001, 'No In-Memory Advisor tasks exist for report generation: you can create tasks with the PL/SQL interface or imadvisor_recommendations.sql');
  END IF;
END;
/



Rem im_task_name is deprecated and replaced by task_name
Rem If both are specified, task_name takes precedence.
COLUMN im_task_name NOPRINT NEW_VALUE im_task_name;
SET TERMOUT OFF;
SELECT NULL AS im_task_name FROM DUAL WHERE NULL IS NOT NULL;
COLUMN im_task_name CLEAR;
SET TERMOUT ON;

SELECT DECODE('&&im_task_name',
                NULL, '',
                      'Info: substitution variable IM_TASK_NAME has been deprecated and replaced with TASK_NAME'
             ) AS info_message
FROM   DUAL
WHERE  '&&im_task_name' IS NOT NULL;

COLUMN task_name NOPRINT NEW_VALUE task_name;
SET TERMOUT OFF;
SELECT NULL AS task_name FROM DUAL WHERE NULL IS NOT NULL;
COLUMN task_name CLEAR;
SET TERMOUT ON;

SELECT DECODE('&&task_name',
                NULL, DECODE('&&im_task_name',
                               NULL, '',
                                     'Info: TASK_NAME=''&&im_task_name'' taken from deprecated substitution variable IM_TASK_NAME'
                            ),
                      DECODE('&&im_task_name',
                               NULL, '',
                                     'Info: TASK_NAME=''&&task_name'' supersedes deprecated substitution variable IM_TASK_NAME'
                            )
             ) AS info_message
FROM   DUAL
WHERE  DECODE('&&task_name',
                NULL, DECODE('&&im_task_name',
                               NULL, '',
                                     'Info: TASK_NAME=''&&im_task_name'' taken from deprecated substitution variable IM_TASK_NAME'
                            ),
                      DECODE('&&im_task_name',
                               NULL, '',
                                     'Info: TASK_NAME=''&&task_name'' supersedes deprecated substitution variable IM_TASK_NAME'
                            )
             ) IS NOT NULL;

COLUMN task_name NOPRINT NEW_VALUE task_name;
SET TERMOUT OFF;
SELECT NVL('&&task_name','&&im_task_name') AS task_name FROM DUAL;
SET TERMOUT ON;
COLUMN task_name CLEAR;
UNDEFINE im_task_name;

COLUMN save_task_name NOPRINT NEW_VALUE save_task_name;
SET TERMOUT OFF;
SELECT '&&task_name' AS save_task_name FROM DUAL;
SET TERMOUT ON;
COLUMN save_task_name CLEAR;
UNDEFINE task_name;
COLUMN setvar NOPRINT NEW_VALUE setvar;
SET TERMOUT OFF;
SELECT DECODE('&&save_task_name',NULL,'imadvisor_trash','task_name') AS setvar FROM DUAL;
SET TERMOUT ON;
COLUMN setvar CLEAR;
COLUMN &&setvar NOPRINT NEW_VALUE &&setvar;
SET TERMOUT OFF;
SELECT '&&save_task_name' AS &&setvar FROM DUAL;
SET TERMOUT ON;
COLUMN &&setvar CLEAR;
UNDEFINE setvar;
UNDEFINE imadvisor_trash;



PROMPT Fetching recommendation files for task: &&task_name

SELECT DECODE('&&client_directory_path',
                NULL, 'Placing recommendation files in: the current working directory',
                '.',  'Placing recommendation files in: the current working directory',
                      'Placing recommendation files in: directory &&client_directory_path'
             ) AS status_update
FROM DUAL;

COLUMN client_directory_path NOPRINT NEW_VALUE client_directory_path;
SET TERMOUT OFF;
SELECT DECODE('&&client_directory_path',
                NULL, '',
                '.',  '',
                      '&&client_directory_path/'
             ) AS client_directory_path
FROM DUAL;
SET TERMOUT ON;
COLUMN client_directory_path CLEAR;

DEFINE file_count=0;
COLUMN file_count NOPRINT NEW_VALUE file_count;
COLUMN spool_file NOPRINT NEW_VALUE spool_file;
COLUMN line_size  NOPRINT NEW_VALUE line_size;
COLUMN dir        NOPRINT NEW_VALUE dir;

--------------------------------------------------------------------------------
DEFINE task_file_name='imadvisor_&&task_name..html';
DEFINE file_purpose='recommendation report primary html page';

UNDEFINE spool_file;
SET TERMOUT OFF;
SELECT   file_name               AS spool_file,
         MAX(LENGTH(file_line))  AS line_size
FROM     user_ima_recommendation_lines
WHERE    task_name = '&&task_name'
  AND    file_name = '&&task_file_name'
GROUP BY file_name;
SELECT   NVL('&&spool_file','OFF') AS spool_file,
         NVL('&&line_size','200')  AS line_size
FROM     DUAL;

SELECT DECODE('&&spool_file','OFF','','&&client_directory_path') AS dir FROM DUAL;
SET LINESIZE &&line_size;
SPOOL &&dir&&spool_file;
SELECT   file_line
FROM     user_ima_recommendation_lines
WHERE    task_name='&&task_name'
  AND    file_name='&&task_file_name'
ORDER BY file_line_number;
SPOOL OFF;

SET TERMOUT ON;
SET NEWPAGE 1;
SELECT 'Fetched file: &&task_file_name' AS status_update,
       TO_NUMBER('&&file_count')+1 AS file_count
FROM   DUAL
WHERE  '&&spool_file' <> 'OFF';
SET NEWPAGE NONE;
SELECT 'Purpose:      &&file_purpose' AS file_purpose
FROM   DUAL
WHERE  '&&spool_file' <> 'OFF';

--------------------------------------------------------------------------------
DEFINE task_file_name='imadvisor_sql_&&task_name..html';
DEFINE file_purpose='SQL detail secondary html page with link from primary html page';

UNDEFINE spool_file;
SET TERMOUT OFF;
SELECT   file_name               AS spool_file,
         MAX(LENGTH(file_line))  AS line_size
FROM     user_ima_recommendation_lines
WHERE    task_name = '&&task_name'
  AND    file_name = '&&task_file_name'
GROUP BY file_name;
SELECT   NVL('&&spool_file','OFF') AS spool_file,
         NVL('&&line_size','200')  AS line_size
FROM     DUAL;

SELECT DECODE('&&spool_file','OFF','','&&client_directory_path') AS dir FROM DUAL;
SET LINESIZE &&line_size;
SPOOL &&dir&&spool_file;
SELECT   file_line
FROM     user_ima_recommendation_lines
WHERE    task_name='&&task_name'
  AND    file_name='&&task_file_name'
ORDER BY file_line_number;
SPOOL OFF;

SET TERMOUT ON;
SET NEWPAGE 1;
SELECT 'Fetched file: &&task_file_name' AS status_update,
       TO_NUMBER('&&file_count')+1 AS file_count
FROM   DUAL
WHERE  '&&spool_file' <> 'OFF';
SET NEWPAGE NONE;
SELECT 'Purpose:      &&file_purpose' AS file_purpose
FROM   DUAL
WHERE  '&&spool_file' <> 'OFF';

--------------------------------------------------------------------------------
DEFINE task_file_name='imadvisor_object_&&task_name..html';
DEFINE file_purpose='object detail secondary html page with link from primary html';

UNDEFINE spool_file;
SET TERMOUT OFF;
SELECT   file_name               AS spool_file,
         MAX(LENGTH(file_line))  AS line_size
FROM     user_ima_recommendation_lines
WHERE    task_name = '&&task_name'
  AND    file_name = '&&task_file_name'
GROUP BY file_name;
SELECT   NVL('&&spool_file','OFF') AS spool_file,
         NVL('&&line_size','200')  AS line_size
FROM     DUAL;

SELECT DECODE('&&spool_file','OFF','','&&client_directory_path') AS dir FROM DUAL;
SET LINESIZE &&line_size;
SPOOL &&dir&&spool_file;
SELECT   file_line
FROM     user_ima_recommendation_lines
WHERE    task_name='&&task_name'
  AND    file_name='&&task_file_name'
ORDER BY file_line_number;
SPOOL OFF;

SET TERMOUT ON;
SET NEWPAGE 1;
SELECT 'Fetched file: &&task_file_name' AS status_update,
       TO_NUMBER('&&file_count')+1 AS file_count
FROM   DUAL
WHERE  '&&spool_file' <> 'OFF';
SET NEWPAGE NONE;
SELECT 'Purpose:      &&file_purpose' AS file_purpose
FROM   DUAL
WHERE  '&&spool_file' <> 'OFF';

--------------------------------------------------------------------------------
DEFINE task_file_name='imadvisor_auxiliary_&&task_name..html';
DEFINE file_purpose='rationale secondary html page with link from primary html page';

UNDEFINE spool_file;
SET TERMOUT OFF;
SELECT   file_name               AS spool_file,
         MAX(LENGTH(file_line))  AS line_size
FROM     user_ima_recommendation_lines
WHERE    task_name = '&&task_name'
  AND    file_name = '&&task_file_name'
GROUP BY file_name;
SELECT   NVL('&&spool_file','OFF') AS spool_file,
         NVL('&&line_size','200')  AS line_size
FROM     DUAL;

SELECT DECODE('&&spool_file','OFF','','&&client_directory_path') AS dir FROM DUAL;
SET LINESIZE &&line_size;
SPOOL &&dir&&spool_file;
SELECT   file_line
FROM     user_ima_recommendation_lines
WHERE    task_name='&&task_name'
  AND    file_name='&&task_file_name'
ORDER BY file_line_number;
SPOOL OFF;

SET TERMOUT ON;
SET NEWPAGE 1;
SELECT 'Fetched file: &&task_file_name' AS status_update,
       TO_NUMBER('&&file_count')+1 AS file_count
FROM   DUAL
WHERE  '&&spool_file' <> 'OFF';
SET NEWPAGE NONE;
SELECT 'Purpose:      &&file_purpose' AS file_purpose
FROM   DUAL
WHERE  '&&spool_file' <> 'OFF';

--------------------------------------------------------------------------------
DEFINE task_file_name='imadvisor_&&task_name..sql';
DEFINE file_purpose='recommendation DDL sqlplus script';

UNDEFINE spool_file;
SET TERMOUT OFF;
SELECT   file_name               AS spool_file,
         MAX(LENGTH(file_line))  AS line_size
FROM     user_ima_recommendation_lines
WHERE    task_name = '&&task_name'
  AND    file_name = '&&task_file_name'
GROUP BY file_name;
SELECT   NVL('&&spool_file','OFF') AS spool_file,
         NVL('&&line_size','200')  AS line_size
FROM     DUAL;

SELECT DECODE('&&spool_file','OFF','','&&client_directory_path') AS dir FROM DUAL;
SET LINESIZE &&line_size;
SPOOL &&dir&&spool_file;
SELECT   file_line
FROM     user_ima_recommendation_lines
WHERE    task_name='&&task_name'
  AND    file_name='&&task_file_name'
ORDER BY file_line_number;
SPOOL OFF;

SET TERMOUT ON;
SET NEWPAGE 1;
SELECT 'Fetched file: &&task_file_name' AS status_update,
       TO_NUMBER('&&file_count')+1 AS file_count
FROM   DUAL
WHERE  '&&spool_file' <> 'OFF';
SET NEWPAGE NONE;
SELECT 'Purpose:      &&file_purpose' AS file_purpose
FROM   DUAL
WHERE  '&&spool_file' <> 'OFF';

--------------------------------------------------------------------------------

COLUMN file_count CLEAR;
COLUMN spool_file CLEAR;
COLUMN line_size  CLEAR;
COLUMN dir        CLEAR;

SELECT 'No recommendation files where found for task &&task_name..' AS status_update
FROM   DUAL
WHERE  TO_NUMBER('&&file_count') = 0;

UNDEFINE imadvisor_schema;
UNDEFINE existing_task_count;
UNDEFINE im_task_name;
UNDEFINE task_name;
UNDEFINE save_task_name;
UNDEFINE setvar;
UNDEFINE imadvisor_trash;
UNDEFINE client_directory_path;
UNDEFINE file_count;
UNDEFINE spool_file;
UNDEFINE line_size;
UNDEFINE dir;
UNDEFINE task_file_name;
UNDEFINE file_purpose;

SET HEADING       ON;
SET NEWPAGE       1;
SET LINESIZE      80;
SET PAGESIZE      14;
SET TERMOUT       ON;
SET FEEDBACK      ON;
SET VERIFY        ON;
SET TRIMSPOOL     OFF;
SET SERVEROUTPUT  OFF;

WHENEVER SQLERROR CONTINUE;
