--
-- $Header: rdbms/src/server/svrman/im/imadvisor_commoncode.sql jraitto_imadvisor_12_2_adefix/3 2016/11/10 20:34:50 jraitto Exp $
--
-- imadvisor_commoncode.sql
--
-- Copyright (c) 2015, 2016, Oracle and/or its affiliates. All rights reserved.
--
--    NAME
--      imadvisor_commoncode.sql - PL/SQL code shared with different scripts
--
--    DESCRIPTION
--      <short description of component this file declares/defines>
--
--    NOTES
--      This script must be invoked within the declaritive part of a PL/SQL
--      block (package body, procedure, function, anonymous).
--
--    BEGIN SQL_FILE_METADATA 
--    SQL_SOURCE_FILE: rdbms/src/server/svrman/im/imadvisor_commoncode.sql 
--    SQL_SHIPPED_FILE: 
--    SQL_PHASE: 
--    SQL_STARTUP_MODE: NORMAL 
--    SQL_IGNORABLE_ERRORS: NONE 
--    SQL_CALLING_FILE: 
--    END SQL_FILE_METADATA
--
--    MODIFIED   (MM/DD/YY)
--    jraitto     11/09/16 - Adjust to 12.2 AWR view changes
--    jraitto     04/19/16 - keep augment schema names <= 30
--    jraitto     02/20/16 - Continuing edits
--    jraitto     02/11/16 - Bug 21842458
--    jraitto     09/24/15 - replace seccheck_schema with seccheck_schema_name
--                           and use dbms_assert.simple_sql_name to allow
--                           checks on new-schema names
--    jraitto     09/22/15 - use dbms_assert w/user inputs for dynamic SQL
--    jraitto     09/18/15 - check for SQL injection
--    jraitto     06/30/15 - bugs 21348597, 21348650, 21348701
--    jraitto     06/10/15 - fix parameter fetches on CDB roots
--    jraitto     06/01/15 - PL/SQL code shared with different scripts
--    jraitto     06/01/15 - Created
--

--------------------------------------------------------------------------------
  FUNCTION seccheck_tblspace_name (userspec_tblspace_name IN VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    IF userspec_tblspace_name IS NULL THEN
      RETURN NULL;
    END IF;
    BEGIN
      RETURN  dbms_assert.simple_sql_name (userspec_tblspace_name);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR (-20001, 'Illegal tablespace name');
    END; 
  END seccheck_tblspace_name;

--------------------------------------------------------------------------------
  FUNCTION seccheck_pdb_name (userspec_pdb_name IN VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    IF userspec_pdb_name IS NULL THEN
      RETURN NULL;
    END IF;
    BEGIN
      RETURN  dbms_assert.simple_sql_name (userspec_pdb_name);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR (-20001, 'Illegal PDB name');
    END; 
  END seccheck_pdb_name;

--------------------------------------------------------------------------------
  FUNCTION seccheck_schema_name (userspec_schema_name IN VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    IF userspec_schema_name IS NULL THEN
      RETURN NULL;
    END IF;
    BEGIN
      -- Do not use dbms_assert.schema_name: userspec_schema_name need not exist
      RETURN  dbms_assert.simple_sql_name (userspec_schema_name);
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR (-20001, 'Illegal schema name');
    END; 
  END seccheck_schema_name;

--------------------------------------------------------------------------------
  FUNCTION local_database_type RETURN VARCHAR2 IS
    rv        VARCHAR2(10); -- 'non-CDB', 'CDB-root', 'PDB-seed', 'PDB'
    pdb_name  VARCHAR2(128);
  BEGIN
    BEGIN
      EXECUTE IMMEDIATE
        'SELECT CASE
                  WHEN db.cdb = ''YES''
                  THEN
                    CASE
                      WHEN db.dbid = db.con_dbid
                      THEN ''CDB-root''
                      ELSE ''PDB''
                    END
                  ELSE ''non-CDB''
                END AS what_am_i
         FROM   v$database db
         WHERE  ROWNUM = 1'
      INTO rv;
    EXCEPTION
      WHEN OTHERS THEN
        IF SQLCODE = -904 THEN
          rv := 'non-CDB';
        ELSE
          RAISE;
        END IF;
    END;
    IF rv = 'PDB' THEN
      SELECT SYS_CONTEXT('userenv', 'con_name')
      INTO   pdb_name
      FROM   DUAL;
      IF pdb_name = 'PDB$SEED' THEN
        rv := 'PDB-seed';
      END IF;
    END IF;
    RETURN rv;
  END local_database_type;

--------------------------------------------------------------------------------
  FUNCTION fetch_db_parameter (param_name IN VARCHAR2, con_id IN NUMBER) RETURN VARCHAR2 IS
    c   NUMBER;
    rv  VARCHAR2(4000);
  BEGIN
    SELECT COUNT(*) INTO c
    FROM   dba_tab_columns
    WHERE  owner        = 'SYS'
      AND  table_name   = 'V_$PARAMETER'
      AND  column_name  = 'CON_ID';
    BEGIN
      IF c = 0 THEN
        SELECT value INTO rv
        FROM    v$parameter
        WHERE   name    = param_name
          AND   ROWNUM  = 1;
      ELSE
        EXECUTE IMMEDIATE
          'SELECT value
           FROM ( SELECT   value
                  FROM     v$parameter
                  WHERE    name   = '''||param_name||'''
                    AND    con_id IN ('||NVL(con_id,0)||', 0, 1)
                  ORDER BY DECODE(con_id, 1, -1, con_id) DESC
                )
           WHERE ROWNUM = 1'
         INTO rv;
      END IF;
      RETURN rv;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RETURN NULL;
      WHEN OTHERS THEN
        RAISE;
    END;
  END fetch_db_parameter;

--------------------------------------------------------------------------------
  PROCEDURE fetch_local_db_info
    (userspec_pdb_name        IN  VARCHAR2,
     db_is_cdb_root           OUT BOOLEAN,
     db_is_pdb_seed           OUT BOOLEAN,
     db_is_pdb                OUT BOOLEAN,
     pdb_name                 OUT VARCHAR2,
     con_id                   OUT NUMBER,
     con_dbid                 OUT NUMBER,
     dbid                     OUT NUMBER,
     db_name                  OUT VARCHAR2,
     db_created               OUT DATE,
     instance_number          OUT NUMBER,
     instance_name            OUT VARCHAR2,
     instance_version         OUT VARCHAR2,
     instance_version_banner  OUT VARCHAR2,
     compatible_version       OUT VARCHAR2,
     service_name             OUT VARCHAR2,
     sga_max_size             OUT NUMBER,
     inmemory_size            OUT NUMBER,   -- With versions prior to 12.1.0.2 or if not set, 0.
     inmemory_unused_space    OUT NUMBER,   -- Ditto.
     ash_sample_interval      OUT NUMBER,
     ash_diskfilter_ratio     OUT NUMBER,
     db_supports_inmemory     OUT BOOLEAN) IS

    sec_userspec_pdb_name         VARCHAR2(128) := seccheck_pdb_name (userspec_pdb_name);
    sqlcode_no_such_tab_or_view   CONSTANT NUMBER          := -942;
    local_db_type                 VARCHAR2(100);
    c                             NUMBER;
  BEGIN

     db_is_cdb_root           := NULL;
     db_is_pdb                := NULL;
     pdb_name                 := NULL;
     con_id                   := NULL;
     con_dbid                 := NULL;
     dbid                     := NULL;
     db_name                  := NULL;
     db_created               := NULL;
     instance_number          := NULL;
     instance_name            := NULL;
     instance_version         := NULL;
     instance_version_banner  := NULL;
     compatible_version       := NULL;
     service_name             := NULL;
     sga_max_size             := NULL;
     inmemory_size            := NULL;
     inmemory_unused_space    := NULL;
     ash_sample_interval      := NULL;
     ash_diskfilter_ratio     := NULL;
     db_supports_inmemory     := NULL;

    local_db_type  := local_database_type();
    db_is_cdb_root := local_db_type = 'CDB-root';
    db_is_pdb_seed := local_db_type = 'PDB-seed';
    db_is_pdb      := local_db_type = 'PDB';
    BEGIN
      EXECUTE IMMEDIATE
        'SELECT NVL(pdb.pdb_id,0) AS my_con_id
         FROM   v$database db, cdb_pdbs pdb
         WHERE  db.con_dbid = pdb.dbid(+)
           AND  ROWNUM = 1'
      INTO con_id;
    EXCEPTION
      WHEN OTHERS THEN
        IF SQLCODE = sqlcode_no_such_tab_or_view THEN -- view cdb_pdbs is undefined (earlier database versions)
          IF local_db_type <> 'non-CDB' THEN
            RAISE;
          END IF;
          con_id := 0;
        ELSE
          RAISE;
        END IF;
    END;

    IF db_is_cdb_root THEN
      IF  sec_userspec_pdb_name IS NOT NULL THEN
        BEGIN
          EXECUTE IMMEDIATE
            'SELECT pdb.pdb_id, pdb.dbid, pdb.pdb_name
             FROM   cdb_pdbs pdb
             WHERE  pdb.pdb_name = '''|| sec_userspec_pdb_name||'''
               AND  ROWNUM   = 1'
          INTO fetch_local_db_info.con_id,
               fetch_local_db_info.con_dbid,
               fetch_local_db_info.pdb_name;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            con_id     := NULL;
            con_dbid   := NULL;
            pdb_name   := NULL;
          WHEN OTHERS THEN
            RAISE;
        END;
      ELSE
        con_id     := NULL;
        con_dbid   := NULL;
      END IF;
    ELSIF db_is_pdb THEN
      BEGIN
        EXECUTE IMMEDIATE
          'SELECT pdb.pdb_id, pdb.dbid, pdb.pdb_name
           FROM   cdb_pdbs pdb
           WHERE  ROWNUM = 1
             AND  (  '''|| sec_userspec_pdb_name||''' IS NULL
                  OR pdb.pdb_name = '''|| sec_userspec_pdb_name||'''
                  )'           
        INTO fetch_local_db_info.con_id,
             fetch_local_db_info.con_dbid,
             fetch_local_db_info.pdb_name;
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            IF sec_userspec_pdb_name IS NULL THEN
              RAISE_APPLICATION_ERROR (-20001, 'Internal error: db_is_pdb but no rows found in cdb_pdbs');
            END IF;
            con_id     := NULL;
            con_dbid   := NULL;
            pdb_name   := NULL;
          WHEN OTHERS THEN
            RAISE;
        END;
    ELSIF  sec_userspec_pdb_name IS NOT NULL THEN
      con_id     := NULL;
      con_dbid   := NULL;
      pdb_name   := NULL;
    END IF;

    IF (db_is_cdb_root OR db_is_pdb) AND con_id IS NOT NULL THEN
      BEGIN
        EXECUTE IMMEDIATE
          'SELECT pdb_name
           FROM   cdb_pdbs
           WHERE  pdb_id = '||con_id
        INTO fetch_local_db_info.db_name;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          RAISE_APPLICATION_ERROR (-20001, 'PDB_NAME not found, CON_ID='||con_id);
        WHEN OTHERS THEN
          RAISE;
      END;
    ELSIF  sec_userspec_pdb_name IS NULL THEN
      con_id := 0;
    END IF;

    SELECT dbid,
           name,
           created
    INTO   fetch_local_db_info.dbid,
           fetch_local_db_info.db_name,
           fetch_local_db_info.db_created
    FROM   v$database
    WHERE  ROWNUM=1;

    IF  sec_userspec_pdb_name IS NULL AND con_dbid IS NULL THEN
      IF con_id <> 0 THEN
        RAISE_APPLICATION_ERROR (-20001, 'Internal error: con_id<>0 AND con_dbid IS NULL');
      END IF;
      con_dbid := dbid;
    END IF;

    SELECT instance_number,
           instance_name,
           version
    INTO   fetch_local_db_info.instance_number,
           fetch_local_db_info.instance_name,
           fetch_local_db_info.instance_version
    FROM   v$instance
    WHERE  ROWNUM=1;

    SELECT banner
    INTO   fetch_local_db_info.instance_version_banner     
    FROM   v$version
    WHERE  banner LIKE 'Oracle Database %'
      AND  ROWNUM=1;

    compatible_version := NVL(fetch_db_parameter('compatible', con_id),
                              instance_version);

    SELECT value
    INTO   fetch_local_db_info.service_name
    FROM   v$listener_network
    WHERE  type='SERVICE NAME'
      AND  ROWNUM=1;

    sga_max_size := fetch_db_parameter('sga_max_size', con_id);

    inmemory_size := fetch_db_parameter('inmemory_size', con_id);

    IF inmemory_size > 0 THEN
      BEGIN
        EXECUTE IMMEDIATE
          'SELECT TO_NUMBER('||TO_CHAR(inmemory_size)||') - used_bytes
           FROM   ( SELECT    con_id, SUM(used_bytes) AS used_bytes
                    FROM      v$inmemory_area
                    WHERE     con_id IN ('||con_id||', 0, 1)
                    GROUP BY  con_id
                    ORDER BY  DECODE(con_id,1,-1,con_id) DESC
                  )
           WHERE  ROWNUM = 1'
        INTO fetch_local_db_info.inmemory_unused_space;
      EXCEPTION
        WHEN OTHERS THEN
          inmemory_unused_space := 0;
      END;
    ELSE
      inmemory_unused_space := 0;
    END IF;

    ash_sample_interval  := NVL(fetch_db_parameter('_ash_sample_interval',
                                                  con_id),
                                1000);

    ash_diskfilter_ratio := NVL(fetch_db_parameter('_ash_disk_filter_ratio',
                                                  con_id),
                                10);

    SELECT COUNT(*)
    INTO   c
    FROM   dba_views
    WHERE  view_name LIKE 'V%$INMEMORY%';
    db_supports_inmemory := c > 0;

  END fetch_local_db_info;

--------------------------------------------------------------------------------
  PROCEDURE fatal_dbid (dbid IN NUMBER) IS
  BEGIN
    RAISE_APPLICATION_ERROR (-20001, 
'DBID '||dbid||' is outside the legal range of 1..4294967295
If you loaded as follows:
SQL> @$ORACLE_HOME/rdbms/admin/awrload.sql '||dbid||'
Then unload as follows:
SQL> EXECUTE EXECUTE DBMS_WORKLOAD_REPOSITORY.DROP_SNAPSHOT_RANGE(0,9999999999,'||dbid||');
Then reload using a legal DBID.
');
  END fatal_dbid;

--------------------------------------------------------------------------------
  PROCEDURE verify_dbid_is_in_range (dbid IN NUMBER) IS
    con_id                                  NUMBER;
    sqlcode_invalid_identifier     CONSTANT NUMBER  := -904;
    sqlcode_argument_out_of_range  CONSTANT NUMBER  := -1428;
  BEGIN
    EXECUTE IMMEDIATE
      'SELECT con_dbid_to_id ('||dbid||') FROM DUAL'
    INTO   con_id;
  EXCEPTION
    WHEN OTHERS THEN
      IF SQLCODE = sqlcode_invalid_identifier THEN
        -- con_dbid_to_id not yet defined
        IF dbid < 1
        OR dbid > 4294967295 THEN
          fatal_dbid (dbid);
        END IF;        
      ELSIF SQLCODE = sqlcode_argument_out_of_range THEN
        fatal_dbid (dbid);
      ELSE
        RAISE;
      END IF;
  END verify_dbid_is_in_range;

--------------------------------------------------------------------------------
  FUNCTION random_password RETURN VARCHAR2 IS

    TYPE password_chars_t IS TABLE OF CHAR(1) INDEX BY PLS_INTEGER;
    password_chars        password_chars_t;

    lc_lo                 CONSTANT PLS_INTEGER := 1;
    lc_hi                 CONSTANT PLS_INTEGER := 26;
    uc_lo                 CONSTANT PLS_INTEGER := 27;
    uc_hi                 CONSTANT PLS_INTEGER := 52;
    num_lo                CONSTANT PLS_INTEGER := 53;
    num_hi                CONSTANT PLS_INTEGER := 62;
    sc_lo                 CONSTANT PLS_INTEGER := 63;
    sc_hi                 CONSTANT PLS_INTEGER := 81;
    all_lo                CONSTANT PLS_INTEGER := lc_lo;
    all_hi                CONSTANT PLS_INTEGER := sc_hi;

    TYPE char_type_info_t IS TABLE OF PLS_INTEGER INDEX BY PLS_INTEGER;
    char_type_lo         char_type_info_t;
    char_type_hi         char_type_info_t;
    min_char_type        CONSTANT PLS_INTEGER := 1;
    max_char_type        CONSTANT PLS_INTEGER := 4;
    char_type_count      CONSTANT PLS_INTEGER := 4;
    char_type            PLS_INTEGER;
    insert_i             PLS_INTEGER;

    rv                    VARCHAR2(30);
    max_pwd_len           CONSTANT PLS_INTEGER := 30;

  BEGIN

    password_chars(1)   := 'a'; -- lc
    password_chars(2)   := 'b';
    password_chars(3)   := 'c';
    password_chars(4)   := 'd';
    password_chars(5)   := 'e';
    password_chars(6)   := 'f';
    password_chars(7)   := 'g';
    password_chars(8)   := 'h';
    password_chars(9)   := 'i';
    password_chars(10)  := 'j';
    password_chars(11)  := 'k';
    password_chars(12)  := 'l';
    password_chars(13)  := 'm';
    password_chars(14)  := 'n';
    password_chars(15)  := 'o';
    password_chars(16)  := 'p';
    password_chars(17)  := 'q';
    password_chars(18)  := 'r';
    password_chars(19)  := 's';
    password_chars(20)  := 't';
    password_chars(21)  := 'u';
    password_chars(22)  := 'v';
    password_chars(23)  := 'w';
    password_chars(24)  := 'x';
    password_chars(25)  := 'y';
    password_chars(26)  := 'z';
    password_chars(27)  := 'A'; -- uc
    password_chars(28)  := 'B';
    password_chars(29)  := 'C';
    password_chars(30)  := 'D';
    password_chars(31)  := 'E';
    password_chars(32)  := 'F';
    password_chars(33)  := 'G';
    password_chars(34)  := 'H';
    password_chars(35)  := 'I';
    password_chars(36)  := 'J';
    password_chars(37)  := 'K';
    password_chars(38)  := 'L';
    password_chars(39)  := 'M';
    password_chars(40)  := 'N';
    password_chars(41)  := 'O';
    password_chars(42)  := 'P';
    password_chars(43)  := 'Q';
    password_chars(44)  := 'R';
    password_chars(45)  := 'S';
    password_chars(46)  := 'T';
    password_chars(47)  := 'U';
    password_chars(48)  := 'V';
    password_chars(49)  := 'W';
    password_chars(50)  := 'X';
    password_chars(51)  := 'Y';
    password_chars(52)  := 'Z';
    password_chars(53)  := '0'; -- num
    password_chars(54)  := '1';
    password_chars(55)  := '2';
    password_chars(56)  := '3';
    password_chars(57)  := '4';
    password_chars(58)  := '5';
    password_chars(59)  := '6';
    password_chars(60)  := '7';
    password_chars(61)  := '8';
    password_chars(62)  := '9';
    password_chars(63)  := '-'; -- sc
    password_chars(64)  := '_';
    password_chars(65)  := '.';
    password_chars(66)  := '~';
    password_chars(67)  := '#';
    password_chars(68)  := '$';
    password_chars(69)  := '%';
    password_chars(70)  := '^';
    password_chars(71)  := '*';
    password_chars(72)  := '-';
    password_chars(73)  := '_';
    password_chars(74)  := '+';
    password_chars(75)  := '=';
    password_chars(76)  := '{';
    password_chars(77)  := '}';
    password_chars(78)  := '[';
    password_chars(79)  := ']';
    password_chars(80)  := '<';
    password_chars(81)  := '>';

    char_type_lo(1)    := lc_lo;
    char_type_hi(1)    := lc_hi;

    char_type_lo(2)    := uc_lo;
    char_type_hi(2)    := uc_hi;

    char_type_lo(3)    := num_lo;
    char_type_hi(3)    := num_hi;

    char_type_lo(4)    := sc_lo;
    char_type_hi(4)    := sc_hi;

    WHILE (rv IS NULL OR LENGTH(rv) < (max_pwd_len-char_type_count)) LOOP
      rv := rv||password_chars(MOD(ABS(dbms_random.random),all_hi-all_lo)+all_lo);
    END LOOP;

    FOR char_type IN min_char_type .. max_char_type LOOP
      insert_i := MOD(ABS(dbms_random.random),LENGTH(rv))+1;
      rv := SUBSTR(rv,1,insert_i-1)
            ||password_chars(MOD(ABS(dbms_random.random),char_type_hi(char_type)-char_type_lo(char_type))+char_type_lo(char_type))
            ||SUBSTR(rv,insert_i);
    END LOOP;

    RETURN rv;

  END random_password;

--------------------------------------------------------------------------------
  FUNCTION augment_schema_name (dbid IN NUMBER)
  RETURN VARCHAR2 IS
    curr_date                  CONSTANT DATE         := SYSDATE;
    date_format                CONSTANT VARCHAR2(22) :=
      'YYYY-MON-DD HH24:MI:SS';
    basis_date                 CONSTANT DATE
    := TO_DATE('1970-JAN-01 00:00:00',date_format);
    hex8_format                CONSTANT VARCHAR2(8)  := '0XXXXXXX';
    hex8_max                   CONSTANT NUMBER
      := TO_NUMBER('FFFFFFFF', hex8_format);
    curr_date_hex              CONSTANT VARCHAR2(8)  :=
     TRIM(BOTH FROM
       TO_CHAR(MOD(((curr_date-basis_date)*(24*60*60)), hex8_max),
                   hex8_format
              )
         );
    dbid_hex                   CONSTANT VARCHAR2(8) :=
     TRIM(BOTH FROM
       TO_CHAR(MOD(dbid, hex8_max),
                   hex8_format
              )
         );
  BEGIN
    IF local_database_type() = 'CDB-root' THEN
      RETURN 'C##IMADVISOR_'|| curr_date_hex||'_'||dbid_hex;
    ELSE
      RETURN 'IMADVISOR_'|| curr_date_hex||'_'||dbid_hex;
    END IF;    
  END augment_schema_name;

--------------------------------------------------------------------------------
  -- Return NULL if no mapping is needed
  -- Note: With 1.0.0.0.0 AWR augments, CDB roots were not yet supported and AWR augment schema names were 30 characters long.
  -- When the CDB root C## prefix is added to a MOS1 AWR augment, the schema name is then 33 characters and needs to be truncated to 30 characters.
  -- With 1.0.0.0.1 and later, the non-CDB augment names are 27 characters long to allow for the C## prefix.
  FUNCTION map_schema_name (schema_name IN VARCHAR2)
  RETURN VARCHAR2 IS
    cdb_root_prefix  CONSTANT VARCHAR2(3) := 'C##';
  BEGIN
    IF local_database_type() = 'CDB-root' THEN
      IF SUBSTR(schema_name,1,LENGTH(cdb_root_prefix)) = cdb_root_prefix THEN
        RETURN NULL;
      ELSE
        RETURN SUBSTR(cdb_root_prefix||schema_name,1,30); -- Truncate from 33 to 30 characters with 1.0.0.0.0 AWR augments
      END IF;
    ELSE
      IF SUBSTR(schema_name,1,LENGTH(cdb_root_prefix)) = cdb_root_prefix THEN
        RETURN SUBSTR(schema_name,LENGTH(cdb_root_prefix)+1);
      ELSE
        RETURN NULL;
      END IF;
    END IF;
  END map_schema_name;

--------------------------------------------------------------------------------
  PROCEDURE create_schema
    (schema_name      IN VARCHAR2,
     password         IN VARCHAR2,
     perm_tablespace  IN VARCHAR2,
     temp_tablespace  IN VARCHAR2,
     if_exists        IN VARCHAR2) IS
    sec_schema_name      VARCHAR2(128) := seccheck_schema_name (schema_name);
    c        NUMBER;
    command  VARCHAR2(32767);
  BEGIN
    SELECT COUNT(*) INTO c
    FROM   sys.dba_users
    WHERE  username = sec_schema_name;
    IF c > 0 THEN
      IF if_exists = 'REUSE' THEN
        RETURN;
      ELSIF if_exists = 'REPLACE' THEN
        EXECUTE IMMEDIATE 'DROP USER '||sec_schema_name||' CASCADE';
      ELSE
        RAISE_APPLICATION_ERROR (-20001, if_exists);
      END IF;
    END IF;
    command := 'CREATE USER '||sec_schema_name||' IDENTIFIED BY "'||password||'"';
    IF perm_tablespace IS NOT NULL THEN
      command := command||' DEFAULT TABLESPACE '||perm_tablespace;
    END IF;
    IF temp_tablespace IS NOT NULL THEN
      command := command||' TEMPORARY TABLESPACE '||temp_tablespace;
    END IF;
    EXECUTE IMMEDIATE command;
    IF perm_tablespace IS NOT NULL
    OR temp_tablespace IS NOT NULL THEN
      EXECUTE IMMEDIATE 'GRANT UNLIMITED TABLESPACE TO '||sec_schema_name;
    END IF;
  END create_schema;
