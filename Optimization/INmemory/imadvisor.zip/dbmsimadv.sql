Rem
Rem $Header: rdbms/admin/dbmsimadv.sql jraitto_imadvisor_12_2_adefix/4 2017/01/04 14:08:18 jraitto Exp $
Rem
Rem dbmsimadv_src.sql
Rem
Rem Copyright (c) 2014, 2017, Oracle and/or its affiliates. 
Rem All rights reserved.
Rem
Rem    NAME
Rem      dbmsimadv.sql - DBMS_INMEMORY_ADVISOR package specification for the
Rem                      Oracle Database In-Memory Advisor
Rem
Rem    DESCRIPTION
Rem      PL/SQL interface to produce recommendations of objects to place into
Rem      in-memory (IM) columnar storage.  Placement of data in-memory can produce
Rem      dramatic performance improvements in a variety of types of processing, the
Rem      most significant of which is analytics processing.  The Orace Database In-Memory
Rem      Advisor produces recommendations for improved analytics processing
Rem      performance.
Rem
Rem
Rem    BEGIN SQL_FILE_METADATA 
Rem    SQL_SOURCE_FILE: rdbms/src/server/svrman/im/dbmsimadv.sql 
Rem    SQL_SHIPPED_FILE: 
Rem    SQL_PHASE: 
Rem    SQL_STARTUP_MODE: NORMAL 
Rem    SQL_IGNORABLE_ERRORS: NONE 
Rem    SQL_CALLING_FILE: 
Rem    END SQL_FILE_METADATA
Rem
Rem    MODIFIED   (MM/DD/YY)
Rem    jraitto     12/28/16 - add workload filter interface
Rem    jraitto     11/02/16 - Adjust to 12.2 AWR view changes
Rem    jraitto     02/19/16 - change USER in synonym to
Rem                           SYS_CONTEXT(USERENV,CURRENT_SCHEMA)
Rem    jraitto     09/21/15 - Change AUTHID to CURRENT_USER
Rem    jraitto     09/10/15 - Continuing edits
Rem    jraitto     08/13/15 - derived from dbmsimadv.sql
Rem    jraitto     06/03/15 - single-page html report option
Rem    jraitto     05/18/15 - CDB/PDB support
Rem    jraitto     02/12/15 - Public release: remove pre-release stuff
Rem    jraitto     01/19/15 - add tweakable parameter interface
Rem    jraitto     12/02/14 - Continuing edits
Rem    jraitto     10/30/14 - Continuing edits
Rem    jraitto     10/20/14 - add new generate_recommendations interface
Rem    jraitto     08/14/14 - Continuing edits
Rem    jraitto     08/04/14 - Continuing edits
Rem    jraitto     08/01/14 - Continuing edits
Rem    jraitto     07/21/14 - Continuing edits
Rem    jraitto     07/18/14 - Continuing edits
Rem    jraitto     06/20/14 - Continuing edits
Rem    jraitto     06/09/14 - Continuing edits
Rem    jraitto     05/28/14 - Continuing edits
Rem    jraitto     04/22/14 - DBMS_INMEMORY_ADVISOR package specification
Rem    jraitto     04/22/14 - Created
Rem

-- @@?/rdbms/admin/sqlsessstart.sql

CREATE OR REPLACE PACKAGE dbms_inmemory_advisor AUTHID CURRENT_USER AS

  -- The following constants are duplicated from DBMS_COMPRESSION, version 12.1.0.2
  comp_inmemory_nocompress      CONSTANT NUMBER := 8192;
  comp_inmemory_dml             CONSTANT NUMBER := 16384;
  comp_inmemory_query_low       CONSTANT NUMBER := 32768;
  comp_inmemory_query_high      CONSTANT NUMBER := 65536;
  comp_inmemory_capacity_low    CONSTANT NUMBER := 131072;
  comp_inmemory_capacity_high   CONSTANT NUMBER := 262144;

--------------------------------------------------------------------------------  
  PROCEDURE create_task (
    task_name             IN VARCHAR2,
    task_desc             IN VARCHAR2    := NULL,
    dbid                  IN NUMBER      := NULL,
    instance_number       IN NUMBER      := NULL,
    pdb_name              IN VARCHAR2    := NULL,
    awr_store_source      IN VARCHAR2    := NULL);
  -- CREATE_TASK creates a DBMS_INMEMORY_ADVISOR task.
  --
  -- Parameters:
  --
  --   task_name             A unique name up to 30 characters in length for
  --                         the DBMS_INMEMORY_ADVISOR task.
  --
  --   task_desc             Optional description of the task up to 256
  --                         characters in length.
  --
  --   dbid                  Database identifier from which statistics and data are to
  --                         be captured. By default or if you specify NULL, statistics
  --                         and data are captured from the database to which the
  --                         invoker of CREATE_TASK is connected.  If you specify a
  --                         different database identifier, you must first import
  --                         both an AWR export and an IM Advisor AWR augment.
  --
  --   instance_number       Database instance number from which statistics and data
  --                         are to be captured.  By default or if you specify NULL,
  --                         statistics and data are captured from the instance to
  --                         which the invoker of CREATE_TASK is connected.
  --
  --   pdb_name              The name of the PDB for which you desire in-memory
  --                         recommendations.
  --
  --                         When running against a live workload (using the
  --                         default DBID):
  --
  --                         o With a non-CDB, you must not specify pdb_name.
  --
  --                         o With a CDB root, you must specify pdb_name and
  --                           it must match one of the PDBs contained by the
  --                           CDB root.
  --
  --                         o With a PDB, pdb_name defaults to the connected
  --                           PDB name.  If you specify pdb_name, it must match
  --                           the connected PDB name.
  --
  --                         When running against an augmented AWR import (using
  --                         a DBID corresponding to an augmented AWR import):
  --
  --                         o An augmented AWR export from a non-CDB can be
  --                           imported to either a non-CDB or a CDB root or,
  --                           starting with Oracle Database 12.2, a PDB.
  --
  --                         o An augmented AWR export from a CDB root can be
  --                           imported to either a CDB root or a non-CDB or,
  --                           starting with Oracle Database 12.2, a PDB.
  --
  --                         o Augmented AWR workloads can only be exported
  --                           from or imported to a PDB with Oracle Database 12.2+.
  --
  --                         o With an augmented AWR import from a non-CDB,
  --                           you must not specify pdb_name.
  --
  --                         o With an augmented AWR import from a CDB root,
  --                           you must specify pdb_name to match one of the
  --                           PDBs contained by the CDB root from which it
  --                           was exported.
  --
  -- awr_store_source          The Automatic Workload Repository (AWR) store
  --                           to be used: 'ROOT' or 'PDB'.  Prior to Oracle
  --                           Database 12.2, all AWR data is stored on the
  --                           root. Starting with Oracle Database 12.2, AWR
  --                           data can be stored on the root or on PDBs or a
  --                           combination of both.
  --
  --                           A choice of the AWR root store or a PDB AWR store
  --                           are only applicable with a live workload on a 12.2+
  --                           PDB.  The In Memory Advisor sets the awr_store_source
  --                           default accordingly with all other environments.
  --                           Therefore, only set this parameter with a live
  --                           workload on a 12.2+ PDB.
  --
  --                           With a live workload on a 12.2+ PDB, the default
  --                           is 'ROOT'.  You may specify  'PDB'.  Be aware that
  --                           automatic AWR snapshots are disabled by default on
  --                           the PDB store: prior to running the In Memory Advisor
  --                           against a live workload on a 12.2 PDB store, manually
  --                           capture AWR snapshots onto your PDB store or enable
  --                           automatic AWR snapshots on your PDB store.
  --
  --                           Starting with Oracle Database 12.2, you can import
  --                           AWR data onto your PDB store.  With an imported AWR
  --                           workload on a 12.2+ PDB, the In Memory Advisor
  --                           defaults to 'PDB', which is where the AWR is placed
  --                           when imported on a PDB.  AWR data imported onto the
  --                           root is not accessible from a PDB.  Thus as indicated
  --                           above, you need not set this parameter with an imported
  --                           AWR workload on a 12.2+ PDB as it will correctly default.
  --
  --                           The following combinations are not supported and will
  --                           produce in errors:
  --
  --                           o awr_store_source=>'PDB' on Oracle Datbase 11.2 or 12.1.
  --                           o awr_store_source=>'PDB' on a non-CDB or CDB root.
  --                           o awr_store_source=>'ROOT' on a 12.2+ PDB with imported AWR data.
  --
  -- Example:
  --
  -- SQL> EXEC dbms_inmemory_advisor.create_task ('MyTask','In memory advice for my analytics system');

--------------------------------------------------------------------------------
  PROCEDURE add_sqlset (
    task_name             IN  VARCHAR2,
    sqlset_name           IN  VARCHAR2,
    sqlset_owner          IN  VARCHAR2 := SYS_CONTEXT('USERENV','SESSION_USER'));
  -- ADD_SQLSET adds a captured SQL Tuning Set to the specified task.  Since 
  -- ADD_STATISTICS captures the SQL workload from the Automatic 
  -- Workload Repository (AWR), addition of any SQL tuning sets is optional.  However,
  -- the AWR SQL workload contains only the hottest SQL statements (those that use the
  -- greatest amount of resources).  Therefore, a number of SQL statements may be
  -- omitted from the AWR SQL workload.  Addition of SQL Tuning Sets helps produce more
  -- accurate results when the AWR SQL workload is missing a large percentage of the
  -- of the SQL workload.  This is most likely to happen with a large number of distinct
  -- SQL statements or with ad hoc queries.
  --
  -- After you have executed ADD_STATISTICS, you can call ASH_SQL_COVERAGE_PCT to 
  -- determine if you need to start over and add SQL tuning sets with broader SQL
  -- workload coverage.
  --
  -- Notes:
  -- 1.  Procedure CREATE_TASK must be executed prior to executing this
  --     procedure.
  --
  -- 2. Execution of procedure ADD_SQLSET is optional.  If ADD_SQLSET is to be executed,
  --    it must be done prior to ADD_STATISTICS.
  --
  -- 3. DBMS_INMEMORY_ADVISOR.ADD_STATISTICS captures the SQL data from the Automatic 
  --    Workload Repository (AWR).  Therefore, adding a SQL Tuning Set from AWR (using 
  --    DBMS_SQLTUNE.SELECT_WORKLOAD_REPOSITORY) is not useful or recommended. Instead,
  --    use DBMS_SQLTUNE.CAPTURE_CURSOR_CACHE_SQLSET or another means to create a
  --    SQL Tuning Set that contains a broader representation of the SQL workload.
  --
  -- Parameters:
  --
  --   task_name             Name of the task to which the statistics are to be
  --                         added.
  --
  --   sqlset_name           Name of the SQL Tuning Set to be added.
  --
  --   sqlset_owner          Name of the owner of the SQL Tuning Set to be added.
  --                         Default = current user.
  --
  -- Example:
  --
  -- SQL> EXEC dbms_inmemory_advisor.add_sqlset ('MyTask', 'MySqlSet', USER);

--------------------------------------------------------------------------------
  PROCEDURE add_statistics (
    task_name             IN  VARCHAR2,
    capture_window_start  IN  TIMESTAMP   := NULL,
    capture_window_end    IN  TIMESTAMP   := NULL);
  -- ADD_STATISTICS adds ASH and AWR statistics from the specified 
  -- set of snapshots to the specified task.
  --
  -- Notes:
  -- 1. Procedure CREATE_TASK must be executed prior to executing this procedure.
  --
  -- 2. Execution of procedure ADD_SQLSET is optional.  If ADD_SQLSET to be executed,
  --    it must be done prior to ADD_STATISTICS.
  --
  -- Parameters:
  --
  --   task_name             Name of the task to which the statistics are to be
  --                         added.
  --
  --   capture_window_start  The starting date and time for the capture window of live
  --                         and AWR statistics to be added to the task.  By default
  --                         or if you specify NULL, the window starts with
  --                         the oldest statistics available.
  --
  --   capture_window_end  The ending date and time for the capture window of live
  --                         and AWR statistics to be added to the task.  By default
  --                         or if you specify NULL, the window ends with
  --                         the newest statistics available.
  --
  -- Example:
  --
  -- SQL> EXEC dbms_inmemory_advisor.add_statistics ('MyTask', SYSTIMESTAMP-60, SYSTIMESTAMP);

--------------------------------------------------------------------------------
  PROCEDURE add_hist_statistics (
    task_name             IN  VARCHAR2,
    start_snap_id         IN  NUMBER      := NULL,
    end_snap_id           IN  NUMBER      := NULL);
  -- ADD_HIST_STATISTICS adds AWR (DBA_HIST_...) statistics from the specified 
  -- set of snapshots to the specified task.
  --
  -- Notes:
  -- 1. Procedure CREATE_TASK must be executed prior to executing this procedure.
  --
  -- 2. Execution of procedure ADD_SQLSET is optional.  If ADD_SQLSET to be executed,
  --    it must be done prior to ADD_HIST_STATISTICS.
  --
  -- Parameters:
  --
  --   task_name             Name of the task to which the statistics are to be
  --                         added.
  --
  --   start_snap_id         The starting snapshot identifier for the capture
  --                         of AWR statistics to be added to the task.  By default
  --                         or if you specify NULL, the capture starts with
  --                         the oldest snapshot available.
  --
  --   end_snap_id           The ending snapshot idenfifier for the capture
  --                         of AWR statistics to be added to the task.  By default
  --                         or if you specify NULL, the capture ends with
  --                         the newest snapshot available.
  --
  -- Example:
  --
  -- SQL> EXEC dbms_inmemory_advisor.add_hist_statistics ('MyTask', 87, 139);

--------------------------------------------------------------------------------
  FUNCTION ash_sql_coverage_pct (
    task_name  IN VARCHAR2) RETURN NUMBER;
  -- ASH_SQL_COVERAGE_PCT returns the perccentage (0-100) of ASH samples that
  -- covered by SQL statistics. If less than 50%, you may wish to start over
  -- with more SQL statistics by adding SQL tuning sets.  If you have already
  -- added SQL tuning sets, you may wish to do so again using longer capture
  -- windows.
  -- Parameters:
  --
  --   task_name             Name of the task from which the percentage of ASH
  --                         samples that are covered by SQL statistics is to
  --                         be determined.
  --
  -- Return value:           Percentage (0-100) of ASH samples that are covered by
  --                         by SQL statistics.
  
--------------------------------------------------------------------------------
  PROCEDURE set_compression_factor (
    compression_type          IN NUMBER,
    compression_factor        IN NUMBER,
    owner_pattern             IN VARCHAR2 := '%',
    table_name_pattern        IN VARCHAR2 := '%',
    task_name                 IN VARCHAR2 := NULL);
  -- SET_COMPRESSION_FACTOR sets a fixed, user-specified compression factor for
  -- a specified compression type on the specified tables.  SET_COMPRESSION_FACTOR
  -- sets the compression factor for all tables that match the specified owner and
  -- table name patterns that also appear in the workload statistics
  -- and data.  SET_COMPRESSION_FACTOR is significantly faster
  -- than ESTIMATE_COMPRESSION_FACTOR but can result in less accurate
  -- estimates of in-memory sizes, depending upon how you determine the
  -- compression factor you specify.
  --
  -- For a given Oracle Database In-Memory Advisor task, previous compression factors
  -- for specific objects set with SET_COMPRESSION_FACTOR  or estimated with
  -- ESTIMATE_COMPRESSION_FACTOR are overridden by subsequent calls
  -- to SET_COMPRESSION_FACTOR or ESTIMATE_COMPRESSION_FACTOR that match the same
  -- object: The last setting or estimate of the compression factor for a given object
  -- stands.
  --
  -- Compression factors that are set or estimated for a specific task are not
  -- affected by subsequent compression factor settings or estimates for other specific tasks.
  -- However, tasks that lack compression factor settings or estimates for a given object
  -- and compression type share the compression factors that are available from other tasks.
  -- Therefore, if you use multiple Oracle Database In-Memory Advisor tasks, it is not
  -- necessary to set or estimate the compression factor for objects that already have
  -- compression factors with other Oracle Database In-Memory Advisor tasks.
  --
  -- Note: Procedure CREATE_TASK and ADD_STATISTICS must be executed prior to executing this
  -- procedure.
  --
  -- Parameters:
  --
  --   compression_type          One of the following DBMS_COMPRESSION
  --                             constants:
  --                               COMP_INMEMORY_BASIC or 8192
  --                               COMP_INMEMORY_QUERY or 16384
  --                               COMP_INMEMORY_CAPACITY_LOW or 32768
  --                               COMP_INMEMORY_CAPACITY_HIGH or 65536
  --
  --   compression_factor        The compression factor to be set for the
  --                             specified compression type with the objects
  --                             that match the owner and table name patterns.
  --                             You can also remove prior compression factor
  --                             settings by setting the compression factor to NULL.
  --
  --   owner_pattern             A string pattern that the owner must match with
  --                             a LIKE predicate.
  --
  --   table_name_pattern        A string pattern that the table name must match
  --                             with a LIKE predicate.
  -- 
  --   task_name                 Name of the task for which the compression factor is to be
  --                             set.  By default of if you specify task_name as
  --                             NULL, the compression factor is set for and applied
  --                             to all existing Oracle Database In-Memory Advisor tasks
  --                             that have added statistics and that have not had their
  --                             compression factors specified with either
  --                             DBMS_INMEMORY_ADVISOR.SET_COMPRESSION_FACTOR or
  --                             DBMS_INMEMORY_ADVISOR.ESTIMATE_COMPRESSION_FACTOR.
  --
  -- Example:
  --
  -- SQL> EXEC dbms_inmemory_advisor.set_compression_factor (
  -- 2 dbms_inmemory_advisor.comp_inmemory_query, 15, 'SH', 'SALES%', 'MyTask');
  

--------------------------------------------------------------------------------
  PROCEDURE estimate_compression_factor (
    compression_type          IN NUMBER,
    scratch_tablespace_name   IN VARCHAR2,
    owner_pattern             IN VARCHAR2 := '%',
    table_name_pattern        IN VARCHAR2 := '%',
    task_name                 IN VARCHAR2 := NULL);
  -- ESTIMATE_COMPRESSION_FACTOR estimates a compression factor
  -- for a specified compression type on the specified table for the specified task.
  -- ESTIMATE_COMPRESSION_FACTOR estimates the compression factor for all objects
  -- that match the specified owner and table name, partition name patterns that
  -- also appear in the workload statistics and data associated with the task.
  -- ESTIMATE_COMPRESSION_FACTOR is significantly slower than SET_COMPRESSION_FACTOR
  -- but can result in more accurate estimates of in-memory sizes.
  --
  -- Previous compression factors for specific objects with a specific task set with
  -- SET_COMPRESSION_FACTOR  or estimated with ESTIMATE_COMPRESSION_FACTOR are overridden
  -- by subsequent calls to SET_COMPRESSION_FACTOR or ESTIMATE_COMPRESSION_FACTOR that match the same
  -- object and task: The last setting or estimate of the compression factor for a given object
  -- with a given task stands.
  --
  -- Compression factors that are set or estimated for a specific task are not
  -- affected by subsequent compression factor settings or estimates for other specific tasks.
  -- However, tasks that lack compression factor settings or estimates for a given object
  -- and compression type share the compression factors that are available from other tasks.
  -- Therefore, if you use multiple Oracle Database In-Memory Advisor tasks, it is not
  -- necessary to set or estimate the compression factor for objects that already have
  -- compression factors with other Oracle Database In-Memory Advisor tasks.
  --
  -- Note: Procedure CREATE_TASK and ADD_STATISTICS must be executed prior to executing this
  -- procedure.
  --
  -- Parameters:
  --
  --   compression_type          One of the following DBMS_COMPRESSION
  --                             constants:
  --                               COMP_INMEMORY_BASIC or 8192
  --                               COMP_INMEMORY_QUERY or 16384
  --                               COMP_INMEMORY_CAPACITY_LOW or 32768
  --                               COMP_INMEMORY_CAPACITY_HIGH or 65536
  --
  --   scratch_tablespace_name   The name of the scratch tablespace to be used for compression
  --                             estimation.
  --
  --   owner_pattern             A string pattern that the owner must match with
  --                             a LIKE predicate.
  --
  --   table_name_pattern        A string pattern that the table name must match
  --                             with a LIKE predicate.
  --
  --   task_name                 Name of the task for which the compression factor is to be
  --                             estimated.  By default of if you specify task_name as
  --                             NULL, the compression factor is estimated for and applied
  --                             to all existing Oracle Database In-Memory Advisor tasks
  --                             that have added statistics and that have not had their
  --                             compression factors specified with either
  --                             DBMS_INMEMORY_ADVISOR.SET_COMPRESSION_FACTOR or
  --                             DBMS_INMEMORY_ADVISOR.ESTIMATE_COMPRESSION_FACTOR.
  --
  -- SQL> EXEC dbms_inmemory_advisor.estimate_compression_factor (
  -- 2 dbms_inmemory_advisor.comp_inmemory_query, 'MY_SCRATCH_TS', 'SH', 'SALES%', 'MyTask');

--------------------------------------------------------------------------------
  PROCEDURE execute_task (
    task_name              IN VARCHAR2,
    consider_objects_like  IN VARCHAR2 := NULL);
  -- EXECUTE_TASK analyzes the available data and statistics that have been added to
  -- the specified task.
  --
  -- Note: Procedures CREATE_TASK and ADD_STATISTICS must be executed prior to
  -- executing this procedure.
  --
  -- Parameters:
  --
  --   task_name                 Name of the task to analyze.
  --
  --   consider_objects_like     Optional list of object name patterns to consider as
  --                             candidates.  By default, all objects are candidates.
  --                             You may optionally specify a comma separated list of
  --                             object name patterns to be considered exclusively as
  --                             candidates.  The object name pattern is as follows:
  --
  --                               OBJECT_OWNER.OBJECT_NAME,...
  --
  --                             You may specify multiple object name patterns separated
  --                             by commas (",").  You may use the percent sign ("%") as a
  --                             wild card.   The object name patterns are case sensitive.
  --
  --                             When you specify one or more object name patterns, only
  --                             objects which match at least one of the patterns will be
  --                             considered.
  --
  -- Examples:
  --
  -- SQL> EXEC dbms_inmemory_advisor.execute_task ('MyTask');
  -- SQL> EXEC dbms_inmemory_advisor.execute_task ('MyTask2', 'GEEK_SUMMARY.%,%.GEEK_%');

--------------------------------------------------------------------------------
  PROCEDURE generate_recommendations (
    task_name             IN VARCHAR2,
    directory_name        IN VARCHAR2 := 'DATA_PUMP_DIR',
    inmemory_size         IN NUMBER   := NULL,
    single_page_report    IN BOOLEAN  := FALSE);
  -- Generates output files based upon the analysis of the
  -- specified task.
  --
  -- Notes:
  --
  -- 1. Procedures CREATE_TASK, ADD_STATISTICS and EXECUTE_TASK must be executed
  --    prior to executing this procedure.
  --
  -- 2. The file for the top html page of the report is named
  --    imadvisor_<task_name>.html.  The implementation script is named
  --    imadvisor_<task_name>.sql.  Additional generated recommendation files
  --    are all named with the prefix imadvsior_<task_name>.  When you transfer
  --    the files from the server, you must transfer all files with this name
  --    pattern to the same directory, or you may encounter broken HTML links.
  --
  -- Parameters:
  --
  --   task_name                 Name of the task from which to generate
  --                             recommendations.
  --
  --   directory_name            The name of the Oracle directory object where
  --                             the generated recommendation files are to be
  --                             placed.  The default is DATA_PUMP_DIR.
  --
  --   inmemory_size             The size to be used for in memory storage in
  --                             bytes. The Oracle Database In-Memory Advisor
  --                             uses the largested recommended IM size as the
  --                             default size.  The top page of the generated
  --                             report contains information to help you choose
  --                             the most suitable in-memeory size.  You can
  --                             therefore first generate the report using the
  --                             default in-memory size.  If you then decide to
  --                             use a different in-memory size, you can call
  --                             GENERATE_RECOMMENDATIONS again, specifying the
  --                             in-memory size you wish.
  --
  --   single_page_report        TRUE ==> Generate the report as a single,
  --                             large html file.
  --
  --                             FALSE ==> Generate the report as a number of
  --                             smaller, html files.
  --
  --                             Default: FALSE.
  --
  --                             Note: A single html file is more convenient
  --                             for file transfers and email distributions.
  --                             A number of smaller html files is more efficient
  --                             for browsers and can help avoid browser hangs.
  --
  -- Example:
  --

  --   SQL> EXEC dbms_inmemory_advisor.generate_recommendations ('MyTask', 'MY_ORACLE_DIRECTORY', 50000000000);
  --   SQL> SELECT directory_path FROM dba_directories WHERE directory_name='MY_ORACEL_DIRECTORY';
  --
  --   DIRECTORY_PATH
  --   -----------------------------------------------------------
  --   /usr/oracle/directories/my_oracle_directory
  --
  --   SQL> EXIT
  --   $ cd /usr/oracle/directories/my_oracle_directory
  --   $ firefox imadvisor_MyTask.html
  --   sqlplus / as sysdba
  --   SQL> @imadvisor_MyTask.sql

--------------------------------------------------------------------------------  
  PROCEDURE drop_task (
    task_name             IN VARCHAR2,
    force                 IN BOOLEAN := FALSE);
  -- DROP_TASK drops a DBMS_INMEMORY_ADVISOR task.
  --
  -- Parameters:
  --
  --   task_name             A unique name up to 30 characters in length for
  --                         the DBMS_INMEMORY_ADVISOR task.
  --
  --   force                 By default, drop_task will not drop an active task.
  --                         However, if a task crashes, it remains in an active
  --                         state.  To drop a task after it has crashed,
  --                         specify FORCE=>TRUE.
  --
  -- Example:
  --
  -- SQL> EXEC dbms_inmemory_advisor.drop_task ('MyTask');

--------------------------------------------------------------------------------
  PROCEDURE set_parameter (parameter_name IN VARCHAR2, parameter_value IN NUMBER, task_name IN VARCHAR2 := NULL);
  -- SET_PARAMETER sets a DBMS_INMEMORY_ADVISOR parameter.
  --
  -- Notes:
  --
  -- If task_name is specified with a non-NULL value, the task must have already been created with CREATE_TASK, and the parameter
  -- setting will be applied only to the specified task.
  -- 
  -- If task_name is not specified or is specified with a NULL value, the parameter setting will apply to all tasks that
  -- have not had a task-specific setting for the same parameter.
  -- 
  -- Each parameter must be set prior to calling ADD_STATISTICS or ADD_HIST_STATISTICS in order to have any effect.
  --
  -- Parameters:
  --
  --   parameter_name        Name of the parameter to be set.
  -- 
  --
  --   parameter_value       Value with which to set the parameter.
  --
  --   task_name             Name of the task for which the parameter
  --                         setting is to be applied.
  --
  -- Parameter names, default values and descriptions:
  -- 
  -- read_benefit_factor, default=10.0
  -- Estimate that read activity on an object with in-memory placement will be N x faster.
  -- 10.0 ==> 10X faster.
  --
  -- write_disadvantage_factor, default=0.9
  -- Estimate that write activity on an object with in-memory placement will affect overall performance x N, where N<1.
  -- 0.8 ==> 20% slower.
  --
  -- cpu_benefit_factor, default=2.0
  -- Estimate that CPU activity will be N x faster.
  -- 3.0 ==> 3X faster.
  --
  -- min_overall_benefit_factor, default=1.05
  -- Minimum overall performance benefit, including non-analytics.
  -- 1.05 ==> no recommendations will be presented unless the overall performance improvement >= 5%.
  -- (With only an overall 5% performance improvement, it would be difficult to observe the performance improvement.)
  --
  -- min_inmemory_object_size, default=65536
  -- Minimum object size to qualify for in-memory placement.
  -- 65536 ==> objects smaller than 64KB will be rejected as candidates due to in-memory placement ineligibility.

--------------------------------------------------------------------------------
  FUNCTION get_parameter (parameter_name IN VARCHAR2, task_name IN VARCHAR2 := NULL) RETURN NUMBER;
  -- GET_PARAMETER returns a DBMS_INMEMORY_ADVISOR parameter value.
  --
  -- Notes:
  --
  -- If task_name is specified with a non-NULL value, the parameter setting for the specified task is returned.
  --
  -- If task_name is not specified or is specified as NULL, the parameter setting for all tasks without a task-specific setting is returned.
  --
  -- If the parameter has not been set, the default value is returned.
  --
  -- Parameters:
  --
  --   parameter_name        Name of the parameter value to be returned.
  -- 
  --
  --   task_name             Name of the task from which the parameter
  --                         setting is to be fetched.
  --
  -- Parameter names, default values and descriptions:
  --
  --   Refer to the SET_PARAMETER description.

--------------------------------------------------------------------------------
  PROCEDURE reset_parameters (task_name IN VARCHAR2 := NULL);
  -- RESET_PARAMETERS resets parameters to their defaults.
  --
  -- Notes:
  --
  -- If task_name is specified with a non-NULL value, the parameters for the specified task are reset.
  --
  -- If task_name is not specified or is specified as NULL, the parameters for all tasks are reset.
  --
  -- Parameters:
  --   task_name             Name of the task for which the parameters
  --                         are to be reset.


--******************************************************************************
--****  The following interfaces are not documented and are intended only   ****
--****   for use with In-Memory Advisor SQL*Plus scripts.                   ****
--******************************************************************************

--------------------------------------------------------------------------------
  FUNCTION local_database_type RETURN VARCHAR2;
 
--------------------------------------------------------------------------------

  PROCEDURE fetch_local_db_info
    (userspec_pdb_name        IN  VARCHAR2,
     db_is_cdb_root           OUT BOOLEAN,
     db_is_pdb_seed           OUT BOOLEAN,
     db_is_pdb                OUT BOOLEAN,
     pdb_name                 OUT VARCHAR2,
     con_id                   OUT NUMBER,
     con_dbid                 OUT NUMBER,
     dbid                     OUT NUMBER,
     db_name                  OUT VARCHAR2,
     db_created               OUT DATE,
     instance_number          OUT NUMBER,
     instance_name            OUT VARCHAR2,
     instance_version         OUT VARCHAR2,
     instance_version_banner  OUT VARCHAR2,
     compatible_version       OUT VARCHAR2,
     service_name             OUT VARCHAR2,
     sga_max_size             OUT NUMBER,
     inmemory_size            OUT NUMBER,
     inmemory_unused_space    OUT NUMBER,
     ash_sample_interval      OUT NUMBER,
     ash_diskfilter_ratio     OUT NUMBER,
     db_supports_inmemory     OUT BOOLEAN);

--******************************************************************************
--****  Use the following internal interfaces only under the direction of   ****
--****  Oracle Support, Oracle Development or other authorized Oracle       ****
--****  agents.  These internal interfaces are otherwise not supported and  ****
--****  their use can result in unpredictable behavior.                     ****
--******************************************************************************

  -- Specify task_name to apply a parameter setting to a specific task.
  -- Specify task_name as NULL to apply a default parameter setting to all tasks.
  -- If a parameter has a default setting for all tasks and a different setting for a specific task,
  -- the specific setting will apply to the specified task while the default setting will apply to
  -- all tasks without a specific setting.
  PROCEDURE set_str_parameter$ (task_name IN VARCHAR2, parameter_name IN VARCHAR2, parameter_value IN VARCHAR2);
  PROCEDURE set_num_parameter$ (task_name IN VARCHAR2, parameter_name IN VARCHAR2, parameter_value IN NUMBER);
  FUNCTION  get_str_parameter$ (task_name IN VARCHAR2, parameter_name IN VARCHAR2) RETURN VARCHAR2;
  FUNCTION  get_num_parameter$ (task_name IN VARCHAR2, parameter_name IN VARCHAR2) RETURN NUMBER;

END dbms_inmemory_advisor;
/
SHOW ERRORS;

EXEC EXECUTE IMMEDIATE 'CREATE OR REPLACE PUBLIC SYNONYM dbms_inmemory_advisor FOR '||SYS_CONTEXT('USERENV','CURRENT_SCHEMA')||'.dbms_inmemory_advisor';

GRANT EXECUTE ON dbms_inmemory_advisor TO PUBLIC;

-- @?/rdbms/admin/sqlsessend.sql
